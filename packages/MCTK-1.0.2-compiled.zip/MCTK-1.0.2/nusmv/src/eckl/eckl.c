/**CFile***********************************************************************

  FileName    [eckl.c]

  PackageName [eckl]

  Synopsis    [Routines to perform fair ECKLn model checking.]

  Description [Routines to perform fair ECKLn model checking.]

  SeeAlso     [mc]

  Author      [Xiangyu Luo]

  Copyright   [
  This file is part of the ``eckl'' package of MCTK version 1.
  Copyright (C) 2003-2004 by Multi-Agent System Research Group in
  Sun Yat-sen University, Guangzhou, China.

  MCTK version 1 is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  MCTK version 1 is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA.

  For more information of MCTK see <http://agent.sysu.edu.cn>
  or email to <isp03lxy@student.zsu.edu.cn>.
  Please report bugs to <isp03lxy@student.zsu.edu.cn>.

  To contact the MCTK development board, email to <isp03lxy@student.zsu.edu.cn>. ]

******************************************************************************/
#include "ecklInt.h"
#include "error.h" /* for CATCH */
/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/**Variable********************************************************************

  Synopsis    [Variables to dump the state]

  Description [These variables are used by <tt>starPushStatus</tt>
  and <tt>starPopStatus</tt> to save the system state.]

  SeeAlso     [starPushStatus starPopStatus]

******************************************************************************/
static node_ptr old_state_variables = Nil;
static node_ptr old_all_variables = Nil;
static node_ptr old_all_symbols = Nil;
static node_ptr old_input_variables = Nil;
static node_ptr old_real_state_variables = Nil;
static node_ptr old_boolean_variable_list = Nil;

static bdd_ptr old_input_variables_bdd = (bdd_ptr)NULL;
static bdd_ptr old_next_input_variables_bdd = (bdd_ptr)NULL;
static bdd_ptr old_state_variables_bdd = (bdd_ptr)NULL;
static bdd_ptr old_next_state_variables_bdd = (bdd_ptr)NULL;

static add_ptr old_input_variables_add = (add_ptr)NULL;
static add_ptr old_next_input_variables_add = (add_ptr)NULL;
static add_ptr old_state_variables_add = (add_ptr)NULL;
static add_ptr old_next_state_variables_add = (add_ptr)NULL;

static int old_minterm_vars_dim;

static int old_num_of_variables;  //the number of BDD variables before creating the auxiliary variables
static bdd_ptr old_init_bdd;  //the old BDD of the initiate states
static CPCluster * AuxiTRCluster;  //the auxiliary cluster that store the auxiliary transition relation
static node_ptr old_Justice; //the old fairness constraints fsm->Justice


//Compassion type
static enum Compassion_Type Eckl_CompassionType = Compassion_NoType;
enum Compassion_Type Eckl_get_CompassionType() {return Eckl_CompassionType;}
void Eckl_set_CompassionType(enum Compassion_Type CompType) {Eckl_CompassionType=CompType;}

structCompassionFormulas Eckl_Compassions;  //the var list of compassion formulas
void Eckl_Compassions_free_all()
{
	int i;
	if(Eckl_Compassions.count>0 && Eckl_Compassions.count<=MAX_COMPASSIONFORMULA_NUMBER){
		for(i=0; i<Eckl_Compassions.count; i++)
			Eckl_MaxSubformula_free_one_variable(Eckl_Compassions.CF[i].var);
	}
	Eckl_Compassions.count = 0;
}

//----------------------------------------------------------------------------
//  The type of CTL* model checking algorithm
//  1 -- Normal
//  2 -- Using CTL model checking algorithm once a subformula is a CTL formula.
//----------------------------------------------------------------------------
static int CTLstar_Algorithm_Type = 1;
int Eckl_get_CTLstar_algorithm_type() {return CTLstar_Algorithm_Type;};
void Eckl_set_CTLstar_algorithm_type(int type) {if (type==1 | type==2) CTLstar_Algorithm_Type=type; else CTLstar_Algorithm_Type=1;};

static int Eckl_print_bdd_stats = 0;
void Eckl_set_print_bdd_stats() {Eckl_print_bdd_stats=1;};




/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/
extern char * Eckl_get_string(node_ptr n);
extern char * Eckl_get_ecklspec_string(node_ptr n);
extern bdd_ptr Eckl_eval_spec(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
extern void Compile_FsmBddSetJustice(Fsm_BddPtr fsm, node_ptr justice);
node_ptr Eckl_spec_pretreatment(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr SNP_evaluation(Fsm_BddPtr fsm);
bdd_ptr WhatSum_evaluation(Fsm_BddPtr fsm);
bdd_ptr MuddyChildren_evaluation(Fsm_BddPtr fsm);


/**Function********************************************************************

  Synopsis           [show one variable.]

  Description        []

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_show_var(node_ptr var)
{
	nusmv_assert(var != (node_ptr)NULL);
//	set_indent_size(1);
	node_ptr data = lookup_symbol_hash(var);
	if (data != Nil && node_get_type(data) == VAR) {
		//print_node(nusmv_stdout, car(l));
		indent_node(nusmv_stdout, "", var, "");
		fprintf(nusmv_stdout, " : ");
		print_node(nusmv_stdout, cdr(data));
//		fprintf(nusmv_stdout, "\n");
	}
//	reset_indent_size();
}

/**Function********************************************************************

  Synopsis           [show all variables.]

  Description        []

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_show_vars(boolean statevars, boolean inputvars)
{
	node_ptr l = Nil;

	if (statevars == true && inputvars == true) l = all_variables;
	else if (inputvars == true) l = input_variables;
	else l = state_variables;

	set_indent_size(1);
	while (l != Nil) {
		node_ptr data = lookup_symbol_hash(car(l));
		if (data != Nil && node_get_type(data) == VAR) {
			//print_node(nusmv_stdout, car(l));
			indent_node(nusmv_stdout, "", car(l), "");
			fprintf(nusmv_stdout, " : ");
			print_node(nusmv_stdout, cdr(data));
			fprintf(nusmv_stdout, "\n");
		}
		l = cdr(l);
	}
	reset_indent_size();
}

/**Function********************************************************************

  Synopsis           [Print the ECKL specification.]

  Description        [Print the ECKL specification.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_print_spec(FILE *file, node_ptr n)
{
  node_ptr context = Nil;

  if (node_get_type(n) == CONTEXT) {
    context = car(n);
    n = cdr(n);
  }
  indent_node(file, "ECKLn specification: ", n, " ");
  if(context) {
    fprintf(file, "(in module ");
    print_node(file, context);
    fprintf(file, ") ");
  }
}

/**Function*********************************************************************

  Synopsis    [Print all of the reachable states that satisfies formula s, if arguement 'only_init_state'==true,
  then print only the initiate states.]

  Description []

  SideEffects []

  SeeAlso     []

  Author       [LUO Xiangyu (Xiangyu Luo)]

******************************************************************************/
void  Eckl_print_satisfiable_states(Fsm_BddPtr fsm, bdd_ptr s, boolean only_init_states)
{
	boolean b1, b2;
	if(s == (bdd_ptr)Nil) {	printf("Eckl_print_satisfiable_states(): the formula s is Nil!\n"); nusmv_exit(1);}

	b1 = opt_forward_search(options);  set_forward_search(options);
	b2 = opt_print_reachable(options);  set_print_reachable(options);

//	(void) print_reachable_states(fsm, 0);  //compute reachable states
	//compute reachable states
	if (reachable_states_bdd == (bdd_ptr)NULL) {
		compute_reachable_states(fsm);
	}

	bdd_ptr s0, tmp;
	s0 = bdd_dup(s);
	bdd_and_accumulate(dd_manager, &s0, reachable_states_bdd);

	tmp = bdd_forsome(dd_manager, s0, input_variables_bdd);
	bdd_free(dd_manager, s0);
	s0 = bdd_dup(tmp);
	bdd_free(dd_manager, tmp);

	if(only_init_states) {
		// Intersect with init and invar states
		bdd_and_accumulate(dd_manager, &s0, Compile_FsmBddGetInit(fsm));
		bdd_and_accumulate(dd_manager, &s0, Compile_FsmBddGetInvar(fsm));
	}
	if(s0==(bdd_ptr)Nil) {rpterr("Eckl_print_satisfiable_states(): the formula s0 is Nil!\n"); nusmv_exit(1); }

	int c = bdd_count_minterm(dd_manager, s0, get_minterm_vars_dim());
	if(c>0){
		if(only_init_states) 	fprintf(nusmv_stdout, "------ %d INITIAL states satisfying the specification  ------\n", c);
		else 	fprintf(nusmv_stdout, "------ %d REACHABLE states satisfying the specification  ------\n", c);
		print_states(s0);
	}
	bdd_free(dd_manager, s0);

	if(!b2) unset_print_reachable(options);
	if(!b1) unset_forward_search(options);
	return;
}
/**Function********************************************************************

  Synopsis           [Save the status of global variables]

  Description        [Save the status of global variables]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_SaveStatus()
{
	node_ptr tmp;

	old_state_variables      = state_variables;
	old_all_variables        = all_variables;
	old_all_symbols          = all_symbols;
	old_input_variables      = input_variables;
	old_real_state_variables = real_state_variables;
	old_boolean_variable_list= Nil;

	tmp = get_boolean_variable_list();
	while(tmp) {
		old_boolean_variable_list = cons(car(tmp),old_boolean_variable_list);
		tmp = cdr(tmp);
	}
	old_boolean_variable_list = reverse(old_boolean_variable_list);

	old_state_variables_bdd       = bdd_dup(state_variables_bdd);
	old_state_variables_add       = add_dup(state_variables_add);

	old_next_state_variables_bdd  = bdd_dup(next_state_variables_bdd);
	old_next_state_variables_add  = add_dup(next_state_variables_add);

	old_input_variables_bdd       = bdd_dup(input_variables_bdd);
	old_input_variables_add       = add_dup(input_variables_add);

	old_next_input_variables_bdd  = bdd_dup(next_input_variables_bdd);
	old_next_input_variables_add  = add_dup(next_input_variables_add);

	old_minterm_vars_dim = get_minterm_vars_dim();

	old_num_of_variables = num_of_variables_get();  //the number of BDD variables before creating the auxiliary variables

}

/**Function********************************************************************

  Synopsis           [Restore the status of global variables previously saved]

  Description        [Restore the status of global variables previously saved]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_RestoreStatus()
{
  state_variables      = old_state_variables;
  all_variables        = old_all_variables;
  all_symbols          = old_all_symbols;
  input_variables      = old_input_variables;
  real_state_variables = old_real_state_variables;

  free_boolean_variable_list();
  set_boolean_variable_list(old_boolean_variable_list);


  bdd_free(dd_manager, state_variables_bdd);
  state_variables_bdd = old_state_variables_bdd;

  add_free(dd_manager, state_variables_add);
  state_variables_add = old_state_variables_add;

  bdd_free(dd_manager, next_state_variables_bdd);
  next_state_variables_bdd  = old_next_state_variables_bdd;

  add_free(dd_manager, next_state_variables_add);
  next_state_variables_add = old_next_state_variables_add;

  bdd_free(dd_manager, input_variables_bdd);
  input_variables_bdd = old_input_variables_bdd;

  add_free(dd_manager, input_variables_add);
  input_variables_add = old_input_variables_add;

  bdd_free(dd_manager, next_input_variables_bdd);
  next_input_variables_bdd  = old_next_input_variables_bdd;

  add_free(dd_manager, next_input_variables_add);
  next_input_variables_add  = old_next_input_variables_add;


  set_minterm_vars_dim(old_minterm_vars_dim);

	//free all of the auxiliary variables from DD manager
	Eckl_AuxiVars_free_all();
	num_of_variables_set(old_num_of_variables);

}

/**Function********************************************************************

  Synopsis           [Add the LTL tableau as a new BDD cluster in the transition relation.]

  Description        [the new auxiliary cluster Ci will be returned.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
CPTrans_Ptr Eckl_Compile_CPAddClusterAndFillSchedule(CPTrans_Ptr trans,
                                                bdd_ptr tableau_bdd, CPCluster * Ci)
{
  //CPCluster * Ci;
  CPList fwd_clusters , bwd_clusters, old_fwd, old_bwd;
  CPTrans_Ptr result = CPTransAlloc();

  nusmv_assert(result != (CPTrans_Ptr)NULL);

  //free the old version of auxiliary transition relation
  if(Ci != (CPCluster *)NULL) CPClusterFree(dd_manager, Ci);

  Ci = CPClusterAlloc();

  CPClusterSetTi(Ci, bdd_dup(tableau_bdd));

  bdd_ptr vars = bdd_and(dd_manager, state_variables_bdd, input_variables_bdd);
  old_fwd = CPTransGetForward(trans);
  fwd_clusters = CPListAddOneCluster(Ci, old_fwd, vars);
  CPTransSetForward(result, fwd_clusters);

  bdd_ptr next_vars = bdd_and(dd_manager, next_state_variables_bdd, next_input_variables_bdd);
  old_bwd = CPTransGetBackward(trans);
  bwd_clusters = CPListAddOneCluster(Ci, old_bwd, next_vars);
  CPTransSetBackward(result, bwd_clusters);

  //AuxiTRCluster = Ci;

  return(result);
}

/**Function********************************************************************

  Synopsis           [Delete the LTL tableau as a new BDD cluster Ci in the transition relation trans
  and return the updated transition relation.]

  Description        [the new auxiliary cluster Ci will be poped from the old status.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
CPTrans_Ptr Eckl_Compile_CPDeleteClusterAndUpdateSchedule(CPTrans_Ptr trans, CPCluster * Ci)
{
	bdd_ptr vars;
	CPList fwd_clusters , bwd_clusters, old;
	CPTrans_Ptr result = CPTransAlloc();

	nusmv_assert(result != (CPTrans_Ptr)NULL);
	nusmv_assert(Ci != (CPCluster_Ptr)NULL);

	old = CPTransGetForward(trans);
	fwd_clusters = CPListDeleteCluster(old, Ci);
	CPTransSetForward(result, fwd_clusters);

	old = CPTransGetBackward(trans);
	bwd_clusters = CPListDeleteCluster(old, Ci);
	CPTransSetBackward(result, bwd_clusters);

	//free the auxiliary transition relation
	if(Ci != (CPCluster *)NULL) CPClusterFree(dd_manager, Ci);
	Ci = NULL;
	//AuxiTRCluster = NULL;

	return(result);
}

/**Function********************************************************************

  Synopsis           [Main routine to add the ECKLn tableau to the FSM]

  Description        []

  SideEffects        [fsm will be added with AuxiTR and AuxiInit,
  				save the old BDD of the initiate states to old_init_bdd]

  SeeAlso            []

******************************************************************************/
void Eckl_FsmAddTableau(Fsm_BddPtr fsm, bdd_ptr AuxiInit, bdd_ptr AuxiTR, structJusticeFormulas * AuxiJF)
{
	Partition_Method part;
	Fsm_BddPtr fsm_res;
	CPTrans_Ptr cp_trans;
	add_ptr tmp_add;
	bdd_ptr tmp_bdd;
	bdd_ptr init;

	nusmv_assert(fsm != (Fsm_BddPtr)NULL);
	nusmv_assert(AuxiInit != (bdd_ptr)NULL);
	nusmv_assert(AuxiTR != (bdd_ptr)NULL);

	//----(1) We update the cubes for quantification----
	add_and_accumulate(dd_manager, &state_variables_add, old_state_variables_add);
	bdd_and_accumulate(dd_manager, &state_variables_bdd, old_state_variables_bdd);

	add_and_accumulate(dd_manager, &next_state_variables_add, old_next_state_variables_add);
	bdd_and_accumulate(dd_manager, &next_state_variables_bdd, old_next_state_variables_bdd);

	add_and_accumulate(dd_manager, &input_variables_add, old_input_variables_add);
	bdd_and_accumulate(dd_manager, &input_variables_bdd, old_input_variables_bdd);

	add_and_accumulate(dd_manager, &next_input_variables_add, old_next_input_variables_add);
	bdd_and_accumulate(dd_manager, &next_input_variables_bdd, old_next_input_variables_bdd);


	cp_trans = NULL; // just to be sure we capture ecceptions

	//----(2) Update the transition relation from R to (R & AuxiTR)----
	part = get_partition_method(options);
	switch(part) {
	case Monolithic:
	{
		cp_trans = Compile_FsmBddGetMonoTrans(fsm);
		break;
	}
	case Threshold:
	{
		cp_trans = Compile_FsmBddGetThreshold(fsm);
		break;
	}
	case Iwls95CP:
	{
		cp_trans = Compile_FsmBddGetIwls95CP(fsm);
		break;
	}
	default:
	{
		rpterr("Eckl_FsmAddTableau(): unknown partition method\n");
	}
	}
	nusmv_assert(cp_trans != (CPTrans_Ptr)NULL);


	//Add the LTL tableau as a new BDD cluster in the transition relation.
	cp_trans = Eckl_Compile_CPAddClusterAndFillSchedule(cp_trans, AuxiTR, AuxiTRCluster);
	bdd_free(dd_manager, AuxiTR);

	switch(part) {
	case Monolithic:
	{
		Compile_FsmBddSetMonoTrans(fsm, cp_trans);
		break;
	}
	case Threshold:
	{
		Compile_FsmBddSetThreshold(fsm, cp_trans);
		break;
	}
	case Iwls95CP:
	{
		Compile_FsmBddSetIwls95CP(fsm, cp_trans);
		break;
	}
	default:
	{
		rpterr("Eckl_PropAddTableau: unknown partition method\n");
	}
	}

	/*
	//----(3) Update the initial states from fsm->Init to (fsm->Init & AuxiInit)----
	init = Compile_FsmBddGetInit(fsm);
	nusmv_assert(init != (bdd_ptr)NULL);

	//save the old BDD of the initiate states
	if(old_init_bdd != (bdd_ptr)NULL) bdd_free(dd_manager, old_init_bdd);
	old_init_bdd = bdd_dup(init);
	*/

	//----(4) Update the fairness constraints from fsm->Justice to (fsm->Justice U AuxiJF)----
	old_Justice = Compile_FsmBddGetJustice(fsm);	//save old fairness constraints fsm->Justice
	//add all auxiliary justice formulas to fsm->Justice
	int i;
	node_ptr new_justices, n_tmp;
	new_justices = old_Justice;
	for(i=0; i<AuxiJF->count; i++)
	{
		n_tmp = new_node(BDD, (node_ptr)bdd_dup(AuxiJF->JF[i].bdd), Nil);
		new_justices= new_node(CONS, n_tmp, new_justices);
	}

	if (new_justices==Nil)	//add TRUE to J
	{
		n_tmp = new_node(BDD, (node_ptr)bdd_dup(bdd_one(dd_manager)), Nil);
		new_justices= new_node(CONS, n_tmp, new_justices);
	}

	Compile_FsmBddSetJustice(fsm, new_justices);

	  /* Update the fair states */
  	bdd_ptr fair_states = bdd_dup(Compile_FsmBddGetFairStates(fsm));
  	if (fair_states != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states);
  	Compile_FsmBddSetFairStates(fsm, Mc_ComputeFairStates(fsm));


}

/**Function********************************************************************

  Synopsis           [Main routine to delete the ECKLn tableau from the FSM]

  Description        []

  SideEffects        [AuxiTR and AuxiInit will be deleted from fsm,
  				restore the old BDD of the initiate states from old_init_bdd]

  SeeAlso            []

******************************************************************************/
void Eckl_FsmDeleteTableau(Fsm_BddPtr fsm)
{
	Partition_Method part;
	CPTrans_Ptr cp_trans;

	cp_trans = NULL; // just to be sure we capture ecceptions

	//----(1) Restore the old transition relation----
	part = get_partition_method(options);
	switch(part) {
	case Monolithic:
	{
		cp_trans = Compile_FsmBddGetMonoTrans(fsm);
		break;
	}
	case Threshold:
	{
		cp_trans = Compile_FsmBddGetThreshold(fsm);
		break;
	}
	case Iwls95CP:
	{
		cp_trans = Compile_FsmBddGetIwls95CP(fsm);
		break;
	}
	default:
	{
		rpterr("Eckl_FsmDeleteTableau(): unknown partition method\n");
	}
	}
	nusmv_assert(cp_trans != (CPTrans_Ptr)NULL);

	//Delete the new cluster of auxiliary transition relation
	cp_trans = Eckl_Compile_CPDeleteClusterAndUpdateSchedule(cp_trans, AuxiTRCluster);

	switch(part) {
	case Monolithic:
	{
		Compile_FsmBddSetMonoTrans(fsm, cp_trans);
		break;
	}
	case Threshold:
	{
		Compile_FsmBddSetThreshold(fsm, cp_trans);
		break;
	}
	case Iwls95CP:
	{
		Compile_FsmBddSetIwls95CP(fsm, cp_trans);
		break;
	}
	default:
	{
		rpterr("Eckl_PropAddTableau: unknown partition method\n");
	}
	}

	/*
	//----(2) Restore old BDD of initiate states----
	bdd_ptr init = Compile_FsmBddGetInit(fsm);
	if(init != (bdd_ptr)NULL) bdd_free(dd_manager, init);
	Compile_FsmBddSetInit(fsm, old_init_bdd);
	*/

	//----(3) Restore old fairness constraints----
	Compile_FsmBddSetJustice(fsm, old_Justice);

	  /* Update the fair states */
  	bdd_ptr fair_states = bdd_dup(Compile_FsmBddGetFairStates(fsm));
  	if (fair_states != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states);
  	Compile_FsmBddSetFairStates(fsm, Mc_ComputeFairStates(fsm));


}

/**Function********************************************************************

  Synopsis    [Compute the cube of auxiliary variables.]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
bdd_ptr Eckl_eval_AuxiVars_Cube() {
	bdd_ptr AuxiVars_cube;

	AuxiVars_cube = bdd_cube_diff(dd_manager, state_variables_bdd, old_state_variables_bdd);
	return (AuxiVars_cube);
}




/**Function********************************************************************

  Synopsis           [Main routine to add the BDD AuxiTR to the FSM, so that the new_TR = (old_TR and AuxiTR)]

  Description        []

  SideEffects        [save the new auxilary TR cluster to Ci that will be deleted later to restore the old TR]

  SeeAlso            []

******************************************************************************/
void Eckl_TransAddBdd(Fsm_BddPtr fsm, bdd_ptr AuxiTR, CPCluster * Ci)
{
	Partition_Method part;
	CPTrans_Ptr cp_trans;

	nusmv_assert(fsm != (Fsm_BddPtr)NULL);
	nusmv_assert(AuxiTR != (bdd_ptr)NULL);


	cp_trans = NULL; // just to be sure we capture ecceptions

	//----(2) Update the transition relation from R to (R & AuxiTR)----
	part = get_partition_method(options);
	switch(part) {
	case Monolithic:
	{
		cp_trans = Compile_FsmBddGetMonoTrans(fsm);
		break;
	}
	case Threshold:
	{
		cp_trans = Compile_FsmBddGetThreshold(fsm);
		break;
	}
	case Iwls95CP:
	{
		cp_trans = Compile_FsmBddGetIwls95CP(fsm);
		break;
	}
	default:
	{
		rpterr("Eckl_TransAndBdd(): unknown partition method\n");
	}
	}
	nusmv_assert(cp_trans != (CPTrans_Ptr)NULL);


	//Add the LTL tableau as a new BDD cluster in the transition relation. A copy of AuxiTR is created in the following function
	cp_trans = Eckl_Compile_CPAddClusterAndFillSchedule(cp_trans, AuxiTR, Ci);
//	bdd_free(dd_manager, AuxiTR);

	switch(part) {
	case Monolithic:
	{
		Compile_FsmBddSetMonoTrans(fsm, cp_trans);
		break;
	}
	case Threshold:
	{
		Compile_FsmBddSetThreshold(fsm, cp_trans);
		break;
	}
	case Iwls95CP:
	{
		Compile_FsmBddSetIwls95CP(fsm, cp_trans);
		break;
	}
	default:
	{
		rpterr("Eckl_TransAndBdd: unknown partition method\n");
	}
	}


	/* Update the fair states */
  	bdd_ptr fair_states = bdd_dup(Compile_FsmBddGetFairStates(fsm));
  	if (fair_states != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states);
  	Compile_FsmBddSetFairStates(fsm, Mc_ComputeFairStates(fsm));


}



/**Function********************************************************************

  Synopsis           [Main routine to delete the auxilary TR in the cluster Ci from the current TR to restore the old TR]

  Description        []

  SideEffects        [AuxiTR will be deleted from fsm]

  SeeAlso            []

******************************************************************************/
void Eckl_TransDeleteBdd(Fsm_BddPtr fsm, CPCluster * Ci)
{
	Partition_Method part;
	CPTrans_Ptr cp_trans;

	cp_trans = NULL; // just to be sure we capture ecceptions

	//----(1) Restore the old transition relation----
	part = get_partition_method(options);
	switch(part) {
	case Monolithic:
	{
		cp_trans = Compile_FsmBddGetMonoTrans(fsm);
		break;
	}
	case Threshold:
	{
		cp_trans = Compile_FsmBddGetThreshold(fsm);
		break;
	}
	case Iwls95CP:
	{
		cp_trans = Compile_FsmBddGetIwls95CP(fsm);
		break;
	}
	default:
	{
		rpterr("Eckl_FsmDeleteTableau(): unknown partition method\n");
	}
	}
	nusmv_assert(cp_trans != (CPTrans_Ptr)NULL);

	//Delete the new cluster of auxiliary transition relation
	cp_trans = Eckl_Compile_CPDeleteClusterAndUpdateSchedule(cp_trans, Ci);

	switch(part) {
	case Monolithic:
	{
		Compile_FsmBddSetMonoTrans(fsm, cp_trans);
		break;
	}
	case Threshold:
	{
		Compile_FsmBddSetThreshold(fsm, cp_trans);
		break;
	}
	case Iwls95CP:
	{
		Compile_FsmBddSetIwls95CP(fsm, cp_trans);
		break;
	}
	default:
	{
		rpterr("Eckl_PropAddTableau: unknown partition method\n");
	}
	}

	 /* Update the fair states */
  	bdd_ptr fair_states = bdd_dup(Compile_FsmBddGetFairStates(fsm));
  	if (fair_states != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states);
  	Compile_FsmBddSetFairStates(fsm, Mc_ComputeFairStates(fsm));
}



/**Function********************************************************************

  Synopsis    [The main routine to perform ECKL model checking.]

  Description [The main routine to perform ECKL model checking. It generates a tableau for
  every principally temporal sub-formula of the ECKL formula. The tableau is
  instantiated, compiled and then conjoined with the original model
  (both the set of fairness conditions and the transition relation are
  affected by this operation, for this reason we save the current
  model, and after the verification of the property we restore the
  original one).]

  SideEffects []

  SeeAlso     []

******************************************************************************/
void Eckl_CheckEcklSpec(Prop_Ptr prop) {



    node_ptr spec  = Prop_GetProp(prop);
    Fsm_BddPtr fsm = Prop_GetBddFsm(prop);
	int tableau_result;
	node_ptr spec_formula = Nil;
	char *orginal_spec;

	orginal_spec = Eckl_get_ecklspec_string(spec);

   //if (opt_verbose_level_gt(options, 0)) {
		fprintf(nusmv_stderr, "--Evaluating ");
		Eckl_print_spec(nusmv_stderr, spec);
		fprintf(nusmv_stderr, "...");
  	//}

  	if (fsm == (Fsm_BddPtr)NULL) {
    	if (opt_cone_of_influence(options) == true) {
			add_ptr one = add_one(dd_manager);
      		node_ptr jc = cmp_struct_get_justice(cmps);
		    node_ptr cc = cmp_struct_get_compassion(cmps);
      		Set_t spec_dep = Formulae_GetDependencies(spec, jc, cc);
      		Set_t cone = ComputeCOI(spec_dep);

      		Prop_BuildFsm(prop, Set_Set2List(cone), jc, cc, one);
      		Prop_SetCone(prop, cone);
      		fsm = Prop_GetBddFsm(prop);
      		add_free(dd_manager, one);
    	}
    	else {
      		Prop_SetFsmToMaster(prop);
      		fsm = Prop_GetBddFsm(prop);
    	}
  	}


	//*----Below Code for the examples of epistemic riddles----
/*	printf("Solving Sum and Product Riddle ...\n");
	bdd_ptr res_bdd = SNP_evaluation(fsm);
*/
/*		
	printf("Solving What Sum Riddle ...\n");
	bdd_ptr res_bdd = WhatSum_evaluation(fsm);


	fprintf(nusmv_stdout, "--All solutions--\n");
	print_states(res_bdd);

	dd_print_stats(dd_manager, nusmv_stdout);

	exit(0);
*/	//----Above Code for the example of Sum and Product----*/

/*
	printf("\nSolving Muddy Children Riddle ...\n");
	bdd_ptr res_bdd = MuddyChildren_evaluation(fsm);
	exit(0);
*/

    	//-----------------------------------------------------------------
	// Compute reachable states
    	//-----------------------------------------------------------------
	/*
	if (Eckl_get_CTLstar_algorithm_type()!=2) //We needn't compute the reachable states for CTL model checking
	{
		if (reachable_states_bdd == (bdd_ptr)NULL)
		{
			//----compute the reachable states one time, then free it.----
			compute_reachable_states(fsm);
		}
	}
	*/


	if (Compile_FsmBddGetJustice(fsm)!=Nil && opt_verbose_level_gt(options, 0))
	{
		fprintf(nusmv_stdout, "\n    ---------------------------------------------------------------------------------------------\n");
		fprintf(nusmv_stdout, "    -- You are specifying some Fairness Constraints when checking the CTL* specification.\n");
		fprintf(nusmv_stdout, "    -- WARNING: The CTL* model checking algorithm with fairness constraints is not fully tested.\n");
		fprintf(nusmv_stdout, "    ---------------------------------------------------------------------------------------------\n");
	}

    	//-----------------------------------------------------------------
	// Get compassion fairness constraints
    	//-----------------------------------------------------------------
	boolean full_fairness = (Compile_FsmBddGetCompassion(fsm) != Nil);
	if(full_fairness && Eckl_get_CompassionType()==Compassion_NoType)
	  fprintf(nusmv_stdout, "***Note: Compassion fairness constraints was defined in the .smv file, but it is omitted in CTL* model checking.\n");
	Eckl_get_Compassions(fsm);

    	//-----------------------------------------------------------------
	// Pretreatment before checking a specification
    	//-----------------------------------------------------------------
	node_ptr parent = new_node(CONTEXT, spec, Nil);  //used to get updated specification
	spec = Eckl_spec_pretreatment(fsm, spec, Nil, parent);

    	//-----------------------------------------------------------------
	// Checking an Eckl specification
    	//-----------------------------------------------------------------
	bdd_ptr s0 = Eckl_eval_spec(fsm, spec, Nil, parent);
	spec = car(parent);  //get the updated specification


    //----------------------from LTL model checking-------------------------
    /* Quantify out the input variables from the result of the
       formula evaluation.  */
    bdd_ptr tmp = bdd_forsome(dd_manager, s0, input_variables_bdd);
    bdd_free(dd_manager, s0);

    /* Negate the result */
    s0 = bdd_not(dd_manager,tmp);
    bdd_free(dd_manager, tmp);
    /* Intersect with init and invar states */
    bdd_and_accumulate(dd_manager,&s0,Compile_FsmBddGetInit(fsm));
    bdd_and_accumulate(dd_manager,&s0,Compile_FsmBddGetInvar(fsm));
    //----------------------from LTL model checking-------------------------

//	/*
//	fprintf(nusmv_stdout, "--print all of the satisfiable (initial/reachable) states--\n");
//	Eckl_print_satisfiable_states(fsm, s0, false);
//	*/


	/* Prints out the result, if not true explain. Now only print out the result. */
	//s0 = Init & Invar & !s0
	if (bdd_is_zero(dd_manager, s0)) {
		fprintf(nusmv_stdout, "TRUE\n");
		Prop_SetStatus(prop, Prop_True);
	}
	else {
		fprintf(nusmv_stdout, "FALSE\n");
		Prop_SetStatus(prop, Prop_False);
	}
	bdd_free(dd_manager, s0);

	if (Eckl_print_bdd_stats) dd_print_stats(dd_manager, nusmv_stdout);
}




