/**CFile***********************************************************************

  FileName    [ecklExplain.c]

  PackageName [eckl]

  Synopsis    [Witness and Debug generator for Fair ECKLn models.]

  Description [Witness and Debug generator for Fair ECKLn models.]

  SeeAlso     []

  Author      [Xiangyu Luo]

  Copyright   [
  This file is part of the ``eckl'' package of MCTK version 1. 
  Copyright (C) 2003-2004 by Multi-Agent System Research Group in 
  Sun Yat-sen University, Guangzhou, China. 

  MCTK version 1 is free software; you can redistribute it and/or 
  modify it under the terms of the GNU Lesser General Public 
  License as published by the Free Software Foundation; either 
  version 2 of the License, or (at your option) any later version.

  MCTK version 1 is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public 
  License along with this library; if not, write to the Free Software 
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA.

  For more information of MCTK see <http://agent.sysu.edu.cn>
  or email to <isp03lxy@student.zsu.edu.cn>.
  Please report bugs to <isp03lxy@student.zsu.edu.cn>.

  To contact the MCTK development board, email to <isp03lxy@student.zsu.edu.cn>. ]

******************************************************************************/
#include "mcInt.h"
#include "ustring.h"
#include "ecklInt.h" 

/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/
extern void Compile_FsmBddSetFairStates(Fsm_BddPtr fsm, bdd_ptr fair);
extern bdd_ptr Eckl_ComputeFairStates(Fsm_BddPtr fsm); 
extern bdd_ptr Eckl_eval_spec(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);

/*---------------------------------------------------------------------------*/
/* Definition of static functions                                          */
/*---------------------------------------------------------------------------*/
static node_ptr Eckl_explain_recur     ARGS((Fsm_BddPtr, node_ptr, node_ptr, node_ptr, node_ptr));

/**Function********************************************************************

  Synopsis           [ECKLn Counterexamples and witnesses generator.]

  Description        [This function takes as input a ECKLn formula and
  returns a witness showing how the given formula does not hold. The
  result consists of a list of states (i.e. an execution trace) that
  leads to a state in which the given formula does not hold.]

  SideEffects        []

  SeeAlso            [explain_recur ex_explain eu_explain eg_explain
  ebg_explain ebu_explain]

******************************************************************************/
node_ptr Eckl_explain(Fsm_BddPtr fsm, node_ptr path, node_ptr spec_formula, node_ptr context, node_ptr parent)
{
	if(Eckl_get_support_compassion()){
		//Compute the fair states under the full fairness constraint, i.e. Justice + Compassion.
		bdd_ptr fair_states = bdd_dup(Compile_FsmBddGetFairStates(fsm));
		if (fair_states != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states);
		(void)Compile_FsmBddSetFairStates(fsm, Eckl_ComputeFairStates(fsm));  //Mc_ComputeFairStates(fsm) = EG(true) under fsm->Justice
	}
	
	node_ptr res = Eckl_explain_recur(fsm, path, spec_formula, context, parent);

	//Recompute(Restore) the CTL fair states, before this operation, the original Justice had been restored after ECKLn model checking.
	bdd_ptr fair_states = bdd_dup(Compile_FsmBddGetFairStates(fsm));
	if (fair_states != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states);
	Compile_FsmBddSetFairStates(fsm, Mc_ComputeFairStates(fsm));  //Mc_ComputeFairStates(fsm) = EG(true) under fsm->Justice
	
	return(res);
}

/**Function********************************************************************

  Synopsis           [Recursively traverse the formula ECKLn and rewrite
                      it in order to use the base witnesses generator functions.]

  Description        [Recursively traverse the formula ECKLn and rewrite
  it in order to use the base witnesses generator functions.<br>
  The rewritings performed use the equivalence between ECKLn formulas,
  i.e. <i>A\[f U g\]</i> is equivalent to <i>!(E\[!g U (!g & !f)\] | EG !g)</i>.]

  SideEffects        []

  SeeAlso            [explain]

******************************************************************************/
static node_ptr Eckl_explain_recur(Fsm_BddPtr fsm, node_ptr path,
                              node_ptr formula_expr, node_ptr context, node_ptr parent)
{
  bdd_ptr a1, a2;
  node_ptr new_path;
  int isLTL;

  if (formula_expr == Nil) return(Nil);
//----------Pretreatment of the specification-------------
	if (Eckl_spec_is_state_formula(formula_expr, Nil)!=1) { 
		//If the spec is not a state formula, path quantifier A will be added to the specification.
		node_ptr spec_context, old_formula, tmp1;
		if (node_get_type(formula_expr) == CONTEXT) {
			spec_context = car(formula_expr);
			old_formula = cdr(formula_expr);
			tmp1= new_node(AA, old_formula, Nil);
			setcdr(formula_expr, tmp1);
		}
		else {
			spec_context = Nil;
			old_formula = formula_expr;
			tmp1= new_node(AA, old_formula, Nil);
			formula_expr = tmp1;

			if(car(parent)==old_formula) setcar(parent, tmp1);
			else if(cdr(parent)==old_formula) setcdr(parent, tmp1);
			else{rpterr("Eckl_explain_recur(): the old formula is not the parent's child.\n"); nusmv_exit(1);}
		}
	}
	Eckl_spec_unite_path_and_temporal_quantifiers(formula_expr, Nil);
	Eckl_spec_eliminate_A_G_F(formula_expr, Nil);
//--------------------------------------------------
  yylineno = node_get_lineno(formula_expr);
  switch (node_get_type(formula_expr)) {
  case CONTEXT: 
    return(Eckl_explain(fsm, path, cdr(formula_expr), car(formula_expr), formula_expr));
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case NOT:
  case IMPLIES:
  case IFF:
    new_path = Eckl_explain(fsm, path, car(formula_expr), context, formula_expr);
    if (new_path != Nil) return(new_path);
    return(Eckl_explain(fsm, path, cdr(formula_expr), context, formula_expr));
  case EX:
    a1 = Eckl_eval_spec(fsm, car(formula_expr), context, formula_expr);
    set_the_node(formula_expr);
    new_path = ex_explain(fsm, path, a1);
    bdd_free(dd_manager, a1);
    if (new_path != Nil) {
      node_ptr q = Eckl_explain(fsm, new_path, car(formula_expr), context, formula_expr);

      if (q) return(q);
    }
    return(new_path);
  case AX:
    return(Eckl_explain(fsm, path, find_node(NOT, find_node(EX, find_node(NOT, car(formula_expr), Nil), Nil),
                                     Nil), context, Nil));
  case EF:
    return(Eckl_explain(fsm, path, find_node(EU, one_number, car(formula_expr)), context, Nil));
  case AG:
    return(Eckl_explain(fsm, path, find_node(NOT, find_node(EU, one_number,
                                                   find_node(NOT, car(formula_expr), Nil)),
                                     Nil), context, Nil));
  case EG:
    a1 = Eckl_eval_spec(fsm, car(formula_expr), context, formula_expr);
    set_the_node(formula_expr);
    new_path = eg_explain(fsm, path, a1);
    bdd_free(dd_manager, a1);
    return(new_path);
  case AF:
    /* AF g and !EG !g are equivalent. */
    return (Eckl_explain(fsm, path, find_node(NOT, find_node(EG, find_node(NOT, car(formula_expr), Nil), Nil),
                                      Nil), context, formula_expr));
  case EU:
    a1 = Eckl_eval_spec(fsm, car(formula_expr), context, formula_expr);
    a2 = Eckl_eval_spec(fsm, cdr(formula_expr), context, formula_expr);
    set_the_node(formula_expr);
    new_path = eu_explain(fsm, path, a1, a2);
    bdd_free(dd_manager, a2);
    bdd_free(dd_manager, a1);
    if (new_path != Nil) {
      node_ptr q = Eckl_explain(fsm, new_path, cdr(formula_expr), context, formula_expr);

      if (q != Nil) return(q);
    }
    return(new_path);
  case AU:
    /* A[f U g] and !(E[!g U (!g & !f)] | EG !g) are equivalent. */
    return (Eckl_explain(fsm, path, find_node
		    (NOT, find_node
		     (OR, find_node
		      (EU, find_node
		       (NOT, cdr(formula_expr), Nil), find_node
		       (AND, find_node
			(NOT, car(formula_expr), Nil), find_node
			(NOT, cdr(formula_expr), Nil))), find_node
		      (EG, find_node
		       (NOT, cdr(formula_expr), Nil), Nil)), Nil),
		    context, Nil));

	//  case AA:
	case EE:
		isLTL=Eckl_spec_is_LTL_formula(car(formula_expr), context);
		if(isLTL==1){
//			return Eckl_eval_E_LTL_formula(fsm, formula_expr, context, parent);
		} else { //isLTL != 1
//			return Eckl_eval_E_K_C_MaxSubformulas(fsm, formula_expr, context, parent);
		}

  case ATOM:
    {
      node_ptr name  = find_node(DOT, context, find_atom(formula_expr));
      node_ptr temp1 = lookup_param_hash(name);
      node_ptr temp2 = lookup_symbol_hash(name);
      bdd_ptr  temp3 = (bdd_ptr)lookup_constant_hash(find_atom(formula_expr));

      if((temp1 && temp2) || (temp2 && temp3) || (temp3 && temp1))
	rpterr("atom \"%s\" is ambiguous", str_get_text(node_get_lstring(formula_expr)));
      if (temp1) return(Eckl_explain(fsm, path, temp1, context, Nil));
      if (temp3) return(Nil);
    } /* fall through on purpose here */
  case DOT:
  case ARRAY:
    {
      node_ptr t = eval_struct(formula_expr, context);
      node_ptr v = lookup_symbol_hash(t);

      if (v != Nil) return(Eckl_explain(fsm, path, v, context, Nil));
      return(Nil);
    }
  default:
    return(Nil);
  }
}

/**Function********************************************************************

  Synopsis           [Compile formula E(LTL subformula) into BDD.]

  Description        [n must be of the form E(LTL subformula).]
  
  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
/*
bdd_ptr Eckl_explain_E_LTL_formula(Fsm_BddPtr fsm, node_ptr formula_expr, node_ptr context, node_ptr parent)
{
	int i;
	if (n == Nil) return(bdd_one(dd_manager));
	if(Eckl_spec_is_LTL_formula(car(formula_expr), context)!=1) {
		rpterr("Eckl_explain_E_LTL_formula(): the node car(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "E(LTL): evaluating E( ");
		print_ltlspec(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " )\n");
	}
	
	//(1) Save the original status before checking E(n)
	Eckl_SaveStatus();
	
	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(car(formula_expr), context);
	// Builds the ADD list representing real_state_variables 
	build_real_state_variables();

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, car(formula_expr), context, &AuxiTR, &AuxiJF);
	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);
	
	//(4) create the BDD of fairness constraint according to the justice formulas
	bdd_ptr CF;  //the BDD of fairness constraint
//	CF = Eckl_eval_FairnessConstraint(fsm, &AuxiJF);
	CF = eg(fsm, bdd_one(dd_manager));
	if(CF == (bdd_ptr)NULL) {
		rpterr("Eckl_explain_E_LTL_formula(): CF == NULL.\n");
		nusmv_exit(1);
	}

	//(5) Check E(n) = Exist(AuxiVars)( CF & LTL2Bool(n) )
	//compute the cube of auxiliary variables
	bdd_ptr AuxiVars_cube, tmp_bdd, res_bdd;
	AuxiVars_cube = Eckl_eval_AuxiVars_Cube();
	if(AuxiVars_cube == (bdd_ptr)NULL) {
		rpterr("Eckl_explain_E_LTL_formula(): AuxiVars_Cube == NULL.\n");
		nusmv_exit(1);
	}
	tmp_bdd = Eckl_explain_LTL2Bool(fsm, car(n), context);
	if(tmp_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_explain_E_LTL_formula(): The BDD of LTL2Bool(car(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_and_accumulate(dd_manager, &tmp_bdd, CF);
	res_bdd = bdd_forsome(dd_manager, tmp_bdd, AuxiVars_cube);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_explain_E_LTL_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, AuxiVars_cube);
	bdd_free(dd_manager, CF);

	//(6) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	// Updates the ADD list representing real_state_variables 
	build_real_state_variables();
	
	return(res_bdd);
}
*/





