/**CFile***********************************************************************

  FileName    [ecklEval.c]

  PackageName [eckl]

  Synopsis    [ECKLn to BDD compiler]

  Description [In this file there is the code to compile ECKLn formulas
  into BDD and the code to call the model checking algorithms.]

  SeeAlso     [ecklMc.c ecklExplain.c]

  Author      [Xiangyu Luo]

  Copyright   [
  This file is part of the ``eckl'' package of MCTK version 1.
  Copyright (C) 2003-2004 by Multi-Agent System Research Group in
  Sun Yat-sen University, Guangzhou, China.

  MCTK version 1 is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  MCTK version 1 is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA.

  For more information of MCTK see <http://agent.sysu.edu.cn>
  or email to <isp03lxy@student.zsu.edu.cn>.
  Please report bugs to <isp03lxy@student.zsu.edu.cn>.

  To contact the MCTK development board, email to <isp03lxy@student.zsu.edu.cn>. ]

******************************************************************************/

#include "compileInt.h"
#include "ecklInt.h"
#include "ltlInt.h"


/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/
typedef bdd_ptr (*BDDPFDB)(DdManager *, bdd_ptr);
typedef bdd_ptr (*BDDPFFB)(Fsm_BddPtr, bdd_ptr);
typedef bdd_ptr (*BDDPFDBB)(DdManager *, bdd_ptr, bdd_ptr);
typedef bdd_ptr (*BDDPFFBB)(Fsm_BddPtr, bdd_ptr, bdd_ptr);
typedef bdd_ptr (*BDDPFDBII)(DdManager *, bdd_ptr, int, int);
typedef bdd_ptr (*BDDPFFBII)(Fsm_BddPtr, bdd_ptr, int, int);
typedef bdd_ptr (*BDDPFDBBII)(DdManager *, bdd_ptr, bdd_ptr, int, int);
typedef bdd_ptr (*BDDPFFBBII)(Fsm_BddPtr, bdd_ptr, bdd_ptr, int, int);

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/
void Eckl_spec_eliminate_A_G_F ARGS((node_ptr, node_ptr));

static int eval_compute_recur ARGS((Fsm_BddPtr, node_ptr, node_ptr));
bdd_ptr Eckl_unary_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFDB op, bdd_ptr arg,
                            int resflag, int argflag);
bdd_ptr Eckl_binary_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFDBB op, bdd_ptr arg1, bdd_ptr arg2,
                             int resflag, int argflag1, int argflag2);
bdd_ptr Eckl_unary_mod_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFFB op, bdd_ptr arg,
                                int resflag, int argflag);
bdd_ptr Eckl_binary_mod_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFFBB op, bdd_ptr arg1, bdd_ptr arg2,
                                 int resflag, int argflag1, int argflag2);
bdd_ptr Eckl_binary_mod_bdd_op_ns(Fsm_BddPtr fsm, DdManager * dd, BDDPFFBB op, bdd_ptr arg1, bdd_ptr arg2,
                                    int resflag, int argflag1, int argflag2);
bdd_ptr ternary_mod_bdd_op ARGS((Fsm_BddPtr, DdManager *, BDDPFFBII, node_ptr, int, int, node_ptr));
bdd_ptr quad_mod_bdd_op ARGS((Fsm_BddPtr, DdManager *, BDDPFFBBII, node_ptr, int, int, int, node_ptr));
static bdd_ptr eval_sign ARGS((bdd_ptr a, int flag));

static node_ptr bak_Eckl_LTL2bool_recur(node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_LTL2Bool(Fsm_BddPtr fsm, node_ptr n, node_ptr context);
void Eckl_clear_JustFormulas(structJusticeFormulas * JF);
bdd_ptr bak_old_Eckl_eval_FairnessConstraint(Fsm_BddPtr fsm, structJusticeFormulas * JF);
static int Eckl_new_AuxiTransRelation_JustFormulas_recur(Fsm_BddPtr fsm, node_ptr n, node_ptr context, bdd_ptr * AuxiTR, structJusticeFormulas * JF);
void Eckl_new_AuxiTransRelation_JustFormulas(Fsm_BddPtr fsm, node_ptr n, node_ptr context, bdd_ptr * AuxiTR, structJusticeFormulas * JF);
bdd_ptr Eckl_eval_E_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_K_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_K_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_EKCBDI_MaxSubformulas(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
node_ptr Eckl_spec_pretreatment(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
static bdd_ptr Eckl_eval_spec_recur(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_spec(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
static bdd_ptr Eckl_eval_CTL_spec_recur(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_CTL_spec(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eg_specify_justices(Fsm_BddPtr fsm, bdd_ptr g, node_ptr justices);
void Eckl_ComputeCompassion(Fsm_BddPtr fsm, node_ptr cc, bdd_ptr f, bdd_ptr * res_bdd);
bdd_ptr Eckl_ComputeFairStates(Fsm_BddPtr fsm);
void Eckl_spec_eliminate_redundant_NOT(node_ptr n, node_ptr context);
void Eckl_get_Compassions_recur(node_ptr Compassion_formulas, node_ptr formula_parent, node_ptr Compassion_bdds);
void Eckl_get_Compassions(Fsm_BddPtr fsm);
StructModuleInstantiation * Eckl_lookup_ModInst(node_ptr mod_name);
bdd_ptr Eckl_GetTrans(Fsm_BddPtr fsm);
bdd_ptr Eckl_compute_reachable_states(Fsm_BddPtr fsm);
bdd_ptr Eckl_eval_C_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_C_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);

bdd_ptr Eckl_eval_BDI_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent, int BDI_operator);
bdd_ptr Eckl_eval_B_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_D_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_I_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);

bdd_ptr Eckl_eval_BDI_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent, int BDI_operator);
bdd_ptr Eckl_eval_B_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_D_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);
bdd_ptr Eckl_eval_I_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent);

bdd_ptr Eckl_compute_BD_diff_reachable_states(Fsm_BddPtr fsm, node_ptr agent_name);
bdd_ptr Eckl_eval_FairnessConstraint_for_Desire(Fsm_BddPtr fsm, node_ptr agent_name, int FC_ID);
bdd_ptr CTLK_eval_K_bool_formula(node_ptr agent_name, bdd_ptr states_bdd, bdd_ptr f_bdd);
bdd_ptr SNP_eval_K_variable(node_ptr agent_name, bdd_ptr states_bdd, node_ptr var_name);
bdd_ptr Eckl_eval_K_variable_T1(node_ptr agent_name, bdd_ptr states_bdd, node_ptr var_name);
void Eckl_print_bdd_indexs_in_cube(bdd_ptr cube_bdd);
bdd_ptr Eckl_eval_K_variable_T2(node_ptr agent_name, bdd_ptr states_bdd, node_ptr var_name);
bdd_ptr SNP_evaluation(Fsm_BddPtr fsm);
bdd_ptr WhatSum_evaluation(Fsm_BddPtr fsm);
bdd_ptr MuddyChildren_evaluation(Fsm_BddPtr fsm);
bdd_ptr CTLK_eval_C_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, bdd_ptr states_bdd, bdd_ptr phi_bdd);


/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/
extern bdd_ptr Eckl_eval_AuxiVars_Cube();
extern char * Eckl_get_string(node_ptr n);
extern char *mystrcat(char *s1, char *s2);
extern structCompassionFormulas Eckl_Compassions;  //the var list of compassion formulas
extern node_ptr Eckl_MaxSubformula_new_one_variable(char *strvar, bdd_ptr MSF_bdd);
extern node_ptr Eckl_lookup_VarIndex_hash(node_ptr x);


/**Function********************************************************************

  Synopsis           [Convert a integer number to a string.]

  Description        [Convert a integer number to a string.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
extern char *itoa(int num)
{
  static char d2c[] = {'0','1','2','3','4','5','6','7','8','9'};
  char *ret;
  int i,j,d,n;
  n = num;
  if (n == 0) {
    d = 1;
  }
  else {
    for (d = 0; n != 0; d++)
      n = n/10;
  }
  /*  printf("num = %d, d = %d\n",num,d); */
  ret = (char *)malloc(sizeof(char)*(d+1));
  n = num;
  if (n == 0) {
    ret[0] = '0';
    ret[1] = '\0';
  }
  else {
    for (i = 0; n != 0; i++) {
      j = n % 10;
      ret[d-i-1] = d2c[j];
      n = n / 10;
    }
    ret[d] = '\0';
  }
  /*  printf("char num = %s\n",ret); */
 return(ret);
}

/**Function********************************************************************

  Synopsis           [Get the string of a node's type.]

  Description        [Get the string of a node's type.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
extern char *node_get_type_string(short int nt)
{
	switch (nt) {
		case VAR: return "VAR";
		case CONS: return "VAR";


		case OR: return "OR";
		case AND: return "AND";
//		case IMPLY: return "IMPLY";
//		case EQUIV: return "EQUIV";
//		case NEG: return "NEG";
		case TWODOTS: return "TWODOTS";
//		case FUTURE: return "FUTURE";
//		case GLOBAL: return "GLOBAL";
		case UNTIL: return "UNTIL";
		case RELEASES: return "RELEASES";
		case NEXT: return "NEXT";
//		case ONCE: return "ONCE";
//		case HISTORY: return "HISTORY";
		case SINCE: return "SINCE";
		case TRIGGERED: return "TRIGGERED";
//		case PREV: return "PREV";
//		case NOTPREVNOT: return "NOTPREVNOT";
		case PLUS: return "PLUS";
		case MINUS: return "MINUS";
		case TIMES: return "TIMES";
		case DIVIDE: return "DIVIDE";
		case MOD: return "MOD";
		case EQUAL: return "EQUAL";
		case NOTEQUAL: return "NOTEQUAL";
		case LE: return "LE";
		case GE: return "GE";
		case LT: return "LT";
		case GT: return "GT";
		case UNION: return "UNION";
		case SETIN: return "SETIN";
		case UMINUS: return "UMINUS";
		case ATOM: return "ATOM";
		case NUMBER: return "NUMBER";
		case CASE: return "CASE";
		case ESAC: return "ESAC";
		case XOR: return "XOR";
		case XNOR: return "XNOR";

		default:  return itoa(nt);
	}
}


/**Function********************************************************************

  Synopsis           [Unite the path quantifier and following temporal quantifier into one CTL quantifer,
  such as E X f --> EX f, A f U g --> AU(f, g)]

  Description        []

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_spec_unite_path_and_temporal_quantifiers(node_ptr n, node_ptr context)
{
	node_ptr tmp1, tmp2, tmp3;
	boolean united;

	if (n == Nil) return;

	Eckl_spec_eliminate_redundant_NOT(n, context);

	switch (node_get_type(n)){
	case CONTEXT:
		Eckl_spec_unite_path_and_temporal_quantifiers(cdr(n),car(n));
		break;
	case AA:
	case EE:
		united=false;
		switch(node_get_type(car(n))){
			case OP_NEXT:
				if(node_get_type(n)==AA) n->type=AX; else n->type=EX;
				setcar(n, car(car(n)));
				united=true;
				break;
			case OP_FUTURE:
				if(node_get_type(n)==AA) n->type=AF; else n->type=EF;
				setcar(n, car(car(n)));
				united=true;
				break;
			case OP_GLOBAL:
				if(node_get_type(n)==AA) n->type=AG; else n->type=EG;
				setcar(n, car(car(n)));
				united=true;
				break;
			case UNTIL:
				if(node_get_type(n)==AA) n->type=AU; else n->type=EU;
				setcdr(n, cdr(car(n)));
				setcar(n, car(car(n)));
				united=true;
				break;

			//NOT
			case NOT:
			{
				node_ptr not_child=car(car(n));
				switch(node_get_type(not_child)){
					case OP_NEXT:  //P!X f <--> PX !f
						if(node_get_type(n)==AA) n->type=AX; else n->type=EX;
						setcar(n, new_node(NOT, car(not_child), Nil));
						united=true;
						break;
					case OP_FUTURE:	//P!F f <--> PG !f
						if(node_get_type(n)==AA) n->type=AG; else n->type=EG;
						setcar(n, new_node(NOT, car(not_child), Nil));
						united=true;
						break;
					case OP_GLOBAL:	//P!G f <--> PF !f
						if(node_get_type(n)==AA) n->type=AF; else n->type=EF;
						setcar(n, new_node(NOT, car(not_child), Nil));
						united=true;
						break;
					//case UNTIL:
				}
				break;
			}
		}


		/*
		//after the uniting operation, if the f in PT(f) is not a state formula, then add A quantifier to f, namely PT(A f)
		if(united){
			node_ptr f = car(n);
			if(Eckl_spec_is_state_formula(f, context)!=1)
				setcar(n, new_node(AA, f, Nil));
		}
		*/

		Eckl_spec_unite_path_and_temporal_quantifiers(car(n), context);
		Eckl_spec_unite_path_and_temporal_quantifiers(cdr(n), context);
		break;

	case AND:
	case OR:
	case XOR:
	case XNOR:
	case NOT:
	case IMPLIES:
	case IFF:

	case OP_NEXT:
	case OP_FUTURE:
	case OP_GLOBAL:
	case UNTIL:

	case EX:
	case AX:
	case EF:
	case AG:
	case AF:
	case EG:
	case EU:
	case AU:
		Eckl_spec_unite_path_and_temporal_quantifiers(car(n), context);
		Eckl_spec_unite_path_and_temporal_quantifiers(cdr(n), context);
		break;
	case KNOW:
	case CKNOW:
	case BELIEVE:
	case DESIRE:
	case INTEND:
		Eckl_spec_unite_path_and_temporal_quantifiers(cdr(n), context);
		break;
	default:
	{ /* for all the other we call the eval, and convert the result from ADD to BDD. */
		return ;
	}
	}
}


/**Function********************************************************************

  Synopsis           [Convert a ECKL formula n to a formula containing no ECKL temporal
  operators other than E, X and U.]

  Description        [Convert a ECKL formula n to a formula containing no ECKL temporal
  operators other than E, X and U.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_spec_eliminate_A_G_F(node_ptr n, node_ptr context)
{
  node_ptr tmp1, tmp2, tmp3;

  if (n == Nil) return;
  switch (node_get_type(n)){
  case CONTEXT:
    Eckl_spec_eliminate_A_G_F(cdr(n),car(n));
    break;
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case NOT:
  case IMPLIES:
  case IFF:
    Eckl_spec_eliminate_A_G_F(car(n), context);
    Eckl_spec_eliminate_A_G_F(cdr(n), context);
    break;
  //LTL temporal operators
  case AA:
    tmp3 = car(n);
    tmp1 = new_node(NOT, car(n), Nil);
    tmp2 = new_node(EE, tmp1, Nil);
    n->type = NOT;
    setcar(n, tmp2);

	Eckl_spec_eliminate_redundant_NOT(n, context);
    Eckl_spec_eliminate_A_G_F(n, context);
    break;
  case OP_GLOBAL:
    tmp3 = car(n);
    tmp1 = new_node(NOT, car(n), Nil);
    tmp2 = new_node(OP_FUTURE, tmp1, Nil);
    n->type = NOT;
    setcar(n, tmp2);

	Eckl_spec_eliminate_redundant_NOT(n, context);
    Eckl_spec_eliminate_A_G_F(n, context);
    break;
  case OP_FUTURE:
    tmp3 = car(n);
    tmp1 = new_node(TRUEEXP, Nil, Nil);
    n->type = UNTIL;
    setcar(n, tmp1);
    setcdr(n, tmp3);

    Eckl_spec_eliminate_A_G_F(n, context);
    break;

  case EE:
  case OP_NEXT:
  case UNTIL:
/*
  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:*/
    Eckl_spec_eliminate_A_G_F(car(n), context);
    Eckl_spec_eliminate_A_G_F(cdr(n), context);
    break;
  case KNOW:
  case CKNOW:
  case BELIEVE:
  case DESIRE:
  case INTEND:
    Eckl_spec_eliminate_A_G_F(cdr(n), context);
    break;
  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */
      return ;
    }
  }
}

/**Function********************************************************************

  Synopsis           [Eliminate all of the redundant NOT operators]

  Description        [eliminate redundant NOT operators.]

  SideEffects        [None]

  SeeAlso            []

******************************************************************************/
void Eckl_spec_eliminate_redundant_NOT(node_ptr n, node_ptr context)
{
  node_ptr tmp1, tmp2, tmp3;

  if (n == Nil) return;
  switch (node_get_type(n)){
  case CONTEXT:
    Eckl_spec_eliminate_redundant_NOT(cdr(n),car(n));
    break;
  case NOT:
  {
	//count the number of NOT operators to not_count
	int not_count=1;
	node_ptr node = n;
	while(car(node)!=(node_ptr)Nil && node_get_type(car(node))==NOT){
		not_count++;
		node = car(node);
	}
	//eliminate redundant NOT operators
	node = car(node); 	//node is the operand of the last NOT operator
	if(not_count>1){
		if((not_count % 2)==0){ //even number of NOT operators
			n->type = node_get_type(node);
			setcar(n, car(node));
			setcdr(n, cdr(node));
		}else{  //odd number of NOT operators
			setcar(n, node);
		}
	}
	Eckl_spec_eliminate_redundant_NOT(node, context);
	break;
  }
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case IMPLIES:
  case IFF:
  case AA:
  case OP_GLOBAL:
  case OP_FUTURE:
  case EE:
  case OP_NEXT:
  case UNTIL:
/*  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:*/
    Eckl_spec_eliminate_redundant_NOT(car(n), context);
    Eckl_spec_eliminate_redundant_NOT(cdr(n), context);
    break;
  case KNOW:
  case CKNOW:
  case BELIEVE:
  case DESIRE:
  case INTEND:
    Eckl_spec_eliminate_redundant_NOT(cdr(n), context);
    break;
  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */
      return ;
    }
  }
}

/**Function********************************************************************

  Synopsis           [Updating the specification for compassion as the specification's antecedent.]

  Description        [Let Af g represents the A g under justice & compassion fairness constraint, A g represents
  								A g only under the justice fairness constraint, <p_1, q_1>, ... , <p_k, q_k> is the compassion, hence,
  								Af g <==> A( ((GF p_1 -> GF q_1) & ... & (GF p_k -> GF q_k)) -> g )
  								Ef g <==> E( ((GF p_1 -> GF q_1) & ... & (GF p_k -> GF q_k)) & g )
  								]

  SideEffects        [None]

  SeeAlso            []

******************************************************************************/
void Eckl_spec_updating_for_Compassion_as_SpecAntecedent(node_ptr n, node_ptr context)
{
	node_ptr tmp1, tmp2, tmp3;

	if (n == Nil) return;
	switch (node_get_type(n)){
	case CONTEXT:
		Eckl_spec_updating_for_Compassion_as_SpecAntecedent(cdr(n),car(n));
		break;
	case AA:
	{
		//res = ((GF p_1 -> GF q_1) & ... & (GF p_k -> GF q_k))
		node_ptr res=(node_ptr)Nil;
		int i;
		for(i=0; i<Eckl_Compassions.count; i+=2){
			node_ptr p, q;
			p = Eckl_Compassions.CF[i].n;
			q = Eckl_Compassions.CF[i+1].n;
			tmp1 = new_node(OP_GLOBAL, new_node(OP_FUTURE, p, Nil), Nil);
			tmp2 = new_node(OP_GLOBAL, new_node(OP_FUTURE, q, Nil), Nil);
			tmp3 = new_node(IMPLIES, tmp1, tmp2);

			if(res==(node_ptr)Nil)
				res = tmp3;
			else
				res = new_node(AND, res, tmp3);
		}

		//n = A(res -> car(n))
		node_ptr n_oldchild=car(n);
		setcar(n, new_node(IMPLIES, res, n_oldchild));
		/*
		fprintf(nusmv_stdout, "Compassion:");
		print_node(nusmv_stdout, n);
		fprintf(nusmv_stdout, "\n");
		*/
		Eckl_spec_updating_for_Compassion_as_SpecAntecedent(n_oldchild, context);

		break;
	}
	case EE:
	{
		//res = ((GF p_1 -> GF q_1) & ... & (GF p_k -> GF q_k))
		node_ptr res=(node_ptr)Nil;
		int i;
		for(i=0; i<Eckl_Compassions.count; i+=2){
			node_ptr p, q;
			p = Eckl_Compassions.CF[i].n;
			q = Eckl_Compassions.CF[i+1].n;
			tmp1 = new_node(OP_GLOBAL, new_node(OP_FUTURE, p, Nil), Nil);
			tmp2 = new_node(OP_GLOBAL, new_node(OP_FUTURE, q, Nil), Nil);
			tmp3 = new_node(IMPLIES, tmp1, tmp2);

			if(res==(node_ptr)Nil)
				res = tmp3;
			else
				res = new_node(AND, res, tmp3);
		}

		//n = E(res & car(n))
		node_ptr n_oldchild=car(n);
		setcar(n, new_node(AND, res, n_oldchild));
		/*
		fprintf(nusmv_stdout, "Compassion:");
		print_node(nusmv_stdout, n);
		fprintf(nusmv_stdout, "\n");
		*/
		Eckl_spec_updating_for_Compassion_as_SpecAntecedent(n_oldchild, context);

		break;
	}
	case NOT:
	case AND:
	case OR:
	case XOR:
	case XNOR:
	case IMPLIES:
	case IFF:
	case OP_GLOBAL:
	case OP_FUTURE:
	case OP_NEXT:
	case UNTIL:
/*	case EX:
	case AX:
	case EF:
	case AG:
	case AF:
	case EG:
	case EU:
	case AU:*/
		Eckl_spec_updating_for_Compassion_as_SpecAntecedent(car(n), context);
		Eckl_spec_updating_for_Compassion_as_SpecAntecedent(cdr(n), context);
		break;
	case KNOW:
	case CKNOW:
	case BELIEVE:
	case DESIRE:
	case INTEND:
		Eckl_spec_updating_for_Compassion_as_SpecAntecedent(cdr(n), context);
		break;
	default:
	{ /* for all the other we call the eval, and convert the result from ADD to BDD. */
		return ;
	}
	}
}


/**Function********************************************************************

  Synopsis           [Judge whether or not a ECKL formula n is a pure LTL formula]

  Description        [Judge whether or not a ECKL formula n is a pure LTL formula
    return 1 if n is a pure LTL formula
    return 0 if n is NOT a pure LTL formula
    return -1 if n is Nil
  ]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
int Eckl_spec_is_LTL_formula(node_ptr n, node_ptr context)
{
  int r1, r2;

  if (n == Nil) return -1;
  switch (node_get_type(n)){
  case CONTEXT:
    return Eckl_spec_is_LTL_formula(cdr(n),car(n));

  //path quatifiers
  case AA:
  case EE:

/*  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:*/
  case KNOW:
  case CKNOW:
  case BELIEVE:
  case DESIRE:
  case INTEND:

	return 0;

  //unary operators
  case NOT:
  case OP_GLOBAL:
  case OP_FUTURE:
  case OP_NEXT:
    return Eckl_spec_is_LTL_formula(car(n), context);

  //binary operators
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case IMPLIES:
  case IFF:
  case UNTIL:
    r1 = Eckl_spec_is_LTL_formula(car(n), context);
    r2 = Eckl_spec_is_LTL_formula(cdr(n), context);
    if (r1==1 && r2==1) return 1;
    else if(r1==-1 || r2==-1) return -1;
    else return 0;
  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */
      return 1;
    }
  }
}

/**Function********************************************************************

  Synopsis           [Judge whether or not an ECKL formula n is a pure CTL formula]

  Description        [Judge whether or not an ECKL formula n is a pure CTL formula
    return 1 if n is a pure CTL formula
    return 0 if n is NOT a pure CTL formula
    return -1 if n is Nil
  ]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
int Eckl_spec_is_CTL_formula_recur(node_ptr n, node_ptr context, node_ptr parent, node_ptr grandparent)
{
  int r1, r2;

  if (n == Nil) return -1;
  switch (node_get_type(n)){
  case CONTEXT:
    return Eckl_spec_is_CTL_formula_recur(cdr(n),car(n), n, parent);

  //path quatifiers
  case AA:
  case EE:
    if (node_get_type(car(n))==OP_GLOBAL ||
	    node_get_type(car(n))==OP_FUTURE ||
		node_get_type(car(n))==OP_NEXT)
	{
		//n = PG car(n), PF car(n),PX car(n)
		return Eckl_spec_is_CTL_formula_recur(car(car(n)), context, car(n), n);
	}
	else if (node_get_type(car(n))==UNTIL)
	{
	  //n = P(car(n) U cdr(n))
	  r1 = Eckl_spec_is_CTL_formula_recur(car(car(n)), context, car(n), n);
      r2 = Eckl_spec_is_CTL_formula_recur(cdr(car(n)), context, car(n), n);
	  if (r1==1 && r2==1) return 1;
	  else if(r1==-1 || r2==-1) return -1;
	  else return 0;
	}
	else if (node_get_type(car(n))==NOT)
	{
	  if (node_get_type(car(car(n)))==OP_GLOBAL ||
	      node_get_type(car(car(n)))==OP_FUTURE ||
		  node_get_type(car(car(n)))==OP_NEXT)
      {
		return Eckl_spec_is_CTL_formula_recur(car(car(car(n))), context, car(car(n)), car(n));
	  }
	  else if (node_get_type(car(car(n)))==UNTIL)
	  {
	    r1 = Eckl_spec_is_CTL_formula_recur(car(car(car(n))), context, car(car(n)), car(n));
        r2 = Eckl_spec_is_CTL_formula_recur(cdr(car(car(n))), context, car(car(n)), car(n));
	    if (r1==1 && r2==1) return 1;
	    else if(r1==-1 || r2==-1) return -1;
		else return 0;
	  } else return 0;
	} else return 0;

/*  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:*/
  case KNOW:
  case CKNOW:
  case BELIEVE:
  case DESIRE:
  case INTEND:
	return 0;

  //unary operators
  case NOT:
    return Eckl_spec_is_CTL_formula_recur(car(n), context, n, parent);

  //binary operators
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case IMPLIES:
  case IFF:
    r1 = Eckl_spec_is_CTL_formula(car(n), context, n, parent);
    r2 = Eckl_spec_is_CTL_formula(cdr(n), context, n, parent);
    if (r1==1 && r2==1) return 1;
    else if(r1==-1 || r2==-1) return -1;
    else return 0;

  //-------------------------------------------------------
  // temporal operators
  //-------------------------------------------------------
  case OP_GLOBAL:
  case OP_FUTURE:
  case OP_NEXT:
  case UNTIL:
    if (parent==Nil)
	{ //p U q: there is NOT any operator before the temporal operator
	  return 0;
	}
	else if ( node_get_type(parent)==AA || node_get_type(parent)==EE )
	{ //parent = P(p U q)
	  if (node_get_type(n)==UNTIL)
	  {
	    r1 = Eckl_spec_is_CTL_formula_recur(car(n), context, n, parent);
    	r2 = Eckl_spec_is_CTL_formula_recur(cdr(n), context, n, parent);
	    if (r1==1 && r2==1) return 1;
	    else if(r1==-1 || r2==-1) return -1;
	    else return 0;
	  }
	  else   //n==OP_GLOBAL, OP_FUTURE, or OP_NEXT:
	  {
  	    return Eckl_spec_is_CTL_formula_recur(car(n), context, n, parent);
	  }
	}
	else if ( node_get_type(parent)==NOT )
	{ //parent = !n
  	  if ( grandparent==Nil )
	  { //there is not any operator before !n
	    return 0;
	  }
	  else if ( node_get_type(grandparent)==AA || node_get_type(grandparent)==EE )
	  { //grandparent = P!n
		if (node_get_type(n)==UNTIL)
	  	{
	      r1 = Eckl_spec_is_CTL_formula_recur(car(n), context, n, parent);
    	  r2 = Eckl_spec_is_CTL_formula_recur(cdr(n), context, n, parent);
	      if (r1==1 && r2==1) return 1;
	      else if(r1==-1 || r2==-1) return -1;
	      else return 0;
	    }
	    else   //n==OP_GLOBAL, OP_FUTURE, or OP_NEXT:
	    {
  	      return Eckl_spec_is_CTL_formula_recur(car(n), context, n, parent);
	    }
  	  } else return 0;
	} else return 0;

  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */

	  //--------------------------------------------------------
	  // if n is a VAR and n is a new auxiable variable for a temporal formula(the prefix of n's string name is "MSFVAR{")
	  // then return 0, because n is exactly a non-CTL formula.
	  //--------------------------------------------------------
	  if (strncmp(Eckl_get_string(n), "MSFVAR{", 7)==0) /*node_get_type(n)==DOT &&*/
	  {
	    //fprintf(nusmv_stdout, " [%s] ", Eckl_get_string(n));
	    return 0;
	  }
	  else return 1;
    }
  }
}

/**Function********************************************************************

  Synopsis           [Judge whether or not an ECKL formula n is a pure CTL formula]

  Description        [Judge whether or not an ECKL formula n is a pure CTL formula
    return 1 if n is a pure CTL formula
    return 0 if n is NOT a pure CTL formula
    return -1 if n is Nil
  ]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
int Eckl_spec_is_CTL_formula(node_ptr n, node_ptr context)
{
  return Eckl_spec_is_CTL_formula_recur(n, context, Nil, Nil);
}

/**Function********************************************************************

  Synopsis           [Judge whether or not a ECKL formula n is a state formula]

  Description        [Judge whether or not a ECKL formula n is a state formula
    return 1 if n is a state formula
    return 0 if n is NOT a state formula
    return -1 if n is Nil
  ]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
int Eckl_spec_is_state_formula(node_ptr n, node_ptr context)
{
  int r1, r2;

  if (n == Nil) return;
  switch (node_get_type(n)){
  case CONTEXT:
    return Eckl_spec_is_state_formula(cdr(n),car(n));

  //path quatifiers
  case AA:
  case EE:

/*  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:*/

  case KNOW:  //ECKLn quatifier
  case CKNOW:  //ECKLn quatifier
  case BELIEVE:
  case DESIRE:
  case INTEND:

	return 1;

  //temporal operators
  case OP_GLOBAL:
  case OP_FUTURE:
  case OP_NEXT:
  case UNTIL:
    return 0;

  case NOT:
    return Eckl_spec_is_state_formula(car(n), context);

  //bool operators
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case IMPLIES:
  case IFF:
    r1 = Eckl_spec_is_state_formula(car(n), context);
    r2 = Eckl_spec_is_state_formula(cdr(n), context);
    if (r1==1 && r2==1) return 1;
    else if(r1==-1 || r2==-1) return -1;
    else return 0;
  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */
      return 1;
    }
  }
}

/**Function********************************************************************

  Synopsis           [Judge whether or not a ECKL formula n is a pure boolean formula, i.e.
  including only atom propositions and bool operators]

  Description        [Judge whether or not a ECKL formula n is a pure boolean formula
    return 1 if n is a boolean formula
    return 0 if n is NOT a boolean formula
    return -1 if n is Nil
  ]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
int Eckl_spec_is_bool_formula(node_ptr n, node_ptr context)
{
  int r1, r2;

  if (n == Nil) return;
  switch (node_get_type(n)){
  case CONTEXT:
    return Eckl_spec_is_bool_formula(cdr(n),car(n));

  //path quatifiers
  case AA:
  case EE:

/*  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:*/

  case KNOW:  //ECKLn quatifier
  case CKNOW:  //ECKLn quatifier
  case BELIEVE:
  case DESIRE:
  case INTEND:

  //temporal operators
  case OP_GLOBAL:
  case OP_FUTURE:
  case OP_NEXT:
  case UNTIL:
    return 0;

  case NOT:
    return Eckl_spec_is_bool_formula(car(n), context);

  //bool operators
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case IMPLIES:
  case IFF:
    r1 = Eckl_spec_is_bool_formula(car(n), context);
    r2 = Eckl_spec_is_bool_formula(cdr(n), context);
    if (r1==1 && r2==1) return 1;
    else if(r1==-1 || r2==-1) return -1;
    else return 0;
  default:
    {
      return 1;
    }
  }
}

/**Function********************************************************************

  Synopsis           [Find all of the maximal subformulas in the ECKL formula n.]

  Description        [Find all of the maximal subformulas in the ECKL formula n. the maximal subformulas of n
  is all of the subformula sn of n such that sn's main operator is E or K.
  NOTE:
  	n must be a legal ECKLn formula with maximal subformulas, its parent formula is of the form E(n) or K(n).]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_spec_find_MaxSubformulas(node_ptr n, node_ptr context, node_ptr parent, structMaxSubformulas * MSFs)
{
  int r1, r2;

  if (n == Nil) return;
  switch (node_get_type(n)){
  case CONTEXT:
    return Eckl_spec_find_MaxSubformulas(cdr(n),car(n), n, MSFs);

  //path quatifiers
  case AA:
  case EE:

/*  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:*/

  case KNOW:
  case CKNOW:
  case BELIEVE:
  case DESIRE:
  case INTEND:
		//create one maximal subformula
		MSFs->MSF[MSFs->count].parent = parent;
		MSFs->MSF[MSFs->count].n = n;
		MSFs->MSF[MSFs->count].context = context;
		MSFs->count++;
    return;

  //unary operators
  case NOT:
  case OP_GLOBAL:
  case OP_FUTURE:
  case OP_NEXT:
    return Eckl_spec_find_MaxSubformulas(car(n), context, n, MSFs);

  //binary operators
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case IMPLIES:
  case IFF:
  case UNTIL:

    Eckl_spec_find_MaxSubformulas(car(n), context, n, MSFs);
    Eckl_spec_find_MaxSubformulas(cdr(n), context, n, MSFs);
	return;
  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */
      return;
    }
  }
}


/**Function********************************************************************

  Synopsis           [Recursive step of <code>Eckl_eval_CTL_spec_recur()</code>.]

  Description        [Performs the recursive step of <code>Eckl_eval_CTL_spec_recur()</code>.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
static bdd_ptr Eckl_eval_CTL_spec_recur(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	bdd_ptr arg1, arg2, res;
	if (n == Nil) return(bdd_one(dd_manager));

	switch (node_get_type(n)){
	case CONTEXT:
		return(Eckl_eval_CTL_spec(fsm, cdr(n),car(n), n));
	case AND:
		set_the_node(n);
		arg1 = Eckl_eval_CTL_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_CTL_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_and, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case OR:
		set_the_node(n);
		arg1 = Eckl_eval_CTL_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_CTL_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case XOR:
		set_the_node(n);
		arg1 = Eckl_eval_CTL_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_CTL_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case XNOR:
		set_the_node(n);
		arg1 = Eckl_eval_CTL_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_CTL_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, 1, 1, -1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case NOT:
		set_the_node(n);
		arg1 = Eckl_eval_CTL_spec(fsm, car(n), context, n);
		res = Eckl_unary_bdd_op(fsm, dd_manager, bdd_not, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case IMPLIES:
		set_the_node(n);
		arg1 = Eckl_eval_CTL_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_CTL_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, arg1, arg2, 1, -1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case IFF:
		set_the_node(n);
		arg1 = Eckl_eval_CTL_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_CTL_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, -1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	/*====CTL subformula====
	case EX:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ex, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case AX:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ex, arg1, -1, -1);
		bdd_free(dd_manager, arg1);
		return(res);
	case EF:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ef, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case AG:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ef, arg1, -1, -1);
		bdd_free(dd_manager, arg1);
		return(res);
	case AF:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, eg, arg1, -1, -1);
		bdd_free(dd_manager, arg1);
		return(res);
	case EG:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, eg, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case EU:      //return(binary_mod_bdd_op(fsm, dd_manager, eu, n, 1, 1, 1, context));
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_mod_bdd_op(fsm, dd_manager, eu, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case AU:      //return(binary_mod_bdd_op(fsm, dd_manager, au, n, 1, 1, 1, context));
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_mod_bdd_op(fsm, dd_manager, au, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	//====================*/

	//  case AA:
	case EE:{
		switch (node_get_type(car(n)))
		{
			case OP_GLOBAL:
				set_the_node(n);
				arg1 = Eckl_eval_CTL_spec(fsm, car(car(n)), context, car(n));
				res = Eckl_unary_mod_bdd_op(fsm, dd_manager, eg, arg1, 1, 1);
				bdd_free(dd_manager, arg1);
				return(res);

			case OP_FUTURE:
				set_the_node(n);
				arg1 = Eckl_eval_CTL_spec(fsm, car(car(n)), context, car(n));
				res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ef, arg1, 1, 1);
				bdd_free(dd_manager, arg1);
				return(res);

			case OP_NEXT:
				set_the_node(n);
				arg1 = Eckl_eval_CTL_spec(fsm, car(car(n)), context, car(n));
				res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ex, arg1, 1, 1);
				bdd_free(dd_manager, arg1);
				return(res);

			case UNTIL: //n=E(arg1 U arg2)
				/*
				fprintf(nusmv_stdout, "Checking: ");
				Eckl_print_spec(nusmv_stdout, n);
				fprintf(nusmv_stdout, "...\n");
				*/

				set_the_node(n);
				arg1 = Eckl_eval_CTL_spec(fsm, car(car(n)), context, car(n));
				arg2 = Eckl_eval_CTL_spec(fsm, cdr(car(n)), context, car(n));

				if (arg1==bdd_one(dd_manager))
				{  //n=E(true U arg2)  <=> n=EF arg2
					res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ef, arg2, 1, 1);
				}
				else
				{  //n=E(arg1 U arg2)
					res = Eckl_binary_mod_bdd_op(fsm, dd_manager, eu, arg1, arg2, 1, 1, 1);
				}
				bdd_free(dd_manager, arg1);
				bdd_free(dd_manager, arg2);
				return(res);

			case NOT:
			{
				switch (node_get_type(car(car(n))))
				{
					case OP_GLOBAL:
						set_the_node(n);
						arg1 = Eckl_eval_CTL_spec(fsm, car(car(car(n))), context, car(car(n)));
						res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ef, arg1, 1, -1);
						bdd_free(dd_manager, arg1);
						return(res);

					case OP_FUTURE:
						set_the_node(n);
						arg1 = Eckl_eval_CTL_spec(fsm, car(car(car(n))), context, car(car(n)));
						res = Eckl_unary_mod_bdd_op(fsm, dd_manager, eg, arg1, 1, -1);
						bdd_free(dd_manager, arg1);
						return(res);

					case OP_NEXT:
						set_the_node(n);
						arg1 = Eckl_eval_CTL_spec(fsm, car(car(car(n))), context, car(car(n)));
						res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ex, arg1, 1, -1);
						bdd_free(dd_manager, arg1);
						return(res);

					case UNTIL:
						/*
						fprintf(nusmv_stdout, "Checking: ");
						Eckl_print_spec(nusmv_stdout, n);
						fprintf(nusmv_stdout, "...\n");
						*/

						set_the_node(n);
						arg1 = Eckl_eval_CTL_spec(fsm, car(car(car(n))), context, car(car(n)));
						arg2 = Eckl_eval_CTL_spec(fsm, cdr(car(car(n))), context, car(car(n)));

						if (arg1==bdd_one(dd_manager))
						{  //n=E !(true U arg2)  <=> n=EG !arg2
							res = Eckl_unary_mod_bdd_op(fsm, dd_manager, eg, arg2, 1, -1);
						}
						else
						{  //n=E !(arg1 U arg2) <=> !A(arg1 U arg2)
							res = Eckl_binary_mod_bdd_op(fsm, dd_manager, au, arg1, arg2, -1, 1, 1);
						}
						bdd_free(dd_manager, arg1);
						bdd_free(dd_manager, arg2);
						return(res);

					default:
						return(bdd_one(dd_manager));
				}

			}
			default:
				return(bdd_one(dd_manager));
		}
	}

	/*
	case KNOW:
	case CKNOW:
	case BELIEVE:
	case DESIRE:
	case INTEND:
	*/

	default:
	{ /* for all the other we call the eval, and convert the result from ADD to BDD. */
		/*
		fprintf(nusmv_stdout, "Checking: ");
		Eckl_print_spec(nusmv_stdout, n);
		fprintf(nusmv_stdout, "...");
		*/

		bdd_ptr res_bdd;
		add_ptr res_add = eval(n, context);

		if (res_add == NULL) {
			rpterr("Eckl_eval_CTL_spec: res = NULL after a call to \"eval\".");
			nusmv_exit(1);
		}
		res_bdd = add_to_bdd(dd_manager, res_add);
		add_free(dd_manager, res_add);

		//fprintf(nusmv_stdout, "Done.\n");

		return(res_bdd);
	}
	}
}
/**Function********************************************************************

  Synopsis           [Compile a CTL formula into BDD and performs Model Checking.]

  Description        [Compile a CTL formula into BDD and performs Model Checking.]

  SideEffects        []

  SeeAlso            [eval_compute]

******************************************************************************/
bdd_ptr Eckl_eval_CTL_spec(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	bdd_ptr res;
	int temp = yylineno;

	if (n == Nil) return(bdd_one(dd_manager));

	//Check ECKLn specification
	yylineno = node_get_lineno(n);
	res = Eckl_eval_CTL_spec_recur(fsm, n, context, parent);
	yylineno = temp;


	/*
	fprintf(nusmv_stdout, "Finished checking: ");
	Eckl_print_spec(nusmv_stdout, n);
	fprintf(nusmv_stdout, "\n");
	*/

	return(res);
}


/**Function********************************************************************

  Synopsis           [Compile a ECKLn formula into BDD and performs Model Checking.]

  Description        [Compile a ECKLn formula into BDD and performs Model Checking.]

  SideEffects        []

  SeeAlso            [eval_compute]

******************************************************************************/
bdd_ptr Eckl_eval_spec(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	bdd_ptr res;
	int temp = yylineno;

	if (n == Nil) return(bdd_one(dd_manager));

	//Check ECKLn specification
	yylineno = node_get_lineno(n);
	res = Eckl_eval_spec_recur(fsm, n, context, parent);
	yylineno = temp;

	return(res);
}


/**Function********************************************************************

  Synopsis           [Recursive step of <code>Eckl_eval_spec_recur()</code>.]

  Description        [Performs the recursive step of <code>Eckl_eval_spec_recur()</code>.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
static bdd_ptr Eckl_eval_spec_recur(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	int isLTL;
	bdd_ptr arg1, arg2, res;
	if (n == Nil) return(bdd_one(dd_manager));


	switch (node_get_type(n)){
	case CONTEXT:
		return(Eckl_eval_spec(fsm, cdr(n),car(n), n));
	case AND:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_and, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case OR:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case XOR:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case XNOR:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, 1, 1, -1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case NOT:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_bdd_op(fsm, dd_manager, bdd_not, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case IMPLIES:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, arg1, arg2, 1, -1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case IFF:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, -1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	/*====CTL subformula====
	case EX:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ex, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case AX:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ex, arg1, -1, -1);
		bdd_free(dd_manager, arg1);
		return(res);
	case EF:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ef, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case AG:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, ef, arg1, -1, -1);
		bdd_free(dd_manager, arg1);
		return(res);
	case AF:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, eg, arg1, -1, -1);
		bdd_free(dd_manager, arg1);
		return(res);
	case EG:
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		res = Eckl_unary_mod_bdd_op(fsm, dd_manager, eg, arg1, 1, 1);
		bdd_free(dd_manager, arg1);
		return(res);
	case EU:      //return(binary_mod_bdd_op(fsm, dd_manager, eu, n, 1, 1, 1, context));
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_mod_bdd_op(fsm, dd_manager, eu, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	case AU:      //return(binary_mod_bdd_op(fsm, dd_manager, au, n, 1, 1, 1, context));
		set_the_node(n);
		arg1 = Eckl_eval_spec(fsm, car(n), context, n);
		arg2 = Eckl_eval_spec(fsm, cdr(n), context, n);
		res = Eckl_binary_mod_bdd_op(fsm, dd_manager, au, arg1, arg2, 1, 1, 1);
		bdd_free(dd_manager, arg1);
		bdd_free(dd_manager, arg2);
		return(res);
	//====================*/

	//  case AA:
	case EE:{
		if (Eckl_get_CTLstar_algorithm_type()==2 && Eckl_spec_is_CTL_formula(n, context)==1)
		{
			//----------------------------------------------------------------
			//  CTL* model checking algorithm 2
			//  Using CTL model checking algorithm once the formula n is a CTL formula
			//----------------------------------------------------------------
			if (opt_verbose_level_ge(options, 0)) {
				fprintf(nusmv_stdout, " Evaluating as CTL for ");
				Eckl_print_spec(nusmv_stdout, n);
				fprintf(nusmv_stdout, "...");
			}

			return Eckl_eval_CTL_spec(fsm, n, context, parent);
		}
		else
		{
			isLTL=Eckl_spec_is_LTL_formula(car(n), context);
			if(isLTL==1){
				return Eckl_eval_E_LTL_formula(fsm, n, context, parent);
			} else { //isLTL != 1
				return Eckl_eval_EKCBDI_MaxSubformulas(fsm, n, context, parent);
			}
		}
	}

	case KNOW:{
		isLTL=Eckl_spec_is_LTL_formula(cdr(n), context);
		if(isLTL==1){
			if(Eckl_spec_is_bool_formula(cdr(n), context)==1)
				return Eckl_eval_K_bool_formula(fsm, n, context, parent);
			else
				return Eckl_eval_K_LTL_formula(fsm, n, context, parent);
		} else { //isLTL != 1
			return Eckl_eval_EKCBDI_MaxSubformulas(fsm, n, context, parent);
		}
	}

	case CKNOW:{
		isLTL=Eckl_spec_is_LTL_formula(cdr(n), context);
		if(isLTL==1){
			if(Eckl_spec_is_bool_formula(cdr(n), context)==1)
				return Eckl_eval_C_bool_formula(fsm, n, context, parent);
			else
				return Eckl_eval_C_LTL_formula(fsm, n, context, parent);
		} else { //isLTL != 1
			return Eckl_eval_EKCBDI_MaxSubformulas(fsm, n, context, parent);
		}
	}

	case BELIEVE:{
		isLTL=Eckl_spec_is_LTL_formula(cdr(n), context);
		if(isLTL==1){
			if(Eckl_spec_is_bool_formula(cdr(n), context)==1) {
				return Eckl_eval_B_bool_formula(fsm, n, context, parent);
				//return (bdd_one(dd_manager));
			} else {
				return Eckl_eval_B_LTL_formula(fsm, n, context, parent);
				//return (bdd_one(dd_manager));
			}
		} else { //isLTL != 1
			return Eckl_eval_EKCBDI_MaxSubformulas(fsm, n, context, parent);
		}
	}

	case DESIRE:{
		isLTL=Eckl_spec_is_LTL_formula(cdr(n), context);
		if(isLTL==1){
			if(Eckl_spec_is_bool_formula(cdr(n), context)==1)
				return Eckl_eval_D_bool_formula(fsm, n, context, parent);
				//return (bdd_one(dd_manager));
			else
				return Eckl_eval_D_LTL_formula(fsm, n, context, parent);
				//return (bdd_one(dd_manager));
		} else { //isLTL != 1
			return Eckl_eval_EKCBDI_MaxSubformulas(fsm, n, context, parent);
		}
	}

	case INTEND:{
		isLTL=Eckl_spec_is_LTL_formula(cdr(n), context);
		if(isLTL==1){
			if(Eckl_spec_is_bool_formula(cdr(n), context)==1)
				return Eckl_eval_I_bool_formula(fsm, n, context, parent);
				//return (bdd_one(dd_manager));
			else
				return Eckl_eval_I_LTL_formula(fsm, n, context, parent);
				//return (bdd_one(dd_manager));
		} else { //isLTL != 1
			return Eckl_eval_EKCBDI_MaxSubformulas(fsm, n, context, parent);
		}
	}

	/*
	//LTL temporal operators
	case OP_GLOBAL:
	case OP_FUTURE:
	case OP_NEXT:
	case UNTIL:
	*/

	default:
	{ /* for all the other we call the eval, and convert the result from ADD to BDD. */
		bdd_ptr res_bdd;
		add_ptr res_add = eval(n, context);

		if (res_add == NULL) {
			rpterr("Eckl_eval_spec: res = NULL after a call to \"eval\".");
			nusmv_exit(1);
		}
		res_bdd = add_to_bdd(dd_manager, res_add);
		add_free(dd_manager, res_add);
		return(res_bdd);
	}
	}
}

/**Function********************************************************************

  Synopsis           [The Pretreatment of the ECKLn specification n.]

  Description        [called in Eckl_eval_spec_recur()]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
node_ptr Eckl_spec_pretreatment(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	boolean full_fairness = (Compile_FsmBddGetCompassion(fsm) != Nil);

	Eckl_spec_eliminate_redundant_NOT(n, context);

    	//-----------------------------------------------------------------
	// If the spec is not a state formula, path quantifier A will be inserted to the head of the specification.
    	//-----------------------------------------------------------------
	if (Eckl_spec_is_state_formula(n, Nil)!=1) {
		node_ptr spec_context, old_formula, tmp1;
		if (node_get_type(n) == CONTEXT) {
			spec_context = car(n);
			old_formula = cdr(n);
			tmp1= new_node(AA, old_formula, Nil);
			setcdr(n, tmp1);
		}
		else {
			spec_context = Nil;
			old_formula = n;
			tmp1= new_node(AA, old_formula, Nil);
			n = tmp1;

			if(car(parent)==old_formula) setcar(parent, tmp1);
			else if(cdr(parent)==old_formula) setcdr(parent, tmp1);
			else{rpterr("Eckl_spec_pretreatment(): the old formula is not the parent's child.\n"); nusmv_exit(1);}
		}
	}

    	//-----------------------------------------------------------------
	// Updating a specification according to the type of compassion fairness constraints
    	//-----------------------------------------------------------------
	if(full_fairness && Eckl_get_CompassionType()!=Compassion_NoType)
	{	//(justice + compassion) strong fairness constraint
		switch (Eckl_get_CompassionType()) {
		  Compassion_as_SpecAntecedent :
			Eckl_spec_updating_for_Compassion_as_SpecAntecedent(n, context);
			break;
		  default:
		    break;
		}
	}else{  //Justice only(weakly fairness constraint)
		//Eckl_spec_unite_path_and_temporal_quantifiers(n, Nil);
	}
/*
	fprintf(nusmv_stderr, "--The A,G,F preseved ");
	Eckl_print_spec(nusmv_stderr, n);
	fprintf(nusmv_stderr, "\n");
*/

	Eckl_spec_eliminate_A_G_F(n, context);
	Eckl_spec_eliminate_redundant_NOT(n, context);

/*
	fprintf(nusmv_stderr, "--Checking the FINAL ");
	Eckl_print_spec(nusmv_stderr, n);
	fprintf(nusmv_stderr, "\n");
*/

	return n;
}

/**Function********************************************************************

  Synopsis           [Compute the conjunction of all Justice fairness constraint. i.e. J1 & J2 & ... & Jn,
  where J1,j2,...,Jn belongs to Justice fairness constraint.]

  Description        []

  SideEffects        []

  SeeAlso            [fair_iter]

******************************************************************************/
static bdd_ptr Eckl_eval_Justice_Conjunction(node_ptr justice)
{
  if(justice == Nil) return(bdd_one(dd_manager));
  if(node_get_type(justice) == CONS){
    bdd_ptr left, right, res;

    left = Eckl_eval_Justice_Conjunction(car(justice));
    right = Eckl_eval_Justice_Conjunction(cdr(justice));
    res = bdd_and(dd_manager, left, right);
    bdd_free(dd_manager, left);
    bdd_free(dd_manager, right);
    return(res);
  }
  if(node_get_type(justice) == BDD){
    return(bdd_dup((bdd_ptr)car(justice)));
  }
  internal_error("Eckl_eval_Justice_Conjunction: justice->type = %d", node_get_type(justice));
}


/**Function********************************************************************

  Synopsis           [Compute and return the BDD of fairness constraint 1]

  Description        [for the computation of knowledge and belief]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_eval_FairnessConstraint1(Fsm_BddPtr fsm)
{
	//compute the BDD of fairness constraint 1
	bdd_ptr FC1_bdd;
	FC1_bdd = eg(fsm, bdd_one(dd_manager));
	if(FC1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_FairnessConstraint(): FC1_bdd == NULL.\n");
		nusmv_exit(1);
	}

	return FC1_bdd;  //now only use the fairness constraint C1
}

/**Function********************************************************************

  Synopsis           [Compute and return the BDD of fairness constraint 2 according to the justice formulas]

  Description        [for the computation of knowledge and belief]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_eval_FairnessConstraint2(Fsm_BddPtr fsm)
{
	//--------------------------------------------------------------------------------
	//compute the BDD of fairness constraint 2 = EF( !exist(next(state_variables_bdd))trans_bdd  & (J1 & J2 & ... & Jn) )
	//--------------------------------------------------------------------------------
	bdd_ptr justice_conjunction_bdd = Eckl_eval_Justice_Conjunction(Compile_FsmBddGetJustice(fsm));
	if(!justice_conjunction_bdd){
		rpterr("Eckl_eval_FairnessConstraint: justice_conjunction_bdd is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr trans_bdd = Eckl_GetTrans(fsm);
	if(!trans_bdd){
		rpterr("Eckl_eval_FairnessConstraint: The BDD of transition relation is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = bdd_shift_forward(dd_manager, state_variables_bdd);
	if(!cube_bdd){
		rpterr("Eckl_eval_FairnessConstraint: The BDD of next(state_variables_bdd) is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr tmp_bdd = bdd_forsome(dd_manager, trans_bdd, cube_bdd);
	bdd_free(dd_manager, trans_bdd);
	bdd_free(dd_manager, cube_bdd);
	bdd_ptr tmp2_bdd = bdd_and(dd_manager, bdd_not(dd_manager, tmp_bdd), justice_conjunction_bdd);
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, justice_conjunction_bdd);
	bdd_ptr FC2_bdd = ef(fsm, tmp2_bdd);
	bdd_free(dd_manager, tmp2_bdd);

	/*
	if(bdd_is_one(dd_manager, FC2_bdd)) fprintf(nusmv_stdout, " <true> \n");
	else if(bdd_is_zero(dd_manager, FC2_bdd)) fprintf(nusmv_stdout, " <false> \n");
	else fprintf(nusmv_stdout, " <other>\n");
	*/

	return(FC2_bdd);
}



/**Function********************************************************************

  Synopsis           [Compute and return the BDD of fairness constraint 1 or 2 according to the justice formulas]

  Description        [for the computation of knowledge and belief]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_eval_FairnessConstraint(Fsm_BddPtr fsm)
{
return bdd_or(dd_manager,
	Eckl_eval_FairnessConstraint1(fsm),
	Eckl_eval_FairnessConstraint2(fsm));

}

/**Function********************************************************************

  Synopsis           [Compile formula E(LTL) into BDD.]

  Description        [n must be of the form E(LTL). i.e. car(n) is LTL formula.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_E_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));
	if(node_get_type(n)!=EE){
		rpterr("Eckl_eval_E_LTL_formula(): the main operator of node n is NOT E.\n");
		nusmv_exit(1);
	}
	if(Eckl_spec_is_LTL_formula(car(n), context)!=1) {
		rpterr("Eckl_eval_E_LTL_formula(): the node car(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_le(options, -1)) {
//		fprintf(nusmv_stdout, "--Checking E(LTL): E( ");
//		print_ltlspec(nusmv_stdout, car(n));
//		fprintf(nusmv_stdout, ")...");
		fprintf(nusmv_stdout, "--Checking E(LTL): ");
		Eckl_print_spec(nusmv_stdout, n);
		fprintf(nusmv_stdout, " ...");
	}

	//(1) Save the original status before checking n
	Eckl_SaveStatus();

	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(car(n), context);
	build_real_state_variables();	// Builds the ADD list representing real_state_variables.

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, car(n), context, &AuxiTR, &AuxiJF);
	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);

/*
    //(3.1) Update the fair states
  	bdd_ptr old_fair_states_bdd = Compile_FsmBddGetFairStates(fsm);
	Compile_FsmBddSetFairStates(fsm, (bdd_ptr)NULL);  //pretreatment for Mc_ComputeFairStates(fsm)
//  	Compile_FsmBddSetFairStates(fsm, Mc_ComputeFairStates(fsm));  //recompute the fair_states_bdd
*/

/*
	bdd_ptr old_fair_states_bdd = Compile_FsmBddGetFairStates(fsm);
	Compile_FsmBddSetFairStates(fsm, (bdd_ptr)NULL);  //Mc_ComputeFairStates(fsm) = EG(true) under fsm->Justice + AuxiJF
*/

	//(4) create the BDD(FC_bdd) of fairness constraint according to the justice formulas
	bdd_ptr FC_bdd = Eckl_eval_FairnessConstraint(fsm);
	//bdd_ptr FC_bdd = bdd_dup(Compile_FsmBddGetFairStates(fsm));  //Eckl_eval_FairnessConstraint(fsm) is equal to Mc_ComputeFairStates(fsm), which is called in Eckl_FsmAddTableau()
	//bdd_ptr FC_bdd = Eckl_ComputeFairStates(fsm);
	//bdd_ptr FC_bdd = Eckl_feasible(fsm);
	//bdd_ptr FC_bdd = Mc_ComputeFairStates(fsm);



	//(5) Check Exist(AuxiVars)( FC_bdd & LTL2Bool(car(n)) )
	//compute the cube of auxiliary variables
	bdd_ptr AuxiVars_cube = Eckl_eval_AuxiVars_Cube();
	if(AuxiVars_cube == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_E_LTL_formula(): AuxiVars_Cube == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr tmp_bdd = Eckl_eval_LTL2Bool(fsm, car(n), context);
	if(tmp_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_E_LTL_formula(): The BDD of LTL2Bool(car(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_and_accumulate(dd_manager, &tmp_bdd, FC_bdd);
	bdd_ptr res_bdd = bdd_forsome(dd_manager, tmp_bdd, AuxiVars_cube);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_E_LTL_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, AuxiVars_cube);
	bdd_free(dd_manager, FC_bdd);

	//(6) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	/* Updates the ADD list representing real_state_variables */
	build_real_state_variables();

/*    //(6.1) Update the fair states
  	fair_states_bdd = bdd_dup(Compile_FsmBddGetFairStates(fsm));
  	if (fair_states_bdd != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states_bdd);
	Compile_FsmBddSetFairStates(fsm, (bdd_ptr)NULL);
  	Compile_FsmBddSetFairStates(fsm, Mc_ComputeFairStates(fsm));
*/

//	Compile_FsmBddSetFairStates(fsm, old_fair_states_bdd);

	if (opt_verbose_level_le(options, -1)) {
		fprintf(nusmv_stdout, "Done!\n");
	}

	return(res_bdd);
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agent K (bool subformula)' into BDD.]

  Description        [n must be of the form 'agent K (bool subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_K_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));
	if(node_get_type(n)!=KNOW){
		rpterr("Eckl_eval_K_bool_formula(): the main operator of node n is NOT K.\n");
		nusmv_exit(1);
	}
	if(Eckl_spec_is_bool_formula(cdr(n), context)!=1){
		fprintf(nusmv_stdout, "Eckl_eval_K_bool_formula: The formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is NOT a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent K bool_formula): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " K ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}

//	//printing message
//	fprintf(nusmv_stdout,"\n(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube\n");

	//Computation
	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_K_bool_formula: the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_K_bool_formula: cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_bool_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//printing message
	//fprintf(nusmv_stdout,"\nPrinting Cube_bdd:\n");
	//print_state_vars(dd_manager, cube_bdd, state_variables);

	//(2) Compute res_bdd = Forall(cube_bdd)( reachable_states_bdd -> ltl2bool(cdr(n)) )
/*
	if(reachable_states_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_K_bool_formula: reachable_states_bdd is NULL.\n");
		nusmv_exit(1);
	}*/
	//if(reachable_states_bdd) bdd_free(dd_manager, reachable_states_bdd);
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

//	//printing message
//	fprintf(nusmv_stdout,"\ncomputing Eckl_eval_LTL2Bool(fsm, cdr(n), context)\n");

	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context); //Eckl_eval_spec_recur(fsm, cdr(n), context, n);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_bool_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

//	//printing message
//	fprintf(nusmv_stdout,"\ncomputing Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, reachable_states_bdd, ltl2bool_bdd, 1, -1, 1);\n");

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, reachable_states_bdd, ltl2bool_bdd, 1, -1, 1);
//	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, Eckl_compute_reachable_states(fsm), ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_bool_formula(): The BDD of reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, ltl2bool_bdd);

//	//printing message
//	fprintf(nusmv_stdout,"\ncomputing bdd_forall(dd_manager, tmp1_bdd, cube_bdd)\n");

	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_bool_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

//	//printing message
//	fprintf(nusmv_stdout,"\nfinished bdd_forall(dd_manager, tmp1_bdd, cube_bdd)\n");

	return(res_bdd);
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agent K (LTL subformula)' into BDD.]

  Description        [n must be of the form 'agent K (LTL subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_K_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));
	if(node_get_type(n)!=KNOW){
		rpterr("Eckl_eval_K_LTL_formula(): the main operator of node n is NOT K.\n");
		nusmv_exit(1);
	}
	if(Eckl_spec_is_LTL_formula(cdr(n), context)!=1) {
		rpterr("Eckl_eval_K_LTL_formula(): the node cdr(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}else if(Eckl_spec_is_bool_formula(cdr(n), context)==1){
		fprintf(nusmv_stdout, "Eckl_eval_K_LTL_formula: The LTL formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent K LTL): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " K ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}

	//(1) Save the original status before checking n
	Eckl_SaveStatus();

	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(cdr(n), context);
	build_real_state_variables();	// Builds the ADD list representing real_state_variables.

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, cdr(n), context, &AuxiTR, &AuxiJF);
	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);

	//(4) Computation
	//(4.1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_K_LTL_formula: the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_K_LTL_formula: cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_LTL_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//(4.2) create the BDD(FC_bdd) of fairness constraint according to the justice formulas
	bdd_ptr FC_bdd = Eckl_eval_FairnessConstraint(fsm);
	if(FC_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_K_LTL_formula: FC_bdd is NULL.\n");
		nusmv_exit(1);
	}

/*
	//(4.3) Compute res_bdd = Forall(cube_bdd)( FC_bdd & reachable_states_bdd -> ltl2bool(cdr(n)) )
	if(reachable_states_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_K_LTL_formula: reachable_states_bdd is NULL.\n");
		nusmv_exit(1);
	}
*/
//	if(reachable_states_bdd) bdd_free(dd_manager, reachable_states_bdd);
//	compute_reachable_states(fsm);
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	bdd_ptr tmp_bdd;
	tmp_bdd = bdd_and(dd_manager, FC_bdd, reachable_states_bdd);
//	tmp_bdd = bdd_and(dd_manager, FC_bdd, Eckl_compute_reachable_states(fsm));
	bdd_free(dd_manager, FC_bdd);

	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_LTL_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, tmp_bdd, ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_LTL_formula(): The BDD of FC_bdd & reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, ltl2bool_bdd);

	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_LTL_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

	//(5) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	build_real_state_variables();	// Updates the ADD list representing real_state_variables

	return(res_bdd);
}

/**Function********************************************************************

  Synopsis           [Compute and_foreach_agent_i)(forall(X-O_i)(G(P)->Z)) ]

  Description        [n must be of the form 'agents C (bool subformula)'.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_eval_C_formula_AdditiveFunction(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent, bdd_ptr Z)
{
	if(Z == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_C_formula_AdditiveFunction(): The parameter Z == NULL.\n");
		nusmv_exit(1);
	}
	if(node_get_type(n)!=CKNOW){
		rpterr("Eckl_eval_C_formula_AdditiveFunction: the main operator of node n is NOT C.\n");
		nusmv_exit(1);
	}
	bdd_ptr res_bdd = bdd_one(dd_manager);

	node_ptr agents = car(n);
	while(agents){
		node_ptr agent = car(agents);

		//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube_i
		node_ptr mod_name = eval_struct(find_atom(agent), Nil);
		StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
		if(!mod_inst){
			fprintf(nusmv_stdout, "Eckl_eval_C_formula_AdditiveFunction: the agent '");
			print_node(nusmv_stdout, mod_name);
			fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
			nusmv_exit(1);
		}

		add_ptr cube_add = add_dup(state_variables_add);
		Eckl_clear_ObsVar_hash();
		Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
		Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
		if(!cube_add){
			rpterr("Eckl_eval_C_formula_AdditiveFunction: cube_add is Nil.\n");
			nusmv_exit(1);
		}
		bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
		add_free(dd_manager, cube_add);
		if(cube_bdd == (bdd_ptr)NULL) {
			rpterr("Eckl_eval_C_formula_AdditiveFunction(): AbstractCube == NULL.\n");
			nusmv_exit(1);
		}

		//(2) Compute formula : forall(X-O_i)(G(P)->Z)
		if(!reachable_states_bdd) {
			rpterr("Eckl_eval_C_formula_AdditiveFunction: reachable_states_bdd==NULL.\n");
			nusmv_exit(1);
		}

		bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, reachable_states_bdd, Z, 1, -1, 1);
		if(tmp1_bdd == (bdd_ptr)NULL) {
			rpterr("Eckl_eval_C_formula_AdditiveFunction(): The BDD of (reachable_states_bdd->Z) == NULL.\n");
			nusmv_exit(1);
		}
		if(Z) bdd_free(dd_manager, Z);

		bdd_ptr tmp2_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
		if(tmp2_bdd == (bdd_ptr)NULL) {
			rpterr("Eckl_eval_C_formula_AdditiveFunction(): tmp2_bdd == NULL.\n");
			nusmv_exit(1);
		}
		bdd_free(dd_manager, tmp1_bdd);
		bdd_free(dd_manager, cube_bdd);

		bdd_and_accumulate(dd_manager, &res_bdd, tmp2_bdd);
		bdd_free(dd_manager, tmp2_bdd);

		agents = cdr(agents);
	}

	return res_bdd;
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agents C (bool subformula)' into BDD.]

  Description        [n must be of the form 'agents C (bool subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_C_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));
	if(node_get_type(n)!=CKNOW){
		rpterr("Eckl_eval_C_bool_formula(): the main operator of node n is NOT C.\n");
		nusmv_exit(1);
	}
	if(Eckl_spec_is_bool_formula(cdr(n), context)!=1){
		fprintf(nusmv_stdout, "Eckl_eval_C_bool_formula: The formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is NOT a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agents C bool_formula): evaluating )");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, ") C ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}

//	if(reachable_states_bdd) bdd_free(dd_manager, reachable_states_bdd);
//	compute_reachable_states(fsm);
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	//compute formula: gfpZ[G(P) & cdr(n) & AddtiveFunction()]
	bdd_ptr new = bdd_one(dd_manager);
	bdd_ptr old = (bdd_ptr)Nil;
	while(1){
		if(old)	bdd_free(dd_manager, old);
		old = bdd_dup(new);

		bdd_ptr tmp1_bdd = Eckl_eval_C_formula_AdditiveFunction(fsm, n, context, parent, new);
		if(!tmp1_bdd){
			rpterr("Eckl_eval_C_bool_formula: the result of additivefunction is NULL.\n");
			nusmv_exit(1);
		}
		bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
		if(!ltl2bool_bdd){
			rpterr("Eckl_eval_C_bool_formula: ltl2bool_bdd is NULL.\n");
			nusmv_exit(1);
		}
		bdd_and_accumulate(dd_manager, &tmp1_bdd, ltl2bool_bdd);
		bdd_free(dd_manager, ltl2bool_bdd);

		bdd_and_accumulate(dd_manager, &tmp1_bdd, reachable_states_bdd);
		if(new) bdd_free(dd_manager, new);
		new = bdd_dup(tmp1_bdd);
		bdd_free(dd_manager, tmp1_bdd);

		if(old==new) break;
	}

	if(old) bdd_free(dd_manager, old);
	return new;
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agents C (LTL subformula)' into BDD.]

  Description        [n must be of the form 'agents C (LTL subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_C_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));
	if(node_get_type(n)!=CKNOW){
		rpterr("Eckl_eval_C_LTL_formula(): the main operator of node n is NOT K.\n");
		nusmv_exit(1);
	}
	if(Eckl_spec_is_LTL_formula(cdr(n), context)!=1) {
		rpterr("Eckl_eval_C_LTL_formula(): the node cdr(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}else if(Eckl_spec_is_bool_formula(cdr(n), context)==1){
		fprintf(nusmv_stdout, "Eckl_eval_C_LTL_formula: The LTL formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agents C LTL): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " C ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}

	//(1) Save the original status before checking n
	Eckl_SaveStatus();

	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(cdr(n), context);
	build_real_state_variables();	// Builds the ADD list representing real_state_variables.

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, cdr(n), context, &AuxiTR, &AuxiJF);
	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);

	//if(reachable_states_bdd) bdd_free(dd_manager, reachable_states_bdd);
	//compute_reachable_states(fsm);
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	//(4) Compute formula: gfpZ[G(P) & forall(auxiX)(FC->ltl2bool(cdr(n))) & AddtiveFunction()]
	bdd_ptr new = bdd_one(dd_manager);
	bdd_ptr old = (bdd_ptr)Nil;
	while(1){
		if(old)	bdd_free(dd_manager, old);
		old = bdd_dup(new);

		//(4.1) compute formula forall(auxiX)(FC->ltl2bool(cdr(n)))
		bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
		if(!ltl2bool_bdd){
			rpterr("Eckl_eval_C_LTL_formula: ltl2bool_bdd is NULL.\n");
			nusmv_exit(1);
		}
		bdd_ptr FC_bdd = Eckl_eval_FairnessConstraint(fsm);
		if(!FC_bdd){
			rpterr("Eckl_eval_C_LTL_formula: FC_bdd is NULL.\n");
			nusmv_exit(1);
		}
		bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, FC_bdd, ltl2bool_bdd, 1, -1, 1);
		if(tmp1_bdd == (bdd_ptr)NULL) {
			rpterr("Eckl_eval_C_LTL_formula: The BDD of (FC_bdd->ltl2bool(cdr(n)) == NULL.\n");
			nusmv_exit(1);
		}
		bdd_free(dd_manager, FC_bdd);
		bdd_free(dd_manager, ltl2bool_bdd);
		//compute the cube of auxiliary variables
		bdd_ptr AuxiVars_cube = Eckl_eval_AuxiVars_Cube();
		if(AuxiVars_cube == (bdd_ptr)NULL) {
			rpterr("Eckl_eval_C_LTL_formula(): AuxiVars_Cube == NULL.\n");
			nusmv_exit(1);
		}
		bdd_ptr tmp2_bdd = bdd_forall(dd_manager, tmp1_bdd, AuxiVars_cube);
		bdd_free(dd_manager, tmp1_bdd);
		//-----------(4.1)------------------------------------

		bdd_ptr tmp3_bdd = Eckl_eval_C_formula_AdditiveFunction(fsm, n, context, parent, new);
		if(!tmp3_bdd){
			rpterr("Eckl_eval_C_LTL_formula: the result of additivefunction is NULL.\n");
			nusmv_exit(1);
		}

		bdd_and_accumulate(dd_manager, &tmp3_bdd, tmp2_bdd);
		bdd_free(dd_manager, tmp2_bdd);

		bdd_and_accumulate(dd_manager, &tmp3_bdd, reachable_states_bdd);
		if(new) bdd_free(dd_manager, new);
		new = bdd_dup(tmp3_bdd);
		bdd_free(dd_manager, tmp3_bdd);

		if(old==new) break;
	}
	if(old) bdd_free(dd_manager, old);

	//(5) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	build_real_state_variables();	// Updates the ADD list representing real_state_variables

	return(new);
}

/**Function********************************************************************

  Synopsis           [Compile expression 'agent_name.var_name' into BDD.]

  Description        [agent_name is a module instance. var_name is belong to {BELIEF_WORLD, DESIRE_WORLD, INTENTION_WORLD}]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_eval_BDI_possibleworld_variable(node_ptr agent_name, char * var_name)
{
	bdd_ptr var_bdd;

	node_ptr name = eval_struct(sym_intern(var_name), find_atom(agent_name));  //name = agent_name.var_name
	//node_ptr name = find_node(DOT, find_atom(agent_name), sym_intern(var_name));
//	print_node(nusmv_stdout, name);
	/* name must be a defined variable */
	node_ptr name_info = lookup_symbol_hash(name);
	if (name_info == (node_ptr)NULL) {
		fprintf(nusmv_stdout, "Eckl_eval_BDI_possibleworld_variable(): '");
		print_node(nusmv_stdout, name);
		fprintf(nusmv_stdout, "' is an undefined symbol in module '");
		print_node(nusmv_stdout, agent_name);
		fprintf(nusmv_stdout, "'.\n");
	   	nusmv_exit(1);
	} else if (node_get_type(name_info) == VAR && cdr(name_info) == boolean_type) {
		//print_node(nusmv_stdout, name);

		//belief_bdd = (belief_name==true)
		add_ptr var_add = eval(name, (node_ptr)NULL);
		if (var_add == (add_ptr)NULL) {
			fprintf(nusmv_stdout, "Eckl_eval_BDI_possibleworld_variable(): var_add == NULL after a call to \"eval\".");
			nusmv_exit(1);
		}
		var_bdd = add_to_bdd(dd_manager, var_add);
		bdd_ref(var_bdd);
		add_free(dd_manager, var_add);
	} else {
        fprintf(nusmv_stdout, "Eckl_eval_BDI_possibleworld_variable(): Symbol '");
		print_node(nusmv_stdout, name);
		fprintf(nusmv_stdout, "' is unexpected data structure (boolean).");
		nusmv_exit(1);
	}

	return (var_bdd);
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agent B/D/I (bool subformula)' into BDD.]

  Description        [n must be of the form 'agent B/D/I (bool subformula)'.
  BDI_operator is in {BELIEVE, DESIRE, INTEND}]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_BDI_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent, int BDI_operator)
{
	if (n == Nil) return(bdd_one(dd_manager));

	char * world_style = "";
	switch(BDI_operator){
		case BELIEVE:
			if(node_get_type(n)!=BELIEVE){
				rpterr("Eckl_eval_BDI_bool_formula(): the main operator of node n is NOT 'B'.\n");
				nusmv_exit(1);
			}
			world_style = BELIEF_WORLD;
			break;
		case DESIRE:
			if(node_get_type(n)!=DESIRE){
				rpterr("Eckl_eval_BDI_bool_formula(): the main operator of node n is NOT 'D'.\n");
				nusmv_exit(1);
			}
			world_style = DESIRE_WORLD;
			break;
		case INTEND:
			if(node_get_type(n)!=INTEND){
				rpterr("Eckl_eval_BDI_bool_formula(): the main operator of node n is NOT 'I'.\n");
				nusmv_exit(1);
			}
			world_style = INTENTION_WORLD;
			break;
	}
	if (world_style == "") {
		rpterr("Eckl_eval_BDI_bool_formula(): world_style is not belong to {BELIEF_WORLD, DESIRE_WORLD, INTENTION_WORLD}");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_bool_formula(cdr(n), context)!=1){
		fprintf(nusmv_stdout, "Eckl_eval_BDI_bool_formula: The formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is NOT a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent B/D/I bool_formula): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " %c ", world_style[0]);
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}


	//get the name of the agent
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));


	//-------------------------------------------------------------------------------------------
	//modify TR for Belief, Desire or Intention
	//-------------------------------------------------------------------------------------------
	CPCluster * NewTRCluster=(CPCluster *)NULL;

	switch(BDI_operator){
	case BELIEVE: {
		//get the BDD of WB' for the agent mod_name
		bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
		bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
		bdd_free(dd_manager, bdd_Belief);

		//create the new_TR as (old_TR and WB'_i)
		Eckl_TransAddBdd(fsm, bdd_Belief_Next, NewTRCluster);
		bdd_free(dd_manager, bdd_Belief_Next);

		break;}
	case DESIRE:{
		//get the BDDs of WB' and WD' for the agent mod_name
		bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
		bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
		bdd_free(dd_manager, bdd_Belief);

		bdd_ptr bdd_Desire = Eckl_eval_BDI_possibleworld_variable(mod_name, DESIRE_WORLD);
		bdd_ptr bdd_Desire_Next = bdd_shift_forward(dd_manager, bdd_Desire);
		bdd_free(dd_manager, bdd_Desire);


		//create the new_TR as (old_TR and WB'_i and WD'_i)
		Eckl_TransAddBdd(fsm, bdd_and(dd_manager, bdd_Belief_Next, bdd_Desire_Next), NewTRCluster);
		bdd_free(dd_manager, bdd_Belief_Next);
		bdd_free(dd_manager, bdd_Desire_Next);

		break;}
	case INTEND: {
		//get the BDD of WI' for the agent mod_name
		bdd_ptr bdd_Intend = Eckl_eval_BDI_possibleworld_variable(mod_name, INTENTION_WORLD);
		bdd_ptr bdd_Intend_Next = bdd_shift_forward(dd_manager, bdd_Intend);
		bdd_free(dd_manager, bdd_Intend);

		//create the new_TR as (old_TR and WI'_i)
		Eckl_TransAddBdd(fsm, bdd_Intend_Next, NewTRCluster);
		bdd_free(dd_manager, bdd_Intend_Next);

		break;}
	}




	//Computation
	//-------------------------------------------------------------------------------------------
	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	//-------------------------------------------------------------------------------------------
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_BDI_bool_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_BDI_bool_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_bool_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//-------------------------------------------------------------------------------------------
	//(2) Compute res_bdd = Forall(cube_bdd)( belief/desire/intention_reachable_states_bdd -> ltl2bool(cdr(n)) )
	//-------------------------------------------------------------------------------------------

	//Create the BDD of the boolean variable presenting the agent's B/D/I world (BDI_bdd==true) B/D/I=True
	bdd_ptr BDI_bdd = Eckl_eval_BDI_possibleworld_variable(mod_name, world_style);
	if (BDI_bdd == (bdd_ptr)NULL) {
		fprintf(nusmv_stdout, "Eckl_eval_BDI_bool_formula(): BDI_bdd==NULL.");
		nusmv_exit(1);
	}

	/*
	if(reachable_states_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_B_bool_formula: reachable_states_bdd is NULL.\n");
		nusmv_exit(1);
	}*/
	//if(reachable_states_bdd) bdd_free(dd_manager, reachable_states_bdd);
	//compute_reachable_states(fsm);
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	bdd_ptr BDI_reachable_states_bdd = bdd_and(dd_manager, reachable_states_bdd, BDI_bdd);
	//bdd_ref(BDI_reachable_states_bdd);
	bdd_free(dd_manager, BDI_bdd);

	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context); //Eckl_eval_spec_recur(fsm, cdr(n), context, n);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_bool_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	//tmp1_bdd = BDI_reachable_states_bdd -> ltl2bool_bdd
	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, BDI_reachable_states_bdd, ltl2bool_bdd, 1, -1, 1);
//	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, Eckl_compute_reachable_states(fsm), ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_bool_formula(): The BDD of belief/desire/intention_reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, BDI_reachable_states_bdd);
	bdd_free(dd_manager, ltl2bool_bdd);

	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_bool_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

	return(res_bdd);
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agent B (bool subformula)' into BDD.]

  Description        [n must be of the form 'agent B (bool subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_B_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));

	if(node_get_type(n)!=BELIEVE){
		rpterr("Eckl_eval_B_bool_formula(): the main operator of node n is NOT 'B'.\n");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_bool_formula(cdr(n), context)!=1){
		fprintf(nusmv_stdout, "Eckl_eval_B_bool_formula(): The formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is NOT a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent B bool_formula): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " B ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}


	//get the name of the agent
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_B_bool_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}


	//-------------------------------------------------------------------------------------------
	//modify TR for Belief
	//-------------------------------------------------------------------------------------------
	CPCluster * NewTRCluster=(CPCluster *)NULL;

	//get the BDD of WB' for the agent mod_name
	bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
	bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
	bdd_free(dd_manager, bdd_Belief);


	//create the new_TR as (old_TR and WB'_i)
	Eckl_TransAddBdd(fsm, bdd_Belief_Next, NewTRCluster);
	bdd_free(dd_manager, bdd_Belief_Next);



	//Computation
	//-------------------------------------------------------------------------------------------
	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	//-------------------------------------------------------------------------------------------
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_B_bool_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_bool_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//-------------------------------------------------------------------------------------------
	//(2) Compute res_bdd = Forall(cube_bdd)( belief_reachable_states_bdd -> ltl2bool(cdr(n)) )
	//-------------------------------------------------------------------------------------------

	bdd_ptr total_reachable_states_bdd = (bdd_ptr)NULL;
	if(reachable_states_bdd != (bdd_ptr)NULL) {
		total_reachable_states_bdd = bdd_dup(reachable_states_bdd);  //saving the total reachable states bdd
		bdd_free(dd_manager, reachable_states_bdd);
	}
	compute_reachable_states(fsm);  //create belief_reachable_states_bdd into reachable_states_bdd


	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context); //Eckl_eval_spec_recur(fsm, cdr(n), context, n);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_bool_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	//tmp1_bdd = belief_reachable_states_bdd -> ltl2bool_bdd
	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, reachable_states_bdd, ltl2bool_bdd, 1, -1, 1);
//	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, Eckl_compute_reachable_states(fsm), ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_bool_formula(): The BDD of belief_reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, ltl2bool_bdd);


	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_bool_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);


	//-------------------------------------------------------------------------------------------
	//restore original TR
	//-------------------------------------------------------------------------------------------
	Eckl_TransDeleteBdd(fsm, NewTRCluster);
	NewTRCluster = (CPCluster *)NULL;

	//restore the total reachable states bdd
	bdd_free(dd_manager, reachable_states_bdd);
	reachable_states_bdd = total_reachable_states_bdd;


	return(res_bdd);
}


/**Function for IJCAI-07********************************************************************

  Synopsis           [Compile formula 'agent D (bool subformula)' into BDD.]

  Description        [n must be of the form 'agent D (bool subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_D_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));

	if(node_get_type(n)!=DESIRE){
		rpterr("Eckl_eval_D_bool_formula(): the main operator of node n is NOT 'D'.\n");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_bool_formula(cdr(n), context)!=1){
		fprintf(nusmv_stdout, "Eckl_eval_D_bool_formula(): The formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is NOT a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent D bool_formula): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " D ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}


	//get the name of the agent
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_D_bool_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}


	//-------------------------------------------------------------------------------------------
	//modify TR for Desire
	//-------------------------------------------------------------------------------------------
	CPCluster * NewTRCluster=(CPCluster *)NULL;

	//get the BDD of WB' for the agent mod_name
	bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
	bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
	bdd_free(dd_manager, bdd_Belief);

	//create the new_TR as (old_TR and WB'_i)
	Eckl_TransAddBdd(fsm, bdd_Belief_Next, NewTRCluster);
	bdd_free(dd_manager, bdd_Belief_Next);



	//Computation
	//-------------------------------------------------------------------------------------------
	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	//-------------------------------------------------------------------------------------------
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_D_bool_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_bool_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//-------------------------------------------------------------------------------------------
	//(2) Compute res1_bdd = Forall(X+X_\varphi - O_i)( BD_diff_reachable_states_bdd -> !ltl2bool(cdr(n)) )
	//-------------------------------------------------------------------------------------------

	bdd_ptr total_reachable_states_bdd = (bdd_ptr)NULL;
	if(reachable_states_bdd != (bdd_ptr)NULL) {
		total_reachable_states_bdd = bdd_dup(reachable_states_bdd);  //saving the total reachable states bdd
		bdd_free(dd_manager, reachable_states_bdd);
	}
	compute_reachable_states(fsm);  //create belief_reachable_states_bdd into reachable_states_bdd


	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context); //Eckl_eval_spec_recur(fsm, cdr(n), context, n);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_bool_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	//tmp1_bdd = BD_diff_reachable_states_bdd -> !ltl2bool_bdd
	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or,
		Eckl_compute_BD_diff_reachable_states(fsm, mod_name), bdd_not(dd_manager, ltl2bool_bdd), 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_bool_formula(): The BDD of BD_diff_reachable_states_bdd -> !ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, ltl2bool_bdd);


	bdd_ptr res1_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_bool_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);



	//-------------------------------------------------------------------------------------------
	//(3) Compute res2_bdd = !B_i !\phi                \phi = cdr(n)
	//-------------------------------------------------------------------------------------------

	// Pretreatment before checking a specification
	node_ptr new_spec = new_node(CONTEXT, n, Nil);  //used to get updated specification

    	node_ptr phi = cdr(n);
    	node_ptr neg_phi = new_node(NOT, cdr(n), Nil);
    	n->type = BELIEVE;
    	setcdr(n, neg_phi);
	//node_ptr old_spec = n;

	Eckl_spec_eliminate_redundant_NOT(new_spec, Nil);

	bdd_ptr res2_bdd = bdd_not(dd_manager, Eckl_eval_spec(fsm, n, Nil, new_spec));

	//n = car(new_spec);  //get the updated specification

	// Restore the old spec
	n->type = DESIRE;
	setcdr(n, phi);



	//-------------------------------------------------------------------------------------------
	//restore original TR
	//-------------------------------------------------------------------------------------------
	Eckl_TransDeleteBdd(fsm, NewTRCluster);
	NewTRCluster = (CPCluster *)NULL;

	//restore the total reachable states bdd
	bdd_free(dd_manager, reachable_states_bdd);
	reachable_states_bdd = total_reachable_states_bdd;


	bdd_ptr res_bdd = bdd_and(dd_manager, res1_bdd, res2_bdd);
	if(res1_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res1_bdd);
	if(res2_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res2_bdd);


	return res_bdd;
}



/**Function for AAAI-06********************************************************************

  Synopsis           [Compile formula 'agent D (bool subformula)' into BDD.]

  Description        [n must be of the form 'agent D (bool subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
/*
bdd_ptr Eckl_eval_D_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	return Eckl_eval_BDI_bool_formula(fsm, n, context, parent, DESIRE);
}
*/



/**Function********************************************************************

  Synopsis           [Compile formula 'agent I (bool subformula)' into BDD.]

  Description        [n must be of the form 'agent I (bool subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_I_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));

	if(node_get_type(n)!=INTEND){
		rpterr("Eckl_eval_I_bool_formula(): the main operator of node n is NOT 'I'.\n");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_bool_formula(cdr(n), context)!=1){
		fprintf(nusmv_stdout, "Eckl_eval_I_bool_formula(): The formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is NOT a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent I bool_formula): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " I ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}


	//get the name of the agent
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_I_bool_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}


	//-------------------------------------------------------------------------------------------
	//modify TR for Intention
	//-------------------------------------------------------------------------------------------
	CPCluster * NewTRCluster=(CPCluster *)NULL;

	//get the BDD of WB' for the agent mod_name
	bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
	bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
	bdd_free(dd_manager, bdd_Belief);

	//get the BDD of WD' for the agent mod_name
	bdd_ptr bdd_Desire = Eckl_eval_BDI_possibleworld_variable(mod_name, DESIRE_WORLD);
	bdd_ptr bdd_Desire_Next = bdd_shift_forward(dd_manager, bdd_Desire);
	bdd_free(dd_manager, bdd_Desire);

	//get the BDD of WI' for the agent mod_name
	bdd_ptr bdd_Intend = Eckl_eval_BDI_possibleworld_variable(mod_name, INTENTION_WORLD);
	bdd_ptr bdd_Intend_Next = bdd_shift_forward(dd_manager, bdd_Intend);
	bdd_free(dd_manager, bdd_Intend);


	//create the new_TR as (old_TR and WB'_i and WD'_i and WI'_i)
	Eckl_TransAddBdd(fsm,
		bdd_and(dd_manager, bdd_and(dd_manager, bdd_Belief_Next, bdd_Desire_Next), bdd_Intend_Next),
		NewTRCluster);

	if(bdd_Belief_Next!=(bdd_ptr)NULL) bdd_free(dd_manager, bdd_Belief_Next);
	if(bdd_Desire_Next!=(bdd_ptr)NULL) bdd_free(dd_manager, bdd_Desire_Next);
	if(bdd_Intend_Next!=(bdd_ptr)NULL) bdd_free(dd_manager, bdd_Intend_Next);



	//Computation
	//-------------------------------------------------------------------------------------------
	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	//-------------------------------------------------------------------------------------------
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_I_bool_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_bool_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//-------------------------------------------------------------------------------------------
	//(2) Compute res_bdd = Forall(cube_bdd)( intend_reachable_states_bdd -> ltl2bool(cdr(n)) )
	//-------------------------------------------------------------------------------------------

	bdd_ptr total_reachable_states_bdd = (bdd_ptr)NULL;
	if(reachable_states_bdd != (bdd_ptr)NULL) {
		total_reachable_states_bdd = bdd_dup(reachable_states_bdd);  //saving the total reachable states bdd
		bdd_free(dd_manager, reachable_states_bdd);
	}
	compute_reachable_states(fsm);  //create belief_reachable_states_bdd into reachable_states_bdd


	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context); //Eckl_eval_spec_recur(fsm, cdr(n), context, n);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_bool_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	//tmp1_bdd = intend_reachable_states_bdd -> ltl2bool_bdd
	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, reachable_states_bdd, ltl2bool_bdd, 1, -1, 1);
//	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, Eckl_compute_reachable_states(fsm), ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_bool_formula(): The BDD of belief_reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, ltl2bool_bdd);


	bdd_ptr res1_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_bool_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);



	//-------------------------------------------------------------------------------------------
	//(3) Compute res2_bdd = D_i \phi                \phi = cdr(n)
	//-------------------------------------------------------------------------------------------

	// Pretreatment before checking a specification
	node_ptr new_spec = new_node(CONTEXT, n, Nil);  //used to get updated specification
    	n->type = DESIRE;

	bdd_ptr res2_bdd = Eckl_eval_spec(fsm, n, Nil, new_spec);

	// Restore the old spec
	n->type = INTEND;



	//-------------------------------------------------------------------------------------------
	//restore original TR
	//-------------------------------------------------------------------------------------------
	Eckl_TransDeleteBdd(fsm, NewTRCluster);
	NewTRCluster = (CPCluster *)NULL;

	//restore the total reachable states bdd
	bdd_free(dd_manager, reachable_states_bdd);
	reachable_states_bdd = total_reachable_states_bdd;


	bdd_ptr res_bdd = bdd_and(dd_manager, res1_bdd, res2_bdd);
	if(res1_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res1_bdd);
	if(res2_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res2_bdd);


	return res_bdd;
}



/**Function********************************************************************

  Synopsis           [Compile formula 'agent B/D/I (LTL subformula)' into BDD.]

  Description        [n must be of the form 'agent B/D/I (LTL subformula)'.
  BDI_operator is in {BELIEVE, DESIRE, INTEND}]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_BDI_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent, int BDI_operator)
{
	if (n == Nil) return(bdd_one(dd_manager));

	char * world_style = "";
	switch(BDI_operator){
		case BELIEVE:
			if(node_get_type(n)!=BELIEVE){
				rpterr("Eckl_eval_BDI_LTL_formula(): the main operator of node n is NOT 'B'.\n");
				nusmv_exit(1);
			}
			world_style = BELIEF_WORLD;
			break;
		case DESIRE:
			if(node_get_type(n)!=DESIRE){
				rpterr("Eckl_eval_BDI_LTL_formula(): the main operator of node n is NOT 'D'.\n");
				nusmv_exit(1);
			}
			world_style = DESIRE_WORLD;
			break;
		case INTEND:
			if(node_get_type(n)!=INTEND){
				rpterr("Eckl_eval_BDI_LTL_formula(): the main operator of node n is NOT 'I'.\n");
				nusmv_exit(1);
			}
			world_style = INTENTION_WORLD;
			break;
	}
	if (world_style == "") {
		rpterr("Eckl_eval_BDI_LTL_formula(): world_style is not belong to {BELIEF_WORLD, DESIRE_WORLD, INTENTION_WORLD}");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_LTL_formula(cdr(n), context)!=1) {
		rpterr("Eckl_eval_BDI_LTL_formula(): the node cdr(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}else if(Eckl_spec_is_bool_formula(cdr(n), context)==1){
		fprintf(nusmv_stdout, "Eckl_eval_BDI_LTL_formula(): The LTL formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent B/D/I LTL): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " %c ", world_style[0]);
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}

	//(1) Save the original status before checking n
	Eckl_SaveStatus();

	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(cdr(n), context);
	build_real_state_variables();	// Builds the ADD list representing real_state_variables.

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, cdr(n), context, &AuxiTR, &AuxiJF);
	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);

	//(4) Computation
	//(4.1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_BDI_LTL_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_BDI_LTL_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_LTL_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//(4.2) create the BDD(FC_bdd) of fairness constraint according to the justice formulas
	bdd_ptr FC_bdd = Eckl_eval_FairnessConstraint(fsm);
	if(FC_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_BDI_LTL_formula: FC_bdd is NULL.\n");
		nusmv_exit(1);
	}


	//(4.3) Compute res_bdd = Forall(cube_bdd)( FC_bdd & belief/desire/intention_reachable_states_bdd -> ltl2bool(cdr(n)) )

	//----BDI_bdd==true)----
	bdd_ptr BDI_bdd = Eckl_eval_BDI_possibleworld_variable(mod_name, world_style);
	if (BDI_bdd == (bdd_ptr)NULL) {
		fprintf(nusmv_stdout, "Eckl_eval_BDI_LTL_formula(): BDI_bdd==NULL.");
		nusmv_exit(1);
	}

/*
	if(reachable_states_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_B_LTL_formula: reachable_states_bdd is NULL.\n");
		nusmv_exit(1);
	}
*/
//	if(reachable_states_bdd) bdd_free(dd_manager, reachable_states_bdd);
//	compute_reachable_states(fsm);
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	//---- BDI_reachable_states_bdd = reachable_states_bdd & BDI_bdd ----
	bdd_ptr BDI_reachable_states_bdd = bdd_and(dd_manager, reachable_states_bdd, BDI_bdd);
	//bdd_ref(BDI_reachable_states_bdd);
	bdd_free(dd_manager, BDI_bdd);

	bdd_ptr tmp_bdd;
	tmp_bdd = bdd_and(dd_manager, FC_bdd, BDI_reachable_states_bdd);
//	tmp_bdd = bdd_and(dd_manager, FC_bdd, Eckl_compute_reachable_states(fsm));
	bdd_free(dd_manager, FC_bdd);
	bdd_free(dd_manager, BDI_reachable_states_bdd);

	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_LTL_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, tmp_bdd, ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_LTL_formula(): The BDD of FC_bdd & belief/desire/intention_reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, ltl2bool_bdd);

	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_BDI_LTL_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

	//(5) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	build_real_state_variables();	// Updates the ADD list representing real_state_variables

	return(res_bdd);
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agent B (LTL subformula)' into BDD.]

  Description        [n must be of the form 'agent B (LTL subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_B_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));

	if(node_get_type(n)!=BELIEVE){
		rpterr("Eckl_eval_B_LTL_formula(): the main operator of node n is NOT 'B'.\n");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_LTL_formula(cdr(n), context)!=1) {
		rpterr("Eckl_eval_B_LTL_formula(): the node cdr(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}else if(Eckl_spec_is_bool_formula(cdr(n), context)==1){
		fprintf(nusmv_stdout, "Eckl_eval_B_LTL_formula(): The LTL formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent B LTL): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " B ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}


	//get the name of the agent
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_B_LTL_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}


	//(1) Save the original status before checking n
	Eckl_SaveStatus();

	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(cdr(n), context);
	build_real_state_variables();	// Builds the ADD list representing real_state_variables.

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of belief transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, cdr(n), context, &AuxiTR, &AuxiJF);

	//get the BDD of WB' for the agent mod_name
	bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
	bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
	bdd_free(dd_manager, bdd_Belief);

	//AuxiTR = AuxiTR and WB'_i
	bdd_and_accumulate(dd_manager, &AuxiTR, bdd_Belief_Next);

	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);



	//(4) Computation
	//(4.1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_B_LTL_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_LTL_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//(4.2) create the BDD(FC_bdd) of fairness constraint according to the justice formulas
	bdd_ptr FC_bdd = Eckl_eval_FairnessConstraint(fsm);
	if(FC_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_B_LTL_formula: FC_bdd is NULL.\n");
		nusmv_exit(1);
	}


	//(4.3) Compute res_bdd = Forall(cube_bdd)( (FC_bdd & belief_reachable_states_bdd) -> ltl2bool(cdr(n)) )

	bdd_ptr total_reachable_states_bdd = (bdd_ptr)NULL;
	if(reachable_states_bdd != (bdd_ptr)NULL) {
		total_reachable_states_bdd = bdd_dup(reachable_states_bdd);  //saving the total reachable states bdd
		bdd_free(dd_manager, reachable_states_bdd);
	}
	compute_reachable_states(fsm);  //create belief_reachable_states_bdd into reachable_states_bdd


	bdd_ptr tmp_bdd;
	tmp_bdd = bdd_and(dd_manager, FC_bdd, reachable_states_bdd);
//	tmp_bdd = bdd_and(dd_manager, FC_bdd, Eckl_compute_reachable_states(fsm));
	bdd_free(dd_manager, FC_bdd);

	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_LTL_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, tmp_bdd, ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_LTL_formula(): The BDD of FC_bdd & belief/desire/intention_reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, ltl2bool_bdd);

	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_B_LTL_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

	//(5) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	build_real_state_variables();	// Updates the ADD list representing real_state_variables


	//restore the total reachable states bdd
	bdd_free(dd_manager, reachable_states_bdd);
	reachable_states_bdd = total_reachable_states_bdd;

	return(res_bdd);
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agent D (LTL subformula)' into BDD.]

  Description        [n must be of the form 'agent D (LTL subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_D_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));

	if(node_get_type(n)!=DESIRE){
		rpterr("Eckl_eval_D_LTL_formula(): the main operator of node n is NOT 'D'.\n");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_LTL_formula(cdr(n), context)!=1) {
		rpterr("Eckl_eval_D_LTL_formula(): the node cdr(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}else if(Eckl_spec_is_bool_formula(cdr(n), context)==1){
		fprintf(nusmv_stdout, "Eckl_eval_D_LTL_formula(): The LTL formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent D LTL): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " D ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}


	//get the name of the agent
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_D_LTL_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}

	//(1) Save the original status before checking n
	Eckl_SaveStatus();

	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(cdr(n), context);
	build_real_state_variables();	// Builds the ADD list representing real_state_variables.

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of belief transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, cdr(n), context, &AuxiTR, &AuxiJF);

	//get the BDD of WB' for the agent mod_name
	bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
	bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
	bdd_free(dd_manager, bdd_Belief);

	//AuxiTR = AuxiTR and WB'_i
	bdd_and_accumulate(dd_manager, &AuxiTR, bdd_Belief_Next);

	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);



	//(4) Computation
	//(4.1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_D_LTL_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_LTL_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//(4.2) create the BDD(FC_bdd) of fairness constraint according to the justice formulas
	bdd_ptr FC_bdd = bdd_or(dd_manager,
		Eckl_eval_FairnessConstraint_for_Desire(fsm, mod_name, 1),
		Eckl_eval_FairnessConstraint_for_Desire(fsm, mod_name, 2));
	if(FC_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_D_LTL_formula: FC_bdd is NULL.\n");
		nusmv_exit(1);
	}


	//(4.3) Compute res1_bdd = Forall(cube_bdd)( (FC_bdd & BD_diff_reachable_states_bdd) -> !ltl2bool(cdr(n)) )

	bdd_ptr total_reachable_states_bdd = (bdd_ptr)NULL;
	if(reachable_states_bdd != (bdd_ptr)NULL) {
		total_reachable_states_bdd = bdd_dup(reachable_states_bdd);  //saving the total reachable states bdd
		bdd_free(dd_manager, reachable_states_bdd);
	}
	compute_reachable_states(fsm);  //create belief_reachable_states_bdd into reachable_states_bdd


	bdd_ptr tmp_bdd;
	tmp_bdd = bdd_and(dd_manager, FC_bdd, Eckl_compute_BD_diff_reachable_states(fsm, mod_name));
//	tmp_bdd = bdd_and(dd_manager, FC_bdd, Eckl_compute_reachable_states(fsm));
	bdd_free(dd_manager, FC_bdd);

	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_LTL_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, tmp_bdd, bdd_not(dd_manager, ltl2bool_bdd), 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_LTL_formula(): The BDD of FC_bdd & BD_diff_reachable_states_bdd -> !ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, ltl2bool_bdd);

	bdd_ptr res1_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_D_LTL_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);



	//-------------------------------------------------------------------------------------------
	//(4.4) Compute res2_bdd = !B_i !\phi                \phi = cdr(n)
	//-------------------------------------------------------------------------------------------

	// Pretreatment before checking a specification
	node_ptr new_spec = new_node(CONTEXT, n, Nil);  //used to get updated specification

    	node_ptr phi = cdr(n);
    	node_ptr neg_phi = new_node(NOT, cdr(n), Nil);
    	n->type = BELIEVE;
    	setcdr(n, neg_phi);
	//node_ptr old_spec = n;

	Eckl_spec_eliminate_redundant_NOT(new_spec, Nil);

	bdd_ptr res2_bdd = bdd_not(dd_manager, Eckl_eval_spec(fsm, n, Nil, new_spec));

	//n = car(new_spec);  //get the updated specification

	// Restore the old spec
	n->type = DESIRE;
	setcdr(n, phi);





	//(5) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	build_real_state_variables();	// Updates the ADD list representing real_state_variables


	//restore the total reachable states bdd
	bdd_free(dd_manager, reachable_states_bdd);
	reachable_states_bdd = total_reachable_states_bdd;


	bdd_ptr res_bdd = bdd_and(dd_manager, res1_bdd, res2_bdd);
	if(res1_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res1_bdd);
	if(res2_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res2_bdd);


	return res_bdd;
}

/**Function********************************************************************

  Synopsis           [Compile formula 'agent I (LTL subformula)' into BDD.]

  Description        [n must be of the form 'agent I (LTL subformula)'.]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr Eckl_eval_I_LTL_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	if (n == Nil) return(bdd_one(dd_manager));

	if(node_get_type(n)!=INTEND){
		rpterr("Eckl_eval_I_LTL_formula(): the main operator of node n is NOT 'I'.\n");
		nusmv_exit(1);
	}

	if(Eckl_spec_is_LTL_formula(cdr(n), context)!=1) {
		rpterr("Eckl_eval_I_LTL_formula(): the node cdr(n) is NOT a LTL formula.\n");
		nusmv_exit(1);
	}else if(Eckl_spec_is_bool_formula(cdr(n), context)==1){
		fprintf(nusmv_stdout, "Eckl_eval_I_LTL_formula(): The LTL formula '");
		print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "' is a pure bool formula.\n");
		nusmv_exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agent I LTL): evaluating ");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, " I ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}


	//get the name of the agent
	node_ptr mod_name = eval_struct(find_atom(car(n)), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));
	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_I_LTL_formula(): the agent '");
		print_node(nusmv_stdout, mod_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}


	//(1) Save the original status before checking n
	Eckl_SaveStatus();

	//(2) create auxiliary variables
	Eckl_AuxiVars_new_all(cdr(n), context);
	build_real_state_variables();	// Builds the ADD list representing real_state_variables.

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "--Show all variables including auxiliary variables--\n");
		Eckl_show_vars(true, true);
	}

	//(3) create the BDD of belief transition relation with auxiliary variables and create the justice formulas
	bdd_ptr AuxiTR;
	structJusticeFormulas AuxiJF;  AuxiJF.count=0;
	Eckl_new_AuxiTransRelation_JustFormulas(fsm, cdr(n), context, &AuxiTR, &AuxiJF);


	//get the BDD of WB' for the agent mod_name
	bdd_ptr bdd_Belief = Eckl_eval_BDI_possibleworld_variable(mod_name, BELIEF_WORLD);
	bdd_ptr bdd_Belief_Next = bdd_shift_forward(dd_manager, bdd_Belief);
	bdd_free(dd_manager, bdd_Belief);

	//get the BDD of WD' for the agent mod_name
	bdd_ptr bdd_Desire = Eckl_eval_BDI_possibleworld_variable(mod_name, DESIRE_WORLD);
	bdd_ptr bdd_Desire_Next = bdd_shift_forward(dd_manager, bdd_Desire);
	bdd_free(dd_manager, bdd_Desire);

	//get the BDD of WI' for the agent mod_name
	bdd_ptr bdd_Intend = Eckl_eval_BDI_possibleworld_variable(mod_name, INTENTION_WORLD);
	bdd_ptr bdd_Intend_Next = bdd_shift_forward(dd_manager, bdd_Intend);
	bdd_free(dd_manager, bdd_Intend);



	//AuxiTR = AuxiTR and WB'_i and WD'_i and WI'_i
	bdd_and_accumulate(dd_manager,
		&AuxiTR,
		bdd_and(dd_manager, bdd_and(dd_manager, bdd_Belief_Next, bdd_Desire_Next), bdd_Intend_Next));

	Eckl_FsmAddTableau(fsm, bdd_one(dd_manager), AuxiTR, &AuxiJF);

	if(bdd_Belief_Next!=(bdd_ptr)NULL) bdd_free(dd_manager, bdd_Belief_Next);
	if(bdd_Desire_Next!=(bdd_ptr)NULL) bdd_free(dd_manager, bdd_Desire_Next);
	if(bdd_Intend_Next!=(bdd_ptr)NULL) bdd_free(dd_manager, bdd_Intend_Next);


	//(4) Computation
	//(4.1) compute the cube(cube_bdd) of StateVariables - ObsVarCube
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_I_LTL_formula(): cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_LTL_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//(4.2) create the BDD(FC_bdd) of fairness constraint according to the justice formulas
	bdd_ptr FC_bdd = Eckl_eval_FairnessConstraint(fsm);
	if(FC_bdd==(bdd_ptr)NULL){
		rpterr("Eckl_eval_I_LTL_formula: FC_bdd is NULL.\n");
		nusmv_exit(1);
	}


	//(4.3) Compute res_bdd = Forall(cube_bdd)( (FC_bdd & intend_reachable_states_bdd) -> ltl2bool(cdr(n)) )

	bdd_ptr total_reachable_states_bdd = (bdd_ptr)NULL;
	if(reachable_states_bdd != (bdd_ptr)NULL) {
		total_reachable_states_bdd = bdd_dup(reachable_states_bdd);  //saving the total reachable states bdd
		bdd_free(dd_manager, reachable_states_bdd);
	}
	compute_reachable_states(fsm);  //create belief_reachable_states_bdd into reachable_states_bdd


	bdd_ptr tmp_bdd;
	tmp_bdd = bdd_and(dd_manager, FC_bdd, reachable_states_bdd);
//	tmp_bdd = bdd_and(dd_manager, FC_bdd, Eckl_compute_reachable_states(fsm));
	bdd_free(dd_manager, FC_bdd);

	bdd_ptr ltl2bool_bdd = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	if(ltl2bool_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_LTL_formula(): The BDD of LTL2Bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, tmp_bdd, ltl2bool_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_LTL_formula(): The BDD of FC_bdd & intend_reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp_bdd);
	bdd_free(dd_manager, ltl2bool_bdd);

	bdd_ptr res1_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_I_LTL_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);


	//(4.4) Compute res2_bdd = D_i \phi                \phi = cdr(n)

	// Pretreatment before checking a specification
	node_ptr new_spec = new_node(CONTEXT, n, Nil);  //used to get updated specification
    	n->type = DESIRE;

	bdd_ptr res2_bdd = Eckl_eval_spec(fsm, n, Nil, new_spec);

	// Restore the old spec
	n->type = INTEND;




	//(5) Restore the original status after checking E(n)
	Eckl_FsmDeleteTableau(fsm);
	Eckl_RestoreStatus();
	build_real_state_variables();	// Updates the ADD list representing real_state_variables


	//restore the total reachable states bdd
	bdd_free(dd_manager, reachable_states_bdd);
	reachable_states_bdd = total_reachable_states_bdd;


	bdd_ptr res_bdd = bdd_and(dd_manager, res1_bdd, res2_bdd);
	if(res1_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res1_bdd);
	if(res2_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, res2_bdd);


	return res_bdd;
}


/**Function********************************************************************

  Synopsis           [Compile formula E(fai(BDD of MSF1, BDD of MSF2, ..., BDD of MSFk)) or
agent K fai(BDD of MSF1, BDD of MSF2, ..., BDD of MSFk)  into BDD.]

  Description        [n must be of the form E(fai(BDD of MSF1, BDD of MSF2, ..., BDD of MSFk)) or
  agent K fai(BDD of MSF1, BDD of MSF2, ..., BDD of MSFk).]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec_recur]

******************************************************************************/
bdd_ptr Eckl_eval_EKCBDI_MaxSubformulas(Fsm_BddPtr fsm, node_ptr n, node_ptr context, node_ptr parent)
{
	int i;
	structMaxSubformulas MSFs;
	MSFs.count = 0;
	static int MSF_index = 0;

	//the old status which will be saved before they was modified in Eckl_MaxSubformula_new_one_variable()
	node_ptr old_state_variables;
	node_ptr old_all_variables;
	node_ptr old_all_symbols;

	//get all of the maximal subformula of the formula n, MSFs.count will be modified.
	if(node_get_type(n)==EE || node_get_type(n)==AA)
	{
		Eckl_spec_find_MaxSubformulas(car(n), context, n, &MSFs);
	}else if (	node_get_type(n)==KNOW ||
				node_get_type(n)==CKNOW ||
				node_get_type(n)==BELIEVE ||
				node_get_type(n)==DESIRE ||
				node_get_type(n)==INTEND)
	{
		Eckl_spec_find_MaxSubformulas(cdr(n), context, n, &MSFs);
	}else
	{
		rpterr("Eckl_eval_EKCBDI_MaxSubformulas: the main operator of n is NOT E,K,C,B,D or I.\n");
		nusmv_exit(1);
	}

	if(MSFs.count<=0) {
		fprintf(nusmv_stdout, "Eckl_eval_EKCBDI_MaxSubformulas: There is NOT any maximal subformula in the non-LTL formula: ");
		if(node_get_type(n)==EE || node_get_type(n)==AA)
			print_node(nusmv_stdout, car(n));
		else if(node_get_type(n)==KNOW || node_get_type(n)==CKNOW
			|| node_get_type(n)==BELIEVE || node_get_type(n)==DESIRE || node_get_type(n)==INTEND)
			print_node(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, ".\n");
		nusmv_exit(1);
	}

	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "Eckl_eval_EKCBDI_MaxSubformulas: Evaluating ");
		Eckl_print_spec(nusmv_stdout, n);
		fprintf(nusmv_stdout, "\n");
	}

	//save old status
	old_state_variables = state_variables;
	old_all_variables = all_variables;
	old_all_symbols = all_symbols;

	/*-------------------------------------------------------------------------------------------
	  Permute every MSF to atomic proposition. hence  E(car(n)) ==> E(LTL) or 'agent K cdr(n)' ==> 'agent K LTL'.
	-------------------------------------------------------------------------------------------*/
	for(i=0; i<MSFs.count; i++) {
		//evaluate the bdd for the maximal subformula
		//bdd_ptr MSF_bdd = Eckl_eval_spec_recur(fsm, MSFs.MSF[i].n, MSFs.MSF[i].context, MSFs.MSF[i].parent);
		bdd_ptr MSF_bdd = Eckl_eval_spec(fsm, MSFs.MSF[i].n, MSFs.MSF[i].context, MSFs.MSF[i].parent);
		if(MSF_bdd==(bdd_ptr)Nil) {
			rpterr("Eckl_eval_EKCBDI_MaxSubformulas: MSF_bdd==Nil.\n");
			nusmv_exit(1);
		}

		//create one bdd variable for the maximal subformula
		char s[10]="";
		char *MSFname = (char *)mystrcat(mystrcat(mystrcat(mystrcat("MSFVAR", s), "{"),
			Eckl_get_string(MSFs.MSF[i].n)),"}");

/*		char s[12]="";
		sprintf(s, "%d", MSF_index++);
		char *MSFname = (char *)mystrcat("MSFVAR", s);
*/
		node_ptr nMSFvar = (node_ptr)Eckl_MaxSubformula_new_one_variable(MSFname, MSF_bdd);
		if(nMSFvar==(node_ptr)Nil) {
			rpterr("Eckl_eval_EKCBDI_MaxSubformulas: nMSFvar==Nil.\n");
			nusmv_exit(1);
		}
		MSFs.MSF[i].var = nMSFvar;  //save the auxiliary variable representing the resulting BDD of this maximal subformula

		if (opt_verbose_level_gt(options, 3)) {
			fprintf(nusmv_stdout, "  Created MSFVAR: ");
			Eckl_show_var(nMSFvar);
			fprintf(nusmv_stdout, "\n");

			node_ptr data = lookup_symbol_hash(nMSFvar);
			if(data==(node_ptr)Nil) {rpterr("Eckl_eval_EKCBDI_MaxSubformulas: The data of MSFs.MSF[i] == NIL\n"); nusmv_exit(1);}
			if(node_get_type(data)!=VAR) {rpterr("Eckl_eval_EKCBDI_MaxSubformulas: node_get_type(data)!=VAR\n"); nusmv_exit(1);}
			if((add_ptr)car(data)==(add_ptr)Nil) {rpterr("Eckl_eval_EKCBDI_MaxSubformulas: car(data)==(add_ptr)Nil\n"); nusmv_exit(1);}
		}

		//----start of permuting the MSF to atomic proposition----
		if(MSFs.MSF[i].parent==(node_ptr)Nil) {
			rpterr("Eckl_eval_EKCBDI_MaxSubformulas: MSFs.MSF[i].parent==Nil.\n");
			nusmv_exit(1);
		}
		if(car(MSFs.MSF[i].parent)==MSFs.MSF[i].n)
			setcar(MSFs.MSF[i].parent, nMSFvar);
		else if(cdr(MSFs.MSF[i].parent)==MSFs.MSF[i].n)
			setcdr(MSFs.MSF[i].parent, nMSFvar);
		else{
			rpterr("Eckl_eval_EKCBDI_MaxSubformulas: MSFs.MSF[i].n is NOT the child of MSFs.MSF[i].parent.\n");
			nusmv_exit(1);
		}
		//----end of permuting the MSF to atomic proposition----
	}

	// After created all of variables for the maximal subformulas, builds the ADD list representing real_state_variables
	build_real_state_variables();

	//bdd_ptr res_bdd = Eckl_eval_spec_recur(fsm, n, context, parent);
	bdd_ptr res_bdd = Eckl_eval_spec(fsm, n, context, parent);

	//Restore the old specification
	for(i=0; i<MSFs.count; i++) {
		if(car(MSFs.MSF[i].parent)==MSFs.MSF[i].var)
			setcar(MSFs.MSF[i].parent, MSFs.MSF[i].n);
		else if(cdr(MSFs.MSF[i].parent)==MSFs.MSF[i].var)
			setcdr(MSFs.MSF[i].parent, MSFs.MSF[i].n);
		else{
			rpterr("Eckl_eval_EKCBDI_MaxSubformulas: MSFs.MSF[i].var is NOT the child of MSFs.MSF[i].parent.\n");
			nusmv_exit(1);
		}
	}

	//free all of the variables for the corresponding maximal subformulas
	Eckl_MaxSubformula_free_all_variables(&MSFs);

	//Restore the old status
	all_symbols = old_all_symbols;
	all_variables = old_all_variables;
	state_variables = old_state_variables;

	return res_bdd;
}


/**Function********************************************************************

  Synopsis    [Permute all of the temporal subformula in LTL formula 'n' to its corresponding auxiliary variables.]

  Description []

  SideEffects [the argument 'n']

  SeeAlso     []

******************************************************************************/
node_ptr bak_Eckl_LTL2bool(node_ptr n, node_ptr context)
{
	node_ptr rn;
	rn = bak_Eckl_LTL2bool_recur(n, context, (node_ptr)Nil);
	if(rn!=n) n=rn;
	return n;
}

/**Function********************************************************************

  Synopsis    [The recursive step of Eckl_LTL2bool().]

  Description []

  SideEffects [the argument 'n']

  SeeAlso     []

******************************************************************************/
static node_ptr bak_Eckl_LTL2bool_recur(node_ptr n, node_ptr context, node_ptr parent)
{
  int i;
  node_ptr tmp1, tmp2;
  if (n == (node_ptr)Nil) return (node_ptr)Nil;
  switch (node_get_type(n)){
  case CONTEXT:
		return bak_Eckl_LTL2bool(cdr(n), car(n));
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case NOT:
  case IMPLIES:
  case IFF:
		tmp1 = bak_Eckl_LTL2bool_recur(car(n), context, n);
		tmp2 = bak_Eckl_LTL2bool_recur(cdr(n), context, n);
		return n;

  //LTL temporal operators
  case OP_GLOBAL:
  case OP_FUTURE:
  case OP_NEXT:
  case UNTIL:
    for(i=0; i<AuxiVars_num; i++){
		if(AuxiVars[i].n==n){
			if(parent!=(node_ptr)Nil){
				if(car(parent)==n){
					setcar(parent, AuxiVars[i].nvar);
					return AuxiVars[i].nvar;
				}else if (cdr(parent)==n){
					setcdr(parent, AuxiVars[i].nvar);
					return AuxiVars[i].nvar;
				}else{
					printf("Eckl_LTL2bool_recur(): the formula is not its parent's child.\n");
					return (node_ptr)Nil;
				}
				break;
			}else{//	(parent==(node_ptr)Nil)
				return AuxiVars[i].nvar;
			}
		}//end of if(AuxiVars[i].n==n){
    }
	printf("Eckl_LTL2bool_recur(): can not find the node in AuxiVars[].\n");
	return (node_ptr)Nil;
  default:
    { // for all the other we call the eval, and convert the result from ADD to BDD.
      return n;
	}
  }
	return n;
}

/**Function********************************************************************

  Synopsis           [Convert a LTL formula into pure boolean formula and compile it into BDD.]

  Description        [node n must be a LTL formula. All of the principally temporal formulas will be
  replaced by its corresponding auxiliary variables.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_eval_LTL2Bool(Fsm_BddPtr fsm, node_ptr n, node_ptr context)
{
	int isLTL, i;
	bdd_ptr arg1, arg2, res;

  if (n == Nil) return(bdd_one(dd_manager));
  if(Eckl_spec_is_LTL_formula(n, context)!=1){
	fprintf(nusmv_stdout, "Eckl_eval_LTL2Bool: '");
	print_node(nusmv_stdout, n);
	fprintf(nusmv_stdout, "' is NOT a pure LTL formula.\n");
	nusmv_exit(1);
  }
  switch (node_get_type(n)){
  case CONTEXT: return(Eckl_eval_LTL2Bool(fsm, cdr(n),car(n)));

  case AND:
	set_the_node(n);
	arg1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	arg2 = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_and, arg1, arg2, 1, 1, 1);
	bdd_free(dd_manager, arg1);
	bdd_free(dd_manager, arg2);
	return(res);
  case OR:
	set_the_node(n);
	arg1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	arg2 = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, arg1, arg2, 1, 1, 1);
	bdd_free(dd_manager, arg1);
	bdd_free(dd_manager, arg2);
	return(res);
  case XOR:
	set_the_node(n);
	arg1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	arg2 = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, 1, 1, 1);
	bdd_free(dd_manager, arg1);
	bdd_free(dd_manager, arg2);
	return(res);
  case XNOR:
	set_the_node(n);
	arg1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	arg2 = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, 1, 1, -1);
	bdd_free(dd_manager, arg1);
	bdd_free(dd_manager, arg2);
	return(res);
  case NOT:
	set_the_node(n);
	arg1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	res = Eckl_unary_bdd_op(fsm, dd_manager, bdd_not, arg1, 1, 1);
	bdd_free(dd_manager, arg1);
	return(res);
  case IMPLIES:
	set_the_node(n);
	arg1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	arg2 = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, arg1, arg2, 1, -1, 1);
	bdd_free(dd_manager, arg1);
	bdd_free(dd_manager, arg2);
	return(res);
  case IFF:
	set_the_node(n);
	arg1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	arg2 = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
	res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_xor, arg1, arg2, -1, 1, 1);
	bdd_free(dd_manager, arg1);
	bdd_free(dd_manager, arg2);
	return(res);

  //LTL temporal operators
  case OP_GLOBAL:
  case OP_FUTURE:
  case OP_NEXT:
  case UNTIL:
	//find the corresponding AuxiVar
    	for(i=0; i<AuxiVars_num; i++){
		if(AuxiVars[i].n!=n) continue;
		//found the corresponding AuxiVar, and evaluate the BDD of auxiliary variable
      		bdd_ptr res_bdd;
      		add_ptr res_add = eval(AuxiVars[i].nvar, Nil);

      		if (res_add == NULL) {
        		rpterr("Eckl_eval_LTL2Bool(): res_add = NULL after a call to \"eval\".");
        		nusmv_exit(1);
      		}
      		res_bdd = add_to_bdd(dd_manager, res_add);
      		add_free(dd_manager, res_add);
      		return(res_bdd);
    	}
	printf("Eckl_eval_LTL2Bool(): can not find the node in AuxiVars[].\n");
	return bdd_one(dd_manager);

  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */
      bdd_ptr res_bdd;
      add_ptr res_add = eval(n, context);

      if (res_add == NULL) {
        rpterr("Eckl_eval_spec: res_add = NULL after a call to \"eval\".");
        nusmv_exit(1);
      }
      res_bdd = add_to_bdd(dd_manager, res_add);
      add_free(dd_manager, res_add);
      return(res_bdd);
    }
  }
}

/**Function********************************************************************

  Synopsis    [Transition Relation: Create one transition relation for the X temporal subformula n.]

  Description [n must be a LTL formula and it is of the form X(car(n)).]

  SideEffects []

  SeeAlso     []

******************************************************************************/
bdd_ptr Eckl_new_X_AuxiTransRelation(Fsm_BddPtr fsm, node_ptr n, node_ptr context)
{
	if(n==(node_ptr)Nil) {printf("Eckl_new_X_AuxiTransRelation(): n==Nil.\n"); return bdd_one(dd_manager);}
	if(node_get_type(n)!=OP_NEXT) {printf("Eckl_new_X_AuxiTransRelation(): the type of node n is NOT OP_NEXT.\n"); return bdd_one(dd_manager);}

	//bdd_tmp2 = the prime version of LTL2bool of car(n)
	bdd_ptr bdd_tmp1 = Eckl_eval_LTL2Bool(fsm, car(n), context);
	bdd_ptr bdd_tmp2 = bdd_permute(dd_manager, bdd_tmp1, current2next);
	bdd_free(dd_manager, bdd_tmp1);

	int i;
	boolean found = false;
	//find the corresponding AuxiVar
    for(i=0; i<AuxiVars_num; i++) if(AuxiVars[i].n==n) {found=true; break;}
	if(!found) {
		printf("Eckl_new_X_AuxiTransRelation(): can not find the node in AuxiVars[].\n");
		return bdd_one(dd_manager);
	}
	//found the corresponding AuxiVar, and evaluate the BDD of auxiliary variable
    bdd_ptr auxivar_bdd;
    add_ptr auxivar_add = eval(AuxiVars[i].nvar, Nil);
    if (auxivar_add == NULL) {
      rpterr("Eckl_new_X_AuxiTransRelation(): res = NULL after a call to \"eval\".");
      nusmv_exit(1);
    }
    auxivar_bdd = add_to_bdd(dd_manager, auxivar_add);
    add_free(dd_manager, auxivar_add);
	//auxivar_bdd = the BDD of the AuxiVar

	//auxivar_bdd <-> bdd_tmp2
	bdd_ptr bdd_tmp3 = bdd_xor(dd_manager, auxivar_bdd, bdd_tmp2);
	bdd_ptr bdd_res = eval_sign(bdd_tmp3, -1);
	bdd_free(dd_manager, auxivar_bdd);
	bdd_free(dd_manager, bdd_tmp2);
	bdd_free(dd_manager, bdd_tmp3);
	return(bdd_res);
}

/**Function********************************************************************

  Synopsis    [Transition Relation: Create one transition relation for the U temporal subformula n.]

  Description [n must be a LTL formula and it is of the form car(n) U cdr(n).
  		U_bdd -- the return auxiliary transition relation
  		JF -- the return justice formula]

  SideEffects []

  SeeAlso     []

******************************************************************************/
void Eckl_new_U_AuxiTransRelation_JustFormula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, bdd_ptr * U_bdd, structJusticeFormulas * JF)
{
	if(n==(node_ptr)Nil) {printf("Eckl_new_U_AuxiTransRelation_JustFormula(): n==Nil.\n"); *U_bdd=bdd_one(dd_manager); return;}
	if(node_get_type(n)!=UNTIL) {printf("Eckl_new_U_AuxiTransRelation_JustFormula(): the type of node n is NOT UNTIL.\n"); *U_bdd=bdd_one(dd_manager); return;}

	bdd_ptr bdd_a = Eckl_eval_LTL2Bool(fsm, car(n), context);
	bdd_ptr bdd_b = Eckl_eval_LTL2Bool(fsm, cdr(n), context);
    if (bdd_a == NULL) {rpterr("Eckl_new_U_AuxiTransRelation_JustFormula(): bdd_a = NULL.\n"); nusmv_exit(1);}
    if (bdd_b == NULL) {rpterr("Eckl_new_U_AuxiTransRelation_JustFormula(): bdd_b = NULL.\n"); nusmv_exit(1);}

	int i;
	boolean found = false;
	//find the corresponding AuxiVar
    for(i=0; i<AuxiVars_num; i++) if(AuxiVars[i].n==n) {found=true; break;}
	if(!found) {
		printf("Eckl_new_U_AuxiTransRelation_JustFormula(): can not find the node in AuxiVars[].\n");
		nusmv_exit(1);
	}
	//found the corresponding AuxiVar, and evaluate the BDD of auxiliary variable
    bdd_ptr auxivar_bdd, next_auxivar_bdd;
    add_ptr auxivar_add = eval(AuxiVars[i].nvar, Nil);
    if (auxivar_add == NULL) {
      rpterr("Eckl_new_U_AuxiTransRelation_JustFormula(): auxivar_add = NULL after a call to \"eval\".\n");
      nusmv_exit(1);
    }
	//auxivar_bdd = the BDD of the AuxiVar
    auxivar_bdd = add_to_bdd(dd_manager, auxivar_add);
    if (auxivar_bdd == NULL) {
      rpterr("Eckl_new_U_AuxiTransRelation_JustFormula(): auxivar_bdd = NULL.\n");
      nusmv_exit(1);
    }
    add_free(dd_manager, auxivar_add);
	next_auxivar_bdd = bdd_permute(dd_manager, auxivar_bdd, current2next);
    if (next_auxivar_bdd == NULL) {
      rpterr("Eckl_new_U_AuxiTransRelation_JustFormula(): next_auxivar_bdd = NULL.\n");
      nusmv_exit(1);
    }

	bdd_ptr bdd_tmp1 = bdd_and(dd_manager, bdd_a, next_auxivar_bdd);
	bdd_or_accumulate(dd_manager, &bdd_tmp1, bdd_b);
	//<->
	bdd_ptr bdd_tmp2 = bdd_xor(dd_manager, auxivar_bdd, bdd_tmp1);
	*U_bdd = eval_sign(bdd_tmp2, -1);

	//------start code for creating the justice formula------
	JF->JF[JF->count].n = n;
	JF->JF[JF->count].context = context;

	bdd_ptr bdd_tmp3 = eval_sign(auxivar_bdd, -1);
	bdd_or_accumulate(dd_manager, &bdd_tmp3, bdd_b);

//	if(JF->JF[JF->count].bdd!=(bdd_ptr)Nil) bdd_free(dd_manager, JF->JF[JF->count].bdd);
	JF->JF[JF->count].bdd = bdd_dup(bdd_tmp3);
	JF->count++;
	//------end code for creating the justice formula------

	bdd_free(dd_manager, bdd_a);
	bdd_free(dd_manager, bdd_b);
	bdd_free(dd_manager, auxivar_bdd);
	bdd_free(dd_manager, next_auxivar_bdd);
	bdd_free(dd_manager, bdd_tmp1);
	bdd_free(dd_manager, bdd_tmp2);
	bdd_free(dd_manager, bdd_tmp3);
}

/**Function********************************************************************

  Synopsis    [Tableau Construction: The Main Function for creating the the auxiliary transition relation and the justice
  formulas for ECKLn model checking.]

  Description [the node n must be a LTL formula. JF is the return justice formulas.]

  SideEffects []

  SeeAlso     []

******************************************************************************/
void Eckl_new_AuxiTransRelation_JustFormulas(Fsm_BddPtr fsm, node_ptr n, node_ptr context, bdd_ptr * AuxiTR, structJusticeFormulas * JF)
{
	if (n == (node_ptr)Nil) return;
	*AuxiTR = bdd_one(dd_manager);

	Eckl_clear_JustFormulas(JF);
	Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, n, context, AuxiTR, JF);
/*
	//add TRUE in JF
	if ((JF->count==0) && (Compile_FsmBddGetFairStates(fsm)==(bdd_ptr)NULL))
	{
		JF->JF[JF->count].bdd = bdd_one(dd_manager);
		JF->count++;
	}
*/
}

/**Function********************************************************************

  Synopsis    [Tableau Construction: The recursive process of creating the the auxiliary transition
  relation for ECKLn model checking.]

  Description [the node n must be a LTL formula.]

  SideEffects []

  SeeAlso     []

******************************************************************************/
static int Eckl_new_AuxiTransRelation_JustFormulas_recur(Fsm_BddPtr fsm, node_ptr n, node_ptr context, bdd_ptr * AuxiTR, structJusticeFormulas * JF)
{
  if (n == (node_ptr)Nil) return 0;
  switch (node_get_type(n)){
  case CONTEXT:
    return Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, cdr(n), car(n), AuxiTR, JF);
  case AND:
  case OR:
  case XOR:
  case XNOR:
  case NOT:
  case IMPLIES:
  case IFF:
/* ----the following operators does not appear in the formula because the formula is a LTL formula
  case EX:
  case AX:
  case EF:
  case AG:
  case AF:
  case EG:
  case EU:
  case AU:
*/
	Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, car(n), context, AuxiTR, JF);
	Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, cdr(n), context, AuxiTR, JF);
    return 0;

/*  case KNOW:
	Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, cdr(n), context, AuxiTR, JF);
    return 0;*/

  //LTL temporal operators, create one variable once encouter a LTL temporal operator.
//  case OP_GLOBAL:
//  case OP_FUTURE:
  case OP_NEXT:
  {
	bdd_ptr X_bdd = Eckl_new_X_AuxiTransRelation(fsm, n, context);
	if(X_bdd==(bdd_ptr)Nil){
		rpterr("Eckl_new_AuxiTransRelation_JustFormulas_recur(): X_bdd==Nil.\n");
		nusmv_exit(1);
	}
	bdd_and_accumulate(dd_manager, AuxiTR, X_bdd);

	Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, car(n), context, AuxiTR, JF);
	return 0;
  }
  case UNTIL:
  {
	bdd_ptr U_bdd;
	Eckl_new_U_AuxiTransRelation_JustFormula(fsm, n, context, &U_bdd, JF);
	if(U_bdd==(bdd_ptr)Nil){
		rpterr("Eckl_new_AuxiTransRelation_JustFormulas_recur(): U_bdd==Nil.\n");
		nusmv_exit(1);
	}
	bdd_and_accumulate(dd_manager, AuxiTR, U_bdd);

	Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, car(n), context, AuxiTR, JF);
	Eckl_new_AuxiTransRelation_JustFormulas_recur(fsm, cdr(n), context, AuxiTR, JF);
	return 0;
  }
  default:
    { /* for all the other we call the eval, and convert the result from ADD to BDD. */
		return 0;
	}
  }

  return 0;
}

/**Function********************************************************************

  Synopsis    [evaluate the bdd of fairness constraint according to the justice formulas JF.]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
bdd_ptr bak_old_Eckl_eval_FairnessConstraint(Fsm_BddPtr fsm, structJusticeFormulas * JF)
{
	bdd_ptr Z1, Z2, ZJ, tmp, res;
	int i=0;

	Z1 = bdd_one(dd_manager);
	while (1) {
		//Z2 (J[0]) & Z2 (J[1]) & ... & Z2 (J[starJFCount-1])
	  	Z2 = bdd_one(dd_manager);
	  	for(i=0; i<JF->count; i++) {
			//calcuate res = EX(EU(true, Z & J[i])
			ZJ = bdd_and(dd_manager, Z1, JF->JF[i].bdd);
			tmp = eu(fsm, bdd_one(dd_manager), ZJ);
			bdd_free(dd_manager, ZJ);
			res = ex(fsm, tmp);
			bdd_free(dd_manager, tmp);

			//Z2 = Z2 & res
			bdd_and_accumulate(dd_manager, &Z2, res);
			bdd_free(dd_manager, res);
		}
		if (Z1==Z2)
			break;
		else {
			//Z1 = Z2
			bdd_free(dd_manager, Z1);
			Z1 = bdd_dup(Z2);
			bdd_free(dd_manager, Z2);
		}
	}
	bdd_free(dd_manager, Z2);
	return Z1;
}

/*---------------------------------------------------------------------------*/
/* Definition of static functions                                            */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis           [Auxiliary function to  handle <tt>CTL</tt> model
  checking under <em>FAIRNESS</em> constraints.]

  Description        [This function is used in the computation of
  <tt>EG alpha</tt> under <em>FAIRNESS</em> constraints. For each
  fairness constraint <tt>f</tt> in the list <code>fc</code>, it
  computes the set of states satisfying <tt>E \[g U f\]<tt>, then
  intersects the corresponding partial result and the resulting set is
  returned back.]

  SideEffects        []

  SeeAlso            [eg eu]

******************************************************************************/
static bdd_ptr Eckl_fair_iter(Fsm_BddPtr fsm, bdd_ptr g, node_ptr fc)
{
  if(fc == Nil) return(bdd_one(dd_manager));
  if(node_get_type(fc) == CONS){
    bdd_ptr left, right, res;

    left = Eckl_fair_iter(fsm, g, car(fc));
    right = Eckl_fair_iter(fsm, g, cdr(fc));
    res = bdd_and(dd_manager, left, right);
    bdd_free(dd_manager, left);
    bdd_free(dd_manager, right);
    return(res);
  }
  if(node_get_type(fc) == BDD){
    bdd_ptr tmp_1, tmp_2, res;

    tmp_1 = bdd_dup((bdd_ptr)car(fc));
    tmp_2 = bdd_and(dd_manager, g, tmp_1);
    res = eu(fsm, g, tmp_2);
    bdd_free(dd_manager, tmp_1);
    bdd_free(dd_manager, tmp_2);
    return(res);
  }
  internal_error("fair_iter: fc->type = %d", node_get_type(fc));
}

/**Function********************************************************************

  Synopsis           [Set of states satisfying <i>EG(g)</i> under (full) fairness constraints fsm->Justice+(fsm->Compassion).]

  Description        [Eckl_eg(g) = eg(g) & for_all_i[eg(g, p_i)->eg(g, q_i),
  								where (p_i, q_i) belongs to fsm->Compassion]

  SideEffects        []

  SeeAlso            [eu ex ef]

******************************************************************************/
bdd_ptr Eckl_eg(Fsm_BddPtr fsm, bdd_ptr g)
{
	bdd_ptr eg_J = eg(fsm, g);

	if(Eckl_get_CompassionType()==Compassion_NoType) return eg_J;

	bdd_ptr res_bdd = bdd_one(dd_manager);
	Eckl_ComputeCompassion(fsm, Compile_FsmBddGetCompassion(fsm), g, &res_bdd);
	if(res_bdd==(bdd_ptr)Nil){rpterr("Eckl_eg(): Eckl_ComputeCompassion() return a Nil bdd.\n"); nusmv_exit(1);}

	bdd_and_accumulate(dd_manager, &res_bdd, eg_J);

	if(eg_J!=(bdd_ptr)Nil) bdd_free(dd_manager, eg_J);

	return res_bdd;
}

/**Function********************************************************************

  Synopsis           [Set of states satisfying <i>EG(g)</i> under fairness constraints justices.]

  Description        [Computes the set of states satisfying <i>EG(g)</i>.]

  SideEffects        []

  SeeAlso            [eu ex ef]

******************************************************************************/
bdd_ptr Eckl_eg_specify_justices(Fsm_BddPtr fsm, bdd_ptr g, node_ptr justices)
{
  int n = 1;
  bdd_ptr tmp_1;
  bdd_ptr Y = bdd_dup(g);
  bdd_ptr oldY = bdd_zero(dd_manager);

  if(justices==(node_ptr)Nil) {rpterr("Eckl_eg(): justices==(node_ptr)Nil\n"); nusmv_exit(1);}

	//----update fsm->Fairstates to the evaluation of eg(g) under argument justices----
	node_ptr old_Justice = Compile_FsmBddGetJustice(fsm);
	Compile_FsmBddSetJustice(fsm, justices);

	bdd_ptr old_fair_states = Compile_FsmBddGetFairStates(fsm);
	Compile_FsmBddSetFairStates(fsm, eg(fsm, bdd_one(dd_manager)));  //Mc_ComputeFairStates(fsm) = EG(true) under justices
	//----------------------------------------------------------------------

  if (opt_verbose_level_gt(options, 1))
    indent_node(nusmv_stderr, "Eckl_eg: computing fixed point approximations for ", get_the_node(), " ...\n");
  while (Y != oldY) {
    if (opt_verbose_level_gt(options, 1)) {
      indent(nusmv_stderr);
      fprintf(nusmv_stderr, "size of Y%d = %g states, %d BDD nodes\n",
              n++, bdd_count_states(dd_manager, Y), bdd_size(dd_manager, Y));
    }
    bdd_free(dd_manager, oldY);
    oldY = bdd_dup(Y);
    {
      bdd_ptr Z = Eckl_fair_iter(fsm, Y, justices);

      bdd_and_accumulate(dd_manager, &Y, Z);
      bdd_free(dd_manager, Z);
    }
    tmp_1 = ex(fsm, Y);
    bdd_and_accumulate(dd_manager, &Y, tmp_1);
    bdd_free(dd_manager, tmp_1);
  }
  bdd_free(dd_manager, oldY);

	//----restore fsm->Fairstates to the evaluation of eg(g) under old justice----
	Compile_FsmBddSetJustice(fsm, old_Justice);

	bdd_ptr fair_states = bdd_dup(Compile_FsmBddGetFairStates(fsm));
	if (fair_states != (bdd_ptr)NULL) bdd_free(dd_manager, fair_states);
	Compile_FsmBddSetFairStates(fsm, old_fair_states);  //Mc_ComputeFairStates(fsm) = EG(true) under old_justice
	//----------------------------------------------------------------------

  return(Y);
}

/**Function********************************************************************

  Synopsis           [Clear all of the justice formulas in JF.]

  Description        []

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_clear_JustFormulas(structJusticeFormulas * JF)
{
	if(JF==NULL) return;

	int i;
	for(i=0; i<JF->count; i++) {
		if(JF->JF[i].bdd != NULL)
			bdd_free(dd_manager, JF->JF[i].bdd);
	}
	JF->count = 0;
}

/**Function********************************************************************

  Synopsis           [Applies unary operation.]

  Description        [Takes in input the expression <code>n</code> and a
  unary operation <code>op</code>. Evaluates <code>n</n> and applies to this
  partial result the unary operator <code>op</code>. The sign of the
  partial result and of the result depends respectively from the flag
  <code>argflag</code> and <code>resflag</code>.]

  SideEffects        []

  SeeAlso            [binary_bdd_op, ternary_bdd_op, quaternary_bdd_op]

******************************************************************************/
bdd_ptr Eckl_unary_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFDB op, bdd_ptr arg,
                            int resflag, int argflag)
{
  nusmv_assert(arg != (bdd_ptr)NULL);

  /* compute and ref the result according to sign of the result */
  return eval_sign(op(dd, eval_sign(arg, argflag)), resflag);
}

/**Function********************************************************************

  Synopsis           [Applies binary operation.]

  Description        [Takes in input the expression <code>n</code> and a
  binary operation <code>op</code>. Extracts from <code>n</n> the operands
  and evaluates them. The binary operator <code>op</code> is then applied
  to these partial results. The sign of the partial results and of the
  result depends respectively from the flags <code>argflag1</code>,
  <code>argflag2</code> and <code>resflag</code>.]

  SideEffects        []

  SeeAlso            [unary_bdd_op, ternary_bdd_op, quaternary_bdd_op]

******************************************************************************/
bdd_ptr Eckl_binary_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFDBB op, bdd_ptr arg1, bdd_ptr arg2,
                             int resflag, int argflag1, int argflag2)
{
  nusmv_assert(arg1 != (bdd_ptr)NULL);
  nusmv_assert(arg2 != (bdd_ptr)NULL);

  return eval_sign(op(dd, eval_sign(arg1, argflag1), eval_sign(arg2, argflag2)), resflag);
}


/**Function********************************************************************

  Synopsis           [Applies unary operation.]

  Description        [Takes in input the expression <code>n</code> and a
  unary operation <code>op</code>. Evaluates <code>n</n> and applies to this
  partial result the unary operator <code>op</code>. The sign of the
  partial result and of the result depends respectively from the flag
  <code>argflag</code> and <code>resflag</code>.]

  SideEffects        []

  SeeAlso            [binary_bdd_op, ternary_bdd_op, quaternary_bdd_op]

******************************************************************************/
bdd_ptr Eckl_unary_mod_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFFB op, bdd_ptr arg,
                                int resflag, int argflag)
{
  nusmv_assert(arg != (bdd_ptr)NULL);

  /* compute and ref the result according to sign of the result */
  return eval_sign(op(fsm, eval_sign(arg, argflag)), resflag);
}

/**Function********************************************************************

  Synopsis           [Applies binary operation.]

  Description        [Takes in input the expression <code>n</code> and a
  binary operation <code>op</code>. Extracts from <code>n</n> the operands
  and evaluates them. The binary operator <code>op</code> is then applied
  to these partial results. The sign of the partial results and of the
  result depends respectively from the flags <code>argflag1</code>,
  <code>argflag2</code> and <code>resflag</code>.]

  SideEffects        []

  SeeAlso            [unary_bdd_op, ternary_bdd_op, quaternary_bdd_op]

******************************************************************************/
bdd_ptr Eckl_binary_mod_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFFBB op, bdd_ptr arg1, bdd_ptr arg2,
                                 int resflag, int argflag1, int argflag2)
{
  nusmv_assert(arg1 != (bdd_ptr)NULL);
  nusmv_assert(arg2 != (bdd_ptr)NULL);

  return eval_sign(op(fsm, eval_sign(arg1, argflag1), eval_sign(arg2, argflag2)), resflag);
}

/**Function********************************************************************

  Synopsis           [Applies binary operation.]

  Description        [Takes in input the expression <code>n</code> and a
  binary operation <code>op</code>. Extracts from <code>n</n> the operands
  and evaluates them. The binary operator <code>op</code> is then applied
  to these partial results. The sign of the partial results and of the
  result depends respectively from the flags <code>argflag1</code>,
  <code>argflag2</code> and <code>resflag</code>.<br>
  The only difference between this and "binary_mod_bdd_op" is that the
  result of the application of the operation passed as argument is not
  referenced. This is used for example in the "minu" and "maxu" operations.]

  SideEffects        []

  SeeAlso            [unary_bdd_op, ternary_bdd_op, quaternary_bdd_op]

******************************************************************************/
bdd_ptr Eckl_binary_mod_bdd_op_ns(Fsm_BddPtr fsm, DdManager * dd, BDDPFFBB op, bdd_ptr arg1, bdd_ptr arg2,
                                    int resflag, int argflag1, int argflag2)
{
  nusmv_assert(arg1 != (bdd_ptr)NULL);
  nusmv_assert(arg2 != (bdd_ptr)NULL);

  return op(fsm, eval_sign(arg1, argflag1), eval_sign(arg2, argflag2));

}

/**Function********************************************************************

  Synopsis           [Applies ternary operation.]

  Description        [Takes in input the expression <code>n</code> and a
  ternary operation <code>op</code>. Extracts from <code>n</n> the operands
  and evaluates them.<br>
  The second and third arguments have to evaluate to numbers. And
  <code>op</code> is a function that takes as input an BDD an two integers.
  The ternary operator <code>op</code> is then applied to these partial
  results. The sign of the partial result and of the result depends
  respectively from the flags <code>argflag</code> and <code>resflag</code>.]

  SideEffects        []

  SeeAlso            [unary_bdd_op, binary_bdd_op, quaternary_bdd_op]

******************************************************************************/
bdd_ptr ternary_mod_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFFBII op, node_ptr n,
                                  int resflag, int argflag, node_ptr context)
{
  bdd_ptr tmp_1, tmp_2, res;
  bdd_ptr arg1 = Eckl_eval_spec(fsm, car(n), context, n);
  int arg2 = eval_num(car(cdr(n)), context);
  int arg3 = eval_num(cdr(cdr(n)), context);

  set_the_node(n);

  tmp_1 = eval_sign(arg1, argflag);
  tmp_2 = op(fsm, tmp_1, arg2, arg3);
  res = eval_sign(tmp_2, resflag);

  bdd_free(dd, tmp_1);
  bdd_free(dd, tmp_2);
  bdd_free(dd, arg1);

  return(res);
}

/**Function********************************************************************

  Synopsis           [Applies quaternary operation.]

  Description        [Takes in input the expression <code>n</code> and a
  quaternary operation <code>op</code>. Extracts from <code>n</n> the operands
  and evaluates them.<br>
  The third and fourth arguments have to evaluate to numbers. And
  <code>op</code> is a function that takes as input two BDD and two integers.
  The quaternary operator <code>op</code> is then applied to these partial
  results. The sign of the partial result and of the result depends
  respectively from the flags <code>argflag1</code>, <code>argflag2</code> and
  <code>resflag</code>.]

  SideEffects        []

  SeeAlso            [unary_bdd_op, binary_bdd_op, ternary_bdd_op]

******************************************************************************/
bdd_ptr quad_mod_bdd_op(Fsm_BddPtr fsm, DdManager * dd, BDDPFFBBII op, node_ptr n,
                               int resflag, int argflag1, int argflag2, node_ptr context)
{
  bdd_ptr tmp_1, tmp_2, tmp_3, res;
  bdd_ptr arg1 = Eckl_eval_spec(fsm, car(car(n)), context, car(n));
  bdd_ptr arg2 = Eckl_eval_spec(fsm, cdr(car(n)), context, car(n));
  int arg3 = eval_num(car(cdr(n)), context);
  int arg4 = eval_num(cdr(cdr(n)), context);

  set_the_node(n);

  tmp_1 = eval_sign(arg1, argflag1);
  tmp_2 = eval_sign(arg2, argflag1);
  tmp_3 = op(fsm, tmp_1, tmp_2, arg3, arg4);
  res = eval_sign(tmp_3, resflag);

  bdd_free(dd, tmp_1);
  bdd_free(dd, tmp_2);
  bdd_free(dd, tmp_3);
  bdd_free(dd, arg1);
  bdd_free(dd, arg2);

  return(res);
}


/**Function********************************************************************

  Synopsis           [Complements a BDD according to a flag.]

  Description        [Given the BDD <code>a</code>, this function returns
  the negation of BDD <code>a</code> or <code>a</code> itself according the
  value of <code>flag</code>. If <code>flag = -1</code> then returns <code>not
  a</code>, else returns <code>a</code>. It is important that the BDD is a
  zero/one BDD (i.e. it has only zero or one as leaf).]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
static bdd_ptr eval_sign(bdd_ptr a, int flag)
{
  if (flag == -1 ) return(bdd_not(dd_manager, a));
  else {
    bdd_ref(a);
    return(a);
  }
}

/**Function********************************************************************

  Synopsis           [and_forall_i[eg(f, p_i)->eg(f, q_i)]

  Description        [(p_i, q_i) belongs to cc, cc is specified compassion, J is fsm->Justice.
  								eg(f, J) is the CTL function eg(f) under Justice J.
  								cc -- the list of compassion, cc=(p_1, q_1, p_2, q_2, ... , p_n, q_n)]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_ComputeCompassion(Fsm_BddPtr fsm, node_ptr cc, bdd_ptr f, bdd_ptr * res_bdd)
{
	static int index=-1;
	static bdd_ptr p=(bdd_ptr)Nil;
	if(cc == Nil) return;

	if(node_get_type(cc) == CONS){
		(void)Eckl_ComputeCompassion(fsm, car(cc), f, res_bdd);
		(void)Eckl_ComputeCompassion(fsm, cdr(cc), f, res_bdd);
		return;
	}

	if(node_get_type(cc) == BDD){
		bdd_ptr tmp_1, tmp_2, res;
		tmp_1 = bdd_dup((bdd_ptr)car(cc));
		if(tmp_1==(bdd_ptr)Nil) 	internal_error("Eckl_ComputeCompassion: bdd is Nil\n");

		index++;
		if((index % 2)==0){ //p
			p = tmp_1;
		}else{ //q = tmp_1
			bdd_ptr q = tmp_1;

			//eg(f, p_i)->eg(f, q_i)
			bdd_ptr eg_bdd1 = Eckl_eg_specify_justices(fsm, f, cons(new_node(BDD, (node_ptr)p, (node_ptr)Nil), (node_ptr)Nil));
			bdd_ptr eg_bdd2 = Eckl_eg_specify_justices(fsm, f, cons(new_node(BDD, (node_ptr)q, (node_ptr)Nil), (node_ptr)Nil));
			res = Eckl_binary_bdd_op(fsm, dd_manager, bdd_or, eg_bdd1, eg_bdd2, 1, -1, 1);

			bdd_and_accumulate(dd_manager, res_bdd, res);

			if(res!=(bdd_ptr)Nil) bdd_free(dd_manager, res);
			if(eg_bdd1!=(bdd_ptr)Nil) bdd_free(dd_manager, eg_bdd1);
			if(eg_bdd2!=(bdd_ptr)Nil) bdd_free(dd_manager, eg_bdd2);
			if(p!=(bdd_ptr)Nil) bdd_free(dd_manager, p);
			if(tmp_1!=(bdd_ptr)Nil) bdd_free(dd_manager, q);
		}

		return;
	}

	internal_error("Eckl_ComputeCompassion: cc->type = %d", node_get_type(cc));
}

/**Function********************************************************************

  Synopsis           [Set of <code>fair_states</code> for ECKLn model checking.]

  Description        [Compute fair(J, C) = fair(J) & for_all_i[eg(true, p_i)->eg(true, q_i)]
  								where 	fair(J)=eg(true, J).
  								(p_i, q_i) belongs to C, C is compassion, J is Justice.
  								eg(f, J) is the CTL function eg(f) under Justice J.]

  SideEffects        []

  SeeAlso            [eg]

******************************************************************************/
bdd_ptr bak_Eckl_ComputeFairStates(Fsm_BddPtr fsm)
{
	bdd_ptr result, one;
	extern node_ptr one_number;

	//fair(J)=eg(true, J)
	set_the_node(one_number);
	one = bdd_one(dd_manager);
	result = eg(fsm, one);
	if(result==(bdd_ptr)Nil){rpterr("Eckl_ComputeFairStates(): eg(true, J) return Nil bdd.\n"); nusmv_exit(1);}
	bdd_free(dd_manager, one);

	if(Eckl_get_CompassionType()==Compassion_NoType) return(result);

	//cc_bdd = and_forall_i[eg(true, p_i)->eg(true, q_i)
	bdd_ptr cc_bdd = bdd_one(dd_manager);
	Eckl_ComputeCompassion(fsm, Compile_FsmBddGetCompassion(fsm), bdd_one(dd_manager), &cc_bdd);
	if(cc_bdd==(bdd_ptr)Nil){rpterr("Eckl_ComputeFairStates(): Eckl_ComputeCompassion() return Nil bdd.\n"); nusmv_exit(1);}

	bdd_and_accumulate(dd_manager, &result, cc_bdd);

	bdd_free(dd_manager, cc_bdd);
	return(result);
}

static bdd_ptr Eckl_ComputeFairStates_recur(Fsm_BddPtr fsm, bdd_ptr Z_bdd, node_ptr fc)
{
  if(fc == Nil) return(bdd_one(dd_manager));
  if(node_get_type(fc) == CONS){
    bdd_ptr left_bdd, right_bdd, res_bdd;

    left_bdd = Eckl_ComputeFairStates_recur(fsm, Z_bdd, car(fc));
    right_bdd = Eckl_ComputeFairStates_recur(fsm, Z_bdd, cdr(fc));
    res_bdd = bdd_and(dd_manager, left_bdd, right_bdd);
    bdd_free(dd_manager, left_bdd);
    bdd_free(dd_manager, right_bdd);
    return(res_bdd);
  }
  if(node_get_type(fc) == BDD){
    bdd_ptr J_bdd, tmp1_bdd, res_bdd;

    J_bdd = bdd_dup((bdd_ptr)car(fc));
    tmp1_bdd = bdd_and(dd_manager, Z_bdd, J_bdd);
    res_bdd = ex(fsm, eu(fsm, bdd_one(dd_manager), tmp1_bdd));
    bdd_free(dd_manager, tmp1_bdd);
    bdd_free(dd_manager, J_bdd);
    return(res_bdd);
  }
  internal_error("Eckl_ComputeFairStates_recur(): fc->type = %d", node_get_type(fc));
}

bdd_ptr Eckl_ComputeFairStates(Fsm_BddPtr fsm)
{
	bdd_ptr old_bdd=(bdd_ptr)NULL, new_bdd;
    node_ptr fairness_constraints = Compile_FsmBddGetJustice(fsm);

	new_bdd = bdd_one(dd_manager);
	while (new_bdd!=old_bdd)
	{
		old_bdd = bdd_dup(new_bdd);
		if (new_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, new_bdd);
		new_bdd = Eckl_ComputeFairStates_recur(fsm, old_bdd, fairness_constraints);

	}

	if (old_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, old_bdd);
	return new_bdd;
}


/**Function********************************************************************

  Synopsis           []

  Description        []

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_get_Compassions(Fsm_BddPtr fsm)
{
	Eckl_Compassions_free_all();
	Eckl_get_Compassions_recur(cmp_struct_get_compassion(cmps), Nil, Compile_FsmBddGetCompassion(fsm));
}

/**Function********************************************************************

  Synopsis           []

  Description        []

  SideEffects        []

  SeeAlso            []

******************************************************************************/
void Eckl_get_Compassions_recur(node_ptr Compassion_formulas, node_ptr formula_parent, node_ptr Compassion_bdds)
{
	char *var_name;
	bdd_ptr var_bdd;

	if(Compassion_formulas == Nil) return;

	if(node_get_type(Compassion_formulas) == CONS){
		(void)Eckl_get_Compassions_recur(car(Compassion_formulas), Compassion_formulas, car(Compassion_bdds));
		(void)Eckl_get_Compassions_recur(cdr(Compassion_formulas), Compassion_formulas, cdr(Compassion_bdds));
		return;
	}

	if(Compassion_formulas != (node_ptr)Nil){
		var_name = Eckl_get_string(Compassion_formulas);
		if(node_get_type(Compassion_bdds) == BDD)
			var_bdd = bdd_dup((bdd_ptr)car(Compassion_bdds));
		nusmv_assert(var_name!="");
		nusmv_assert(var_bdd!=(bdd_ptr)Nil);

		//add one variable representing the var_bdd
		var_name = mystrcat(mystrcat(mystrcat(mystrcat("COMPASSION", itoa(Eckl_Compassions.count)), "{"), var_name), "}");
//		node_ptr var = Eckl_MaxSubformula_new_one_variable(var_name, var_bdd);

		Eckl_Compassions.CF[Eckl_Compassions.count].parent = formula_parent;
		Eckl_Compassions.CF[Eckl_Compassions.count].n = Compassion_formulas;
		Eckl_Compassions.CF[Eckl_Compassions.count].context= Nil;
//		Eckl_Compassions.CF[Eckl_Compassions.count].var = var;

		Eckl_Compassions.count++;
	}

}


/**Function********************************************************************

  Synopsis           [Get the monolothic version of a transition relation]

  Description        [Gets the bdd corresponding to the monolothic
  version of the transition relation of a given fsm. the function is copied from the function
  GetTrans(fsm) in ltlCompassion.c.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_GetTrans(Fsm_BddPtr fsm)
{
  Partition_Method part;
  CPTrans_Ptr cp_trans = NULL; /* just to be sure we capture ecceptions */
  CPList cp_fwd;

  /* Update the transition relation */
  part = get_partition_method(options);
  switch(part) {
  case Monolithic:
    cp_trans = Compile_FsmBddGetMonoTrans(fsm);
    break;
  case Threshold:
    cp_trans = Compile_FsmBddGetThreshold(fsm);
    break;
  case Iwls95CP:
    cp_trans = Compile_FsmBddGetIwls95CP(fsm);
    break;
  default:
    rpterr("ltlPropAddTableau: unknown partition method\n");
  }

  nusmv_assert(cp_trans != (CPTrans_Ptr)NULL);

  cp_fwd = CPTransGetForward(cp_trans);
  return CPListBuildMonolithicBDDFromCPlist(cp_fwd);
}

bdd_ptr Eckl_compute_reachable_states(Fsm_BddPtr fsm)
{
	bdd_ptr old, new;

	bdd_ptr trans = Eckl_GetTrans(fsm);
	new = bdd_zero(dd_manager);

	while(1){
		if(old) bdd_free(dd_manager, old);
		old = bdd_dup(new);

		bdd_ptr tmp1 = bdd_or(dd_manager, new, trans);
		bdd_ptr tmp2 = bdd_forsome(dd_manager, tmp1, state_variables_bdd);
		bdd_free(dd_manager, tmp1);

		bdd_ptr tmp3 = bdd_shift_backward(dd_manager, tmp2);
		bdd_free(dd_manager, tmp2);

		if(new) bdd_free(dd_manager, new);
		new = bdd_or(dd_manager, Compile_FsmBddGetInit(fsm), tmp3);
		bdd_free(dd_manager, tmp3);

		if(old==new) break;
	}

	bdd_free(dd_manager, old);
	return new;
}



/**Function  G_{\tau'}(\theta,\tau)********************************************************************

  Synopsis           [Get the reachable global states of the difference of belief system and
  				desire system of an agent in the current transition relation]

  Description        [Before calling this function, the transition relation must be restricted according
  				to the belief of the agent.]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_compute_BD_diff_reachable_states(Fsm_BddPtr fsm, node_ptr agent_name)
{
	bdd_ptr old_bdd=(bdd_ptr)NULL, new_bdd=(bdd_ptr)NULL;

	//---------------------------------------------------------------
	// forsome(X') ( G(P(\theta,\tau)) and \tau and \neg\tau' )
	// i.e. forsome(X') ( G(P(\theta,\tau)) and \tau and \neg WD'_i )
	//---------------------------------------------------------------
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	bdd_ptr tau_bdd = Eckl_GetTrans(fsm);

	//get the BDD of !WD' for the agent
	bdd_ptr Desire_bdd = Eckl_eval_BDI_possibleworld_variable(agent_name, DESIRE_WORLD);
	bdd_ptr Not_Desire_Next_bdd = bdd_not(dd_manager, bdd_shift_forward(dd_manager, Desire_bdd));
	bdd_free(dd_manager, Desire_bdd);

	new_bdd = bdd_forsome(dd_manager,
		bdd_and(dd_manager, bdd_and(dd_manager, tau_bdd, Not_Desire_Next_bdd), reachable_states_bdd),
		next_state_variables_bdd);


	while(1){
		if(old_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, old_bdd);
		old_bdd = bdd_dup(new_bdd);

		//forsome(X)(Z and \tau)[X'/X]
		bdd_ptr tmp1_bdd = bdd_shift_backward(dd_manager,
			bdd_forsome(dd_manager,
				bdd_and(dd_manager, new_bdd, tau_bdd),
				state_variables_bdd));


		//G(P(\theta,\tau)) and forsome(X')(Z[X/X'] and \tau)
		bdd_ptr tmp2_bdd = bdd_and(dd_manager,
			bdd_forsome(dd_manager,
				bdd_and(dd_manager,
					bdd_shift_forward(dd_manager, new_bdd),
					tau_bdd),
				next_state_variables_bdd),
			reachable_states_bdd);


		if(new_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, new_bdd);
		new_bdd = bdd_or(dd_manager, old_bdd, tmp1_bdd);
		bdd_or_accumulate(dd_manager, &new_bdd, tmp2_bdd);

		bdd_free(dd_manager, tmp1_bdd);
		bdd_free(dd_manager, tmp2_bdd);

		if(new_bdd==old_bdd) break;

	}

	if(old_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, old_bdd);

	return new_bdd;
}



/**Function  G_{\tau'}(\theta,\tau)********************************************************************

  Synopsis           [Get the fairness constraint 1 or 2 for the desire of an agent.]

  Description        [Before calling this function, the transition relation must be restricted according
  				to the belief of the agent.
  				parameter FC_ID: 1 for constraint 1; 2 for constraint 2]

  SideEffects        []

  SeeAlso            []

******************************************************************************/
bdd_ptr Eckl_eval_FairnessConstraint_for_Desire(Fsm_BddPtr fsm, node_ptr agent_name, int FC_ID)
{
	//------------------------------------------------------------------
	// EF( forsome(X')( \tau and !WD'_i and FC^j_\varphi(\theta,tau)[X/X'] ) )   j=1,2
	//------------------------------------------------------------------

	bdd_ptr FC_bdd=(bdd_ptr)NULL;
	if(FC_ID==1)
		FC_bdd = Eckl_eval_FairnessConstraint1(fsm);
	else if(FC_ID==2)
		FC_bdd = Eckl_eval_FairnessConstraint2(fsm);
	else {
		rpterr("Eckl_eval_FairnessConstraint_for_Desire(): FC_ID is not 1 or 2.\n");
		nusmv_exit(1);
	}

	bdd_ptr tau_bdd = Eckl_GetTrans(fsm);

	//get the BDD of !WD' for the agent
	bdd_ptr Desire_bdd = Eckl_eval_BDI_possibleworld_variable(agent_name, DESIRE_WORLD);
	bdd_ptr Not_Desire_Next_bdd = bdd_not(dd_manager, bdd_shift_forward(dd_manager, Desire_bdd));
	bdd_free(dd_manager, Desire_bdd);


	bdd_ptr res_bdd =
		ef(  fsm,
			bdd_forsome(dd_manager,
				bdd_and(dd_manager,
					bdd_and(dd_manager, tau_bdd, Not_Desire_Next_bdd),
					bdd_shift_forward(dd_manager, FC_bdd)),
				next_state_variables_bdd)  );


	if(Not_Desire_Next_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, Not_Desire_Next_bdd);
	if(FC_bdd!=(bdd_ptr)NULL) bdd_free(dd_manager, FC_bdd);


	return res_bdd;
}



/**Function for Sum & Product example********************************************************************

  Synopsis           [Compile formula 'agent K f_bdd' into BDD.]

  Description        [n must be of the form 'agent K (bool subformula)'.
                          argument:
                            states_bdd : the BDD of global reachable states

                      Note that: agent_name is the plain node generated from string,
                                 its internal structure will be generated by calling eval_struct(find_atom(agent_name), Nil)
                                 in this function.
                            ]

  SideEffects        []

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr CTLK_eval_K_bool_formula(node_ptr agent_name, bdd_ptr states_bdd, bdd_ptr f_bdd)
{

	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube

	node_ptr mod_name = eval_struct(find_atom(agent_name), Nil);

	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "CTLK_eval_K_bool_formula: the agent '");
		print_node(nusmv_stdout, agent_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("CTLK_eval_K_bool_formula: cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);

	//delete the bdd with index 0, which is the useless bdd created by NuSMV
	bdd_ptr temp_bdd = bdd_cube_diff(dd_manager, cube_bdd, bdd_new_var_with_index(dd_manager,0));
	bdd_free(dd_manager, cube_bdd);
	cube_bdd=temp_bdd;

	/* fprintf(nusmv_stdout, "[cube:");
    	(void) print_state_vars(dd_manager, cube_bdd, state_variables);
	fprintf(nusmv_stdout,"]"); */

	//fprintf(nusmv_stdout, "[bdds in cube:");
	bdd_ptr cube_support=bdd_support(dd_manager,cube_bdd);
	int i;
	for (i = 0; i <= num_of_variables_get(); i++) {
		bdd_ptr tmp_bdd=bdd_cube_diff(dd_manager,cube_bdd, bdd_new_var_with_index(dd_manager, i));
		if (tmp_bdd != cube_bdd) { //bdd variable with index i is in cube_bdd
			//fprintf(nusmv_stdout,"%d,",i);
		}
		bdd_free(dd_manager,tmp_bdd);
	}
	//fprintf(nusmv_stdout,"]");
	bdd_free(dd_manager,cube_support);
	
	
	
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("CTLK_eval_K_bool_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//printing message
	//fprintf(nusmv_stdout,"\nPrinting Cube_bdd:\n");
	//print_state_vars(dd_manager, cube_bdd, state_variables);

	//(2) Compute res_bdd = Forall(cube_bdd)( states_bdd -> f_bdd )

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op((Fsm_BddPtr)NULL, dd_manager, bdd_or, states_bdd, f_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("CTLK_eval_K_bool_formula(): The BDD of reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}


	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("CTLK_eval_K_bool_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

	bdd_and_accumulate(dd_manager,&res_bdd,states_bdd);
	return res_bdd;
}

/* ---- The backup of this function ----
bdd_ptr CTLK_eval_K_bool_formula(node_ptr agent_name, bdd_ptr states_bdd, bdd_ptr f_bdd)
{

	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube

	node_ptr mod_name = eval_struct(find_atom(agent_name), Nil);

	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "CTLK_eval_K_bool_formula: the agent '");
		print_node(nusmv_stdout, agent_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("CTLK_eval_K_bool_formula: cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);
	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("CTLK_eval_K_bool_formula(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//printing message
	//fprintf(nusmv_stdout,"\nPrinting Cube_bdd:\n");
	//print_state_vars(dd_manager, cube_bdd, state_variables);

	//(2) Compute res_bdd = Forall(cube_bdd)( states_bdd -> f_bdd )

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op((Fsm_BddPtr)NULL, dd_manager, bdd_or, states_bdd, f_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("CTLK_eval_K_bool_formula(): The BDD of reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}


	bdd_ptr res_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(res_bdd == (bdd_ptr)NULL) {
		rpterr("CTLK_eval_K_bool_formula(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);


	return(res_bdd);
}
*/


/*
Let x1,...,xn be the boolean variables that encode the scalar variable var_name. Then,
(agent_name KNOW var_name) is equal to

((agent_name KNOW x1) or (agent_name KNOW !x1))
and ... and
((agent_name KNOW xn) or (agent_name KNOW !xn))

Note that: (1) agent_name is the plain node generated from string,
               its internal structure will be generated by calling eval_struct(find_atom(agent_name), Nil)
               in this function.
           (2) var_name should be the internal structure of the corresponding variable name.
*/
bdd_ptr SNP_eval_K_variable(node_ptr agent_name, bdd_ptr states_bdd, node_ptr var_name)
{
	bdd_ptr res_bdd = bdd_one(dd_manager);

	node_ptr varindex_add = Eckl_lookup_VarIndex_hash(var_name);
	if(varindex_add==(node_ptr)NULL) {
		rpterr("SNP_eval_K_variable: the varindex_add is Nil.\n");
		nusmv_exit(1);
	}

	int start_index = (int)car(varindex_add);
	int offset = (int)cdr(varindex_add);
	//if(ShowMessage)	fprintf(nusmv_stdout, "(index=%d, offset=%d)", start_index, offset);

	int i;
	for(i=start_index; i<(start_index+offset); i+=2){
		add_ptr varelm_add = add_new_var_with_index(dd_manager, i);

		//res1_bdd = agent_name Knows varelm_bdd
		bdd_ptr varelm_bdd = add_to_bdd(dd_manager, varelm_add);
		bdd_ptr res1_bdd = CTLK_eval_K_bool_formula(agent_name, states_bdd, varelm_bdd);


		//res2_bdd = agent_name Knows not_varelm_bdd
		bdd_ptr not_varelm_bdd = bdd_not(dd_manager, varelm_bdd);
		bdd_ptr res2_bdd = CTLK_eval_K_bool_formula(agent_name, states_bdd, not_varelm_bdd);

		bdd_and_accumulate(dd_manager, &res_bdd, bdd_or(dd_manager, res1_bdd, res2_bdd));
		bdd_free(dd_manager, res1_bdd);
		bdd_free(dd_manager, res2_bdd);
	}

	return res_bdd;
}

/*
Let x1,...,xn be the boolean variables that encode the scalar variable var_name. Then,
(agent_name KNOW var_name) is equal to 

  \/_{0<=i<=10}(agent_name K var_name=i)

Note that: (1) agent_name is the plain node generated from string,
               its internal structure will be generated by calling eval_struct(find_atom(agent_name), Nil)
               in this function.
           (2) var_name should be the internal structure of the corresponding variable name.
*/
bdd_ptr Eckl_eval_K_variable_T1(node_ptr agent_name, bdd_ptr states_bdd, node_ptr var_name)
{
	bdd_ptr res_bdd = bdd_zero(dd_manager);

	int i;
	//  
	for(i=0; i<10; i++){
		// constructing the node for "var_name=i"
		node_ptr node_tmp = new_node(EQUAL, var_name, new_node(NUMBER,(node_ptr)i,Nil));
		print_node(nusmv_stdout, node_tmp);

		add_ptr add_tmp = eval(node_tmp,Nil);
		if(add_tmp==(add_ptr)NULL) {fprintf(nusmv_stdout,"the add of var_name=i is NULL.\n"); nusmv_exit(1);}

		//res1_bdd = agent_name K var_name=i
		bdd_ptr res1_bdd = CTLK_eval_K_bool_formula(agent_name, states_bdd, add_to_bdd(dd_manager,add_tmp));
		add_free(dd_manager,add_tmp);

		bdd_or_accumulate(dd_manager, &res_bdd, res1_bdd);
		bdd_free(dd_manager, res1_bdd);
	}
	
	return res_bdd;
}


void Eckl_print_bdd_indexs_in_cube(bdd_ptr cube_bdd)
{
	bdd_ptr cube_support=bdd_support(dd_manager,cube_bdd);
	//fprintf(nusmv_stdout,"(");
	int i;
	for (i = 0; i <= num_of_variables_get(); i++) {
		bdd_ptr tmp_bdd=bdd_cube_diff(dd_manager,cube_bdd, bdd_new_var_with_index(dd_manager, i));
		if (tmp_bdd != cube_bdd) { //bdd variable with index i is in cube_bdd
			fprintf(nusmv_stdout,"%d ",i);
		}
		bdd_free(dd_manager,tmp_bdd);
	}
	//fprintf(nusmv_stdout,")");
	bdd_free(dd_manager,cube_support);

}

/*
Let x1,...,xn be the boolean variables that encode the scalar variable var_name. Then,
(agent_name KNOW var_name) is equal to


Note that: (1) agent_name is the plain node generated from string,
               its internal structure will be generated by calling eval_struct(find_atom(agent_name), Nil)
               in this function.
           (2) var_name should be the internal structure of the corresponding variable name.
*/
bdd_ptr Eckl_eval_K_variable_T2(node_ptr agent_name, bdd_ptr states_bdd, node_ptr var_name)
{
	//d=d'
	add_ptr d_add = eval(var_name,Nil);
	add_ptr dn_add = add_shift_forward(dd_manager,d_add);
	bdd_ptr varequ_bdd = add_to_bdd(dd_manager,add_equal(dd_manager,d_add,dn_add));
	

	node_ptr varindexs = Eckl_lookup_VarIndex_hash(var_name);
	if(varindexs==(node_ptr)NULL) {
		rpterr("SNP_eval_K_variable: the varindexs is Nil.\n");
		nusmv_exit(1);
	}
	int start_index = (int)car(varindexs);
	int offset = (int)cdr(varindexs);

	fprintf(nusmv_stdout, "(K_variable:index=%d, offset=%d)", start_index, offset);

	bdd_ptr cube_var_bdd=bdd_one(dd_manager); //the bdd cube of var_name
//	bdd_ptr varequ_bdd=bdd_one(dd_manager);
	int i;
	for(i=start_index; i<(start_index+offset); i+=2){
		bdd_ptr varelm_bdd = bdd_new_var_with_index(dd_manager, i);
		bdd_and_accumulate(dd_manager,&cube_var_bdd,varelm_bdd);

/*		//varequ_bdd=/\_(b in var_name)(b<->b')
		fprintf(nusmv_stdout,"("); 
		Eckl_print_bdd_indexs_in_cube(varelm_bdd); 
		fprintf(nusmv_stdout,"=");
		Eckl_print_bdd_indexs_in_cube(bdd_shift_forward(dd_manager,varelm_bdd)); 
		fprintf(nusmv_stdout,")");
		
		bdd_and_accumulate(dd_manager,&varequ_bdd,Eckl_binary_bdd_op(NULL,dd_manager,bdd_xor,varelm_bdd,bdd_shift_forward(dd_manager,varelm_bdd),-1,1,1));
*/	}

	//nx_varvals_bdd = next(forsome(X-var).states_bdd)
	bdd_ptr cube_tmp = bdd_cube_diff(dd_manager,state_variables_bdd,cube_var_bdd);
	bdd_ptr varvals_bdd = bdd_forsome(dd_manager,states_bdd,cube_tmp);
	bdd_ptr nx_varvals_bdd = bdd_shift_forward(dd_manager,varvals_bdd);
	bdd_free(dd_manager,cube_tmp);
	bdd_free(dd_manager,varvals_bdd);
	

	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube

	node_ptr mod_name = eval_struct(find_atom(agent_name), Nil);

	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_K_variable_T2: the agent '");
		print_node(nusmv_stdout, agent_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_K_variable_T2: cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);

	fprintf(nusmv_stdout, "cube_bdd:");
	Eckl_print_bdd_indexs_in_cube(cube_bdd);
	
	////delete the bdd with index 0, which is the useless bdd created by NuSMV
	//bdd_ptr temp_bdd = bdd_cube_diff(dd_manager, cube_bdd, bdd_new_var_with_index(dd_manager,0));
	//bdd_free(dd_manager, cube_bdd);
	//cube_bdd=temp_bdd;  

	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_variable_T2(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//printing message
	//fprintf(nusmv_stdout,"\nPrinting Cube_bdd:\n");
	//print_state_vars(dd_manager, cube_bdd, state_variables);

	//(2) Compute know_var_bdd = Forall(cube_bdd)( states_bdd -> varequ_bdd )

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op((Fsm_BddPtr)NULL, dd_manager, bdd_or, states_bdd, varequ_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_variable_T2(): The BDD of reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr know_var_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(know_var_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_variable_T2(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

	//res_bdd = forsome(nx_cube_var_bdd) (nx_varvals_bdd /\ know_var_bdd)
	tmp1_bdd = Eckl_binary_bdd_op((Fsm_BddPtr)NULL, dd_manager, bdd_and, nx_varvals_bdd, know_var_bdd, 1, 1, 1);
	bdd_free(dd_manager,nx_varvals_bdd);
	bdd_free(dd_manager,know_var_bdd);
	bdd_ptr nx_cube_var_bdd = bdd_shift_forward(dd_manager,cube_var_bdd);
	bdd_free(dd_manager,cube_var_bdd);

	bdd_ptr res_bdd = bdd_forsome(dd_manager,tmp1_bdd,nx_cube_var_bdd);
	bdd_free(dd_manager,nx_cube_var_bdd);
		
	bdd_and_accumulate(dd_manager,&res_bdd,states_bdd);
	return res_bdd;
}

/*
bdd_ptr Eckl_eval_K_variable_T2(node_ptr agent_name, bdd_ptr states_bdd, node_ptr var_name)
{
	node_ptr varindexs = Eckl_lookup_VarIndex_hash(var_name);
	if(varindexs==(node_ptr)NULL) {
		rpterr("SNP_eval_K_variable: the varindexs is Nil.\n");
		nusmv_exit(1);
	}
	int start_index = (int)car(varindexs);
	int offset = (int)cdr(varindexs);

	fprintf(nusmv_stdout, "(K_variable:index=%d, offset=%d)", start_index, offset);

	bdd_ptr cube_var_bdd=bdd_one(dd_manager); //the bdd cube of var_name
	bdd_ptr varequ_bdd=bdd_one(dd_manager);
	int i;
	for(i=start_index; i<(start_index+offset); i+=2){
		bdd_ptr varelm_bdd = bdd_new_var_with_index(dd_manager, i);
		bdd_and_accumulate(dd_manager,&cube_var_bdd,varelm_bdd);

		//varequ_bdd=/\_(b in var_name)(b<->b')
		fprintf(nusmv_stdout,"("); 
		Eckl_print_bdd_indexs_in_cube(varelm_bdd); 
		fprintf(nusmv_stdout,"=");
		Eckl_print_bdd_indexs_in_cube(bdd_shift_forward(dd_manager,varelm_bdd)); 
		fprintf(nusmv_stdout,")");
		
		bdd_and_accumulate(dd_manager,&varequ_bdd,Eckl_binary_bdd_op(NULL,dd_manager,bdd_xor,varelm_bdd,bdd_shift_forward(dd_manager,varelm_bdd),-1,1,1));
	}

	//nx_varvals_bdd = next(forsome(X-var).states_bdd)
	bdd_ptr cube_tmp = bdd_cube_diff(dd_manager,state_variables_bdd,cube_var_bdd);
	bdd_ptr varvals_bdd = bdd_forsome(dd_manager,states_bdd,cube_tmp);
	bdd_ptr nx_varvals_bdd = bdd_shift_forward(dd_manager,varvals_bdd);
	bdd_free(dd_manager,cube_tmp);
	bdd_free(dd_manager,varvals_bdd);
	

	//(1) compute the cube(cube_bdd) of StateVariables - ObsVarCube

	node_ptr mod_name = eval_struct(find_atom(agent_name), Nil);

	StructModuleInstantiation *mod_inst = Eckl_lookup_ModInst(mod_name);
	if(!mod_inst){
		fprintf(nusmv_stdout, "Eckl_eval_K_variable_T2: the agent '");
		print_node(nusmv_stdout, agent_name);
		fprintf(nusmv_stdout, "' is NOT a module instantiation.\n");
		nusmv_exit(1);
	}
	add_ptr cube_add = add_dup(state_variables_add);

	//indent_node(nusmv_stdout, "--The Observable Variables of agent '", mod_name, "': (");
	Eckl_clear_ObsVar_hash();
	Eckl_compute_StateVars_diff_ObsVars_Cube(mod_inst, &cube_add, false);
	Eckl_get_ObsVarList_from_ObsVar_hash(false);  //get the list of observable variables of the agent mod_name
	//fprintf(nusmv_stdout, ")\n");

	if(!cube_add){
		rpterr("Eckl_eval_K_variable_T2: cube_add is Nil.\n");
		nusmv_exit(1);
	}
	bdd_ptr cube_bdd = add_to_bdd(dd_manager, cube_add);
	add_free(dd_manager, cube_add);

	fprintf(nusmv_stdout, "cube_bdd:");
	Eckl_print_bdd_indexs_in_cube(cube_bdd);
	
	////delete the bdd with index 0, which is the useless bdd created by NuSMV
	//bdd_ptr temp_bdd = bdd_cube_diff(dd_manager, cube_bdd, bdd_new_var_with_index(dd_manager,0));
	//bdd_free(dd_manager, cube_bdd);
	//cube_bdd=temp_bdd;  

	if(cube_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_variable_T2(): AbstractCube == NULL.\n");
		nusmv_exit(1);
	}

	//printing message
	//fprintf(nusmv_stdout,"\nPrinting Cube_bdd:\n");
	//print_state_vars(dd_manager, cube_bdd, state_variables);

	//(2) Compute know_var_bdd = Forall(cube_bdd)( states_bdd -> varequ_bdd )

	bdd_ptr tmp1_bdd = Eckl_binary_bdd_op((Fsm_BddPtr)NULL, dd_manager, bdd_or, states_bdd, varequ_bdd, 1, -1, 1);
	if(tmp1_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_variable_T2(): The BDD of reachable_states_bdd -> ltl2bool(cdr(n)) == NULL.\n");
		nusmv_exit(1);
	}

	bdd_ptr know_var_bdd = bdd_forall(dd_manager, tmp1_bdd, cube_bdd);
	if(know_var_bdd == (bdd_ptr)NULL) {
		rpterr("Eckl_eval_K_variable_T2(): The returned BDD == NULL.\n");
		nusmv_exit(1);
	}
	bdd_free(dd_manager, tmp1_bdd);
	bdd_free(dd_manager, cube_bdd);

	//res_bdd = forsome(nx_cube_var_bdd) (nx_varvals_bdd /\ know_var_bdd)
	tmp1_bdd = Eckl_binary_bdd_op((Fsm_BddPtr)NULL, dd_manager, bdd_and, nx_varvals_bdd, know_var_bdd, 1, 1, 1);
	bdd_free(dd_manager,nx_varvals_bdd);
	bdd_free(dd_manager,know_var_bdd);
	bdd_ptr nx_cube_var_bdd = bdd_shift_forward(dd_manager,cube_var_bdd);
	bdd_free(dd_manager,cube_var_bdd);

	bdd_ptr res_bdd = bdd_forsome(dd_manager,tmp1_bdd,nx_cube_var_bdd);
	bdd_free(dd_manager,nx_cube_var_bdd);
		
	bdd_and_accumulate(dd_manager,&res_bdd,states_bdd);
	return res_bdd;
}
*/

bdd_ptr SNP_evaluation(Fsm_BddPtr fsm)
{
	/* compute the Global reachable states */
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	//get the name of agent Sum
	node_ptr sum_name = sym_intern("sum");
	//get the name of agent Product
	node_ptr pro_name = sym_intern("pro");


	//get the node of variable x
	node_ptr x = eval_struct(sym_intern("x"), Nil);
	//get the node of variable y
	node_ptr y = eval_struct(sym_intern("y"), Nil);


	/* Announcement 1 : Sum Know !(Pro Know (x,y)) */
	//(1) calculate !(Pro Know (x,y)) to res1_bdd
	bdd_ptr temp1_bdd = bdd_not(dd_manager, bdd_and(dd_manager,
		SNP_eval_K_variable(pro_name, reachable_states_bdd, x),
		SNP_eval_K_variable(pro_name, reachable_states_bdd, y)));

	//(2) calculate Sum Know temp1_bdd
	bdd_ptr sat_a1_bdd = CTLK_eval_K_bool_formula(sum_name, reachable_states_bdd, temp1_bdd);
	bdd_free(dd_manager, temp1_bdd);


	//epistemic model updating
	bdd_and_accumulate(dd_manager, &reachable_states_bdd, sat_a1_bdd);
	bdd_free(dd_manager, sat_a1_bdd);


	/* Announcement 2 : (Pro Know (x,y)) */
	temp1_bdd = bdd_and(dd_manager,
		SNP_eval_K_variable(pro_name, reachable_states_bdd, x),
		SNP_eval_K_variable(pro_name, reachable_states_bdd, y));


	//epistemic model updating
	bdd_and_accumulate(dd_manager, &reachable_states_bdd, temp1_bdd);
	bdd_free(dd_manager, temp1_bdd);


	/* Announcement 3 : (Sum Know (x,y)) */
	temp1_bdd = bdd_and(dd_manager,
		SNP_eval_K_variable(sum_name, reachable_states_bdd, x),
		SNP_eval_K_variable(sum_name, reachable_states_bdd, y));


	//epistemic model updating
	bdd_and_accumulate(dd_manager, &reachable_states_bdd, temp1_bdd);
	bdd_free(dd_manager, temp1_bdd);


	return reachable_states_bdd;
}


bdd_ptr WhatSum_evaluation(Fsm_BddPtr fsm)
{
	/* compute the Global reachable states 
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm) */;


	//bdd_states stores the initial states of the system
	bdd_ptr states_bdd=bdd_dup(Compile_FsmBddGetInit(fsm));
	if (states_bdd == (bdd_ptr)NULL) {
		fprintf(nusmv_stdout,"WhatSum_evaluation: The BDD of the initial states is NULL.\n");
		exit;
	}

/*	fprintf(nusmv_stdout, "--All initial states--\n");
	print_states(states_bdd);*/

		
	//get agents' name
	node_ptr aa_name = sym_intern("aa");
	node_ptr ab_name = sym_intern("ab");
	node_ptr ac_name = sym_intern("ac");


	//get the node of variable x,y,z
	node_ptr x = eval_struct(sym_intern("x"), Nil);
	node_ptr y = eval_struct(sym_intern("y"), Nil);
	node_ptr z = eval_struct(sym_intern("z"), Nil);


	/* Announcement 1 : !(aa Know x) */
	fprintf(nusmv_stdout, "!aa Know x:");
	bdd_ptr temp_bdd;
	temp_bdd = bdd_not(dd_manager,Eckl_eval_K_variable_T2(aa_name, states_bdd, x));
	//epistemic model updating
	bdd_and_accumulate(dd_manager, &states_bdd, temp_bdd);
	bdd_free(dd_manager, temp_bdd);


	/* Announcement 2 : !(ab Know y) */
	fprintf(nusmv_stdout, " !ab know y:");
	temp_bdd = bdd_not(dd_manager,Eckl_eval_K_variable_T2(ab_name, states_bdd, y));
	//epistemic model updating
	bdd_and_accumulate(dd_manager, &states_bdd, temp_bdd);
	bdd_free(dd_manager, temp_bdd);


	/* Announcement 3 : !(ac Know z) */
	fprintf(nusmv_stdout, "!ac know z:");
	temp_bdd = bdd_not(dd_manager,Eckl_eval_K_variable_T2(ac_name, states_bdd, z));
	//epistemic model updating
	bdd_and_accumulate(dd_manager, &states_bdd, temp_bdd);
	bdd_free(dd_manager, temp_bdd);


	/* Announcement 4 : (aa Know x) */
	/*temp_bdd = Eckl_eval_K_variable_T2(aa_name, reachable_states_bdd, x);
	//epistemic model updating
	bdd_and_accumulate(dd_manager, &reachable_states_bdd, temp_bdd);
	bdd_free(dd_manager, temp_bdd);*/



	return states_bdd;
}


/*
bdd_ptr SNP_evaluation2(Fsm_BddPtr fsm)
{
	// compute the Global reachable states
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm);

	//get the name of agent Sum
	node_ptr sum_name = eval_struct(sym_intern("sum"), Nil); //find_atom(new_node(DOT, Nil, find_atom(car(n))));
//	node_ptr mod_name = find_atom(new_node(DOT, Nil, find_atom(car(n))));


	//get the name of agent Product
	node_ptr pro_name = eval_struct(sym_intern("pro"), Nil);


	//get the node of variable x
	node_ptr x = eval_struct(sym_intern("x"), Nil);
	//get the node of variable y
	node_ptr y = eval_struct(sym_intern("y"), Nil);


	// Announcement 1 : Sum Know !(Pro Know (x,y))
	//(1) calculate !(Pro Know (x,y)) to res1_bdd
	bdd_ptr temp1_bdd = bdd_not(dd_manager, bdd_and(dd_manager,
		SNP_eval_K_variable(pro_name, reachable_states_bdd, x),
		SNP_eval_K_variable(pro_name, reachable_states_bdd, y)));

	//(2) calculate sat_a1_bdd = Sum Know temp1_bdd
	bdd_ptr sat_a1_bdd = CTLK_eval_K_bool_formula(sum_name, reachable_states_bdd, temp1_bdd);
	bdd_free(dd_manager, temp1_bdd);




	// Announcement 2 : (Pro Know (x,y))
	bdd_ptr sat_a2_bdd = bdd_and(dd_manager,
		SNP_eval_K_variable(pro_name, reachable_states_bdd, x),
		SNP_eval_K_variable(pro_name, reachable_states_bdd, y));


	//epistemic model updating
	bdd_and_accumulate(dd_manager, &reachable_states_bdd, temp1_bdd);
	bdd_free(dd_manager, temp1_bdd);


	// Announcement 3 : (Sum Know (x,y))
	bdd_ptr temp1_bdd = bdd_and(dd_manager,
		SNP_eval_K_variable(sum_name, reachable_states_bdd, x),
		SNP_eval_K_variable(sum_name, reachable_states_bdd, y));

	bdd_ptr res_bdd=bdd_dup(dd_manager, temp1_bdd);


	return reachable_states_bdd;
}
*/


//Muddy Children without Assignment
//m1+m2+m3=2
bdd_ptr MuddyChildren_evaluation(Fsm_BddPtr fsm)
{
	/* compute the Global reachable states 
	if(reachable_states_bdd == (bdd_ptr)NULL)
		compute_reachable_states(fsm) */;


	//states_bdd stores the initial states of the system
	bdd_ptr states_bdd=bdd_dup(Compile_FsmBddGetInit(fsm));
	if (states_bdd == (bdd_ptr)NULL) {
		fprintf(nusmv_stdout,"MuddyChildren_evaluation: The BDD of the initial states is NULL.\n");
		exit;
	}

/*	fprintf(nusmv_stdout, "--All initial states--\n");
	print_states(states_bdd);*/

		
	//get agents' name
	node_ptr c1_name = sym_intern("c1");
	node_ptr c2_name = sym_intern("c2");
	node_ptr c3_name = sym_intern("c3");


	//get the node of variable x,y,z
	node_ptr m1 = eval_struct(sym_intern("m1"), Nil);
	node_ptr m2 = eval_struct(sym_intern("m2"), Nil);
	node_ptr m3 = eval_struct(sym_intern("m3"), Nil);

	bdd_ptr m1_bdd=add_to_bdd(dd_manager,eval(m1,Nil));
	bdd_ptr m2_bdd=add_to_bdd(dd_manager,eval(m2,Nil));
	bdd_ptr m3_bdd=add_to_bdd(dd_manager,eval(m3,Nil));

	fprintf(nusmv_stdout, "--initial states--\n");
	print_states(states_bdd);
	
	fprintf(nusmv_stdout,"Initial evironment established.\n");

	bdd_ptr temp_bdd;

	// Announcement 1 : !(c1 Know m1) & !(c2 Know m2) & !(c3 Know m3) 
	temp_bdd=bdd_one(dd_manager);
	bdd_and_accumulate(dd_manager, &temp_bdd, bdd_not(dd_manager, CTLK_eval_K_bool_formula(c1_name, states_bdd, m1_bdd)));
	bdd_and_accumulate(dd_manager, &temp_bdd, bdd_not(dd_manager, CTLK_eval_K_bool_formula(c2_name, states_bdd, m2_bdd)));
	bdd_and_accumulate(dd_manager, &temp_bdd, bdd_not(dd_manager, CTLK_eval_K_bool_formula(c3_name, states_bdd, m3_bdd)));
	bdd_and_accumulate(dd_manager, &states_bdd, temp_bdd);		bdd_free(dd_manager, temp_bdd);
	fprintf(nusmv_stdout, "Announcement 1: !(c1 Know m1) & !(c2 Know m2) & !(c3 Know m3) done.\n");

	fprintf(nusmv_stdout, "--all states after Announcement 1 : !(c1 Know m1) & !(c2 Know m2) & !(c3 Know m3) --\n");
	print_states(states_bdd);


	// Announcement 2 : !(c1 Know m1) & !(c2 Know m2) & !(c3 Know m3) 
	temp_bdd=bdd_one(dd_manager);
	bdd_and_accumulate(dd_manager, &temp_bdd, bdd_not(dd_manager, CTLK_eval_K_bool_formula(c1_name, states_bdd, m1_bdd)));
	bdd_and_accumulate(dd_manager, &temp_bdd, bdd_not(dd_manager, CTLK_eval_K_bool_formula(c2_name, states_bdd, m2_bdd)));
	bdd_and_accumulate(dd_manager, &temp_bdd, bdd_not(dd_manager, CTLK_eval_K_bool_formula(c3_name, states_bdd, m3_bdd)));
	bdd_and_accumulate(dd_manager, &states_bdd, temp_bdd);		bdd_free(dd_manager, temp_bdd);
	fprintf(nusmv_stdout, "Announcement 2: !(c1 Know m1) & !(c2 Know m2) & !(c3 Know m3) done.\n");

	fprintf(nusmv_stdout, "--all states after Announcement 2 : !(c1 Know m1) & !(c2 Know m2) & !(c3 Know m3) --\n");
	print_states(states_bdd);


	// Announcement 3 : (c1 Know m1) 
	temp_bdd=bdd_one(dd_manager);
	bdd_and_accumulate(dd_manager, &temp_bdd, CTLK_eval_K_bool_formula(c1_name, states_bdd, m1_bdd));
	bdd_and_accumulate(dd_manager, &temp_bdd, CTLK_eval_K_bool_formula(c2_name, states_bdd, m2_bdd));
	bdd_and_accumulate(dd_manager, &temp_bdd, CTLK_eval_K_bool_formula(c3_name, states_bdd, m3_bdd));
	bdd_and_accumulate(dd_manager, &states_bdd, temp_bdd);		bdd_free(dd_manager, temp_bdd);
	fprintf(nusmv_stdout, "Announcement 3: (c1 Know m1) done.\n");

	fprintf(nusmv_stdout, "--all states after Announcement 3 : (c1 Know m1) --\n");
	print_states(states_bdd);



/*
	// the states that c1 knows m1
	temp_bdd = bdd_and(dd_manager, CTLK_eval_K_bool_formula(c1_name, states_bdd, m1_bdd), states_bdd);

	fprintf(nusmv_stdout, "--All states satisfying c1 knows m1--\n");
	print_states(temp_bdd);


	bdd_ptr temp2_bdd=Eckl_binary_bdd_op(NULL,dd_manager,bdd_or,m1_bdd,temp_bdd,1,-1,1);
	if(bdd_is_zero(dd_manager,Eckl_binary_bdd_op(NULL,dd_manager,bdd_and,states_bdd,temp2_bdd,1,1,-1)))
		fprintf(nusmv_stdout, "m1->(c1 knows m1) is valid.\n");
	else
		fprintf(nusmv_stdout,"m1->(c1 knows m1) is NOT valid.\n");

	bdd_free(dd_manager, temp_bdd);
	bdd_free(dd_manager, temp2_bdd);
*/

	return states_bdd;
}




/**Function********************************************************************

  Synopsis           [Compile formula 'agents C (bool subformula)' into BDD.]

  Description        [n must be of the form 'agents C (bool subformula)'.]

  SideEffects        [phi_bdd will be released in this function.]

  SeeAlso            [Eckl_eval_spec]

******************************************************************************/
bdd_ptr CTLK_eval_C_bool_formula(Fsm_BddPtr fsm, node_ptr n, node_ptr context, bdd_ptr states_bdd, bdd_ptr phi_bdd)
{
	if (n == Nil) return(bdd_one(dd_manager));
	if(node_get_type(n)!=CKNOW){
		rpterr("CTLK_eval_C_bool_formula(): the main operator of node n is NOT C.\n");
		nusmv_exit(1);
	}
	if(states_bdd==(bdd_ptr)Nil) {
		rpterr("CTLK_eval_C_bool_formula(): states_bdd is Nil.\n");
		exit(1);
	}
	if(phi_bdd==(bdd_ptr)Nil) {
		rpterr("CTLK_eval_C_bool_formula(): phi_bdd is Nil.\n");
		exit(1);
	}
	if (opt_verbose_level_gt(options, 3)) {
		fprintf(nusmv_stdout, "(agents C bool_formula): evaluating )");
		print_node(nusmv_stdout, car(n));
		fprintf(nusmv_stdout, ") C ");
		print_ltlspec(nusmv_stdout, cdr(n));
		fprintf(nusmv_stdout, "\n");
	}

	//compute formula: gfpZ[states_bdd & phi_bdd & AddtiveFunction()]
	bdd_ptr new = bdd_one(dd_manager);
	bdd_ptr old = (bdd_ptr)Nil;
	while(1){
		if(old)	bdd_free(dd_manager, old);
		old = bdd_dup(new);

		bdd_ptr tmp1_bdd = Eckl_eval_C_formula_AdditiveFunction(fsm, n, context, Nil, new);
		if(!tmp1_bdd){
			rpterr("CTLK_eval_C_bool_formula: the result of additivefunction is NULL.\n");
			nusmv_exit(1);
		}

		bdd_and_accumulate(dd_manager, &tmp1_bdd, phi_bdd);
		bdd_free(dd_manager, phi_bdd);

		bdd_and_accumulate(dd_manager, &tmp1_bdd, states_bdd);
		if(new) bdd_free(dd_manager, new);
		new = bdd_dup(tmp1_bdd);
		bdd_free(dd_manager, tmp1_bdd);

		if(old==new) break;
	}

	if(old) bdd_free(dd_manager, old);
	return new;
}
