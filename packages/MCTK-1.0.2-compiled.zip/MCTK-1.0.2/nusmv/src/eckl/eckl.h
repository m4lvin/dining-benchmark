/**CHeaderFile***********************************************************************

  FileName    [eckl.h]

  PackageName [eckl]

  Synopsis    [Fair ECKLn model checking algorithms. External header file.]

  Description [Fair ECKLn model checking algorithms. External header file.]

  SeeAlso     []

  Author      [Xiangyu Luo]

  Copyright   [
  This file is part of the ``eckl'' package of MCTK version 1. 
  Copyright (C) 2003-2004 by Multi-Agent System Research Group in 
  Sun Yat-sen University, Guangzhou, China. 

  MCTK version 1 is free software; you can redistribute it and/or 
  modify it under the terms of the GNU Lesser General Public 
  License as published by the Free Software Foundation; either 
  version 2 of the License, or (at your option) any later version.

  MCTK version 1 is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public 
  License along with this library; if not, write to the Free Software 
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA.

  For more information of MCTK see <http://agent.sysu.edu.cn>
  or email to <isp03lxy@student.zsu.edu.cn>.
  Please report bugs to <isp03lxy@student.zsu.edu.cn>.

  To contact the MCTK development board, email to <isp03lxy@student.zsu.edu.cn>. ]

******************************************************************************/

#ifndef _CTLeckl_INC
#define _CTLeckl_INC

#define MAX_AUXIVARS_NUMBER 300
typedef struct structAuxiVar * structAuxiVar_ptr;
struct structAuxiVar {
  char *name;
  node_ptr n;		//the node of the corresponding LTL formula
  node_ptr nvar;	//the node of created state variable

};

//----the datastructure for max subformula----
#define MAX_MAXSUBFORMULA_NUMBER 100
struct structMaxSubformula {
	node_ptr parent;	//the parent node of the root of this maximal subformula in the specification
	node_ptr	n;		//the root of this maximal subformula in the specification
	node_ptr context;	//the context node of the node n in the specification

	node_ptr var;  //the auxiliary variable representing the resulting BDD of check(n)
	
};
struct structMaxSubformulas {
	struct structMaxSubformula MSF[MAX_MAXSUBFORMULA_NUMBER];
	int count;
};
typedef struct structMaxSubformulas structMaxSubformulas;
//---------------------------------------

//----the datastructure for justice formulas----
#define MAX_JUSTICEFORMULA_NUMBER 100
struct structJusticeFormula {
	node_ptr parent;	//the parent node of the root of this justice formula
	node_ptr	n;		//the root of this justice formula
	node_ptr context;	//the context node of the node n
	
	bdd_ptr	bdd;	
};
struct structJusticeFormulas {
	struct structJusticeFormula JF[MAX_JUSTICEFORMULA_NUMBER];
	int count;
};
typedef struct structJusticeFormulas structJusticeFormulas;
//---------------------------------------


//----the datastructure for compassion formulas----
enum Compassion_Type{Compassion_NoType, Compassion_as_SpecAntecedent, Compassion_as_Justice, Compassion_at_AlgorithmLevel};

#define MAX_COMPASSIONFORMULA_NUMBER 100
struct structCompassionFormula {
	node_ptr parent;	//the parent node of the root of this compassion formula
	node_ptr	n;		//the root of this compassion formula
	node_ptr context;	//the context node of the node n
	
	node_ptr var;  //the auxiliary variable representing the resulting BDD of check(n)
};

struct structCompassionFormulas {
	struct structCompassionFormula CF[MAX_COMPASSIONFORMULA_NUMBER];
	int count;
};
typedef struct structCompassionFormulas structCompassionFormulas;
//---------------------------------------


/*----------------Variables for BDI verification -----------------------
Those variables must be declared in an agent's module.
BELIEF_WORLD is a boolean variable declared in an agent's module, if BELIEF_WORLD==true, then
indicates that the current state of the system belongs to the possible world of the agent's belief.
The explanation for DESIRE_WORLD and INTENTION_WORLD are similar to that of BELIEF_WORLD.
----------------------------------------------------------------*/
#define BELIEF_WORLD "WB"
#define DESIRE_WORLD "WD"
#define INTENTION_WORLD "WI"


/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN void eckl_Init ARGS((void));


#endif /* _CTLeckl_INC */

