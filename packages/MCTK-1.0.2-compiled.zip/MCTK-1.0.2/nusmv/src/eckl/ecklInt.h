/**CHeaderFile*****************************************************************

  FileName    [ecklInt.h]

  PackageName [eckl]

  Synopsis    [Internal header of the <tt>eckl</tt> package.]

  Author      [Xiangyu Luo]

  Copyright   [
  This file is part of the ``eckl'' package of MCTK version 1. 
  Copyright (C) 2003-2004 by Multi-Agent System Research Group in 
  Sun Yat-sen University, Guangzhou, China. 

  MCTK version 1 is free software; you can redistribute it and/or 
  modify it under the terms of the GNU Lesser General Public 
  License as published by the Free Software Foundation; either 
  version 2 of the License, or (at your option) any later version.

  MCTK version 1 is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public 
  License along with this library; if not, write to the Free Software 
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA.

  For more information of MCTK see <http://agent.sysu.edu.cn>
  or email to <isp03lxy@student.zsu.edu.cn>.
  Please report bugs to <isp03lxy@student.zsu.edu.cn>.

  To contact the MCTK development board, email to <isp03lxy@student.zsu.edu.cn>. ]

******************************************************************************/

#ifndef _CTLeckl_INT
#define _CTLeckl_INT

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "sm.h"
#include "util.h"
#include "utils.h"
#include "node.h"
#include "set.h"
#include "dd.h"
#include "rbc.h"
#include "grammar.h"
#include "parser.h"
#include "compile.h"
#include "img.h"
#include "opt.h"
#include "prop.h"
#include "mc.h"
#include "cmd.h"

#include "eckl.h"

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/
//for eckl.c
extern add_ptr input_variables_add;
extern bdd_ptr input_variables_bdd;
extern add_ptr next_input_variables_add;
extern bdd_ptr next_input_variables_bdd;
extern add_ptr state_variables_add;
extern bdd_ptr state_variables_bdd;
extern add_ptr next_state_variables_add;
extern bdd_ptr next_state_variables_bdd;
extern node_ptr state_variables;
extern node_ptr input_variables;
extern node_ptr all_symbols;
extern node_ptr all_variables;
extern options_ptr options;
extern cmp_struct_ptr cmps;
extern bdd_ptr trans_bdd;
extern bdd_ptr fair_states_bdd;
extern node_ptr fairness_constraints_bdd;
extern node_ptr real_state_variables;
extern FILE * nusmv_stdout;
extern FILE * nusmv_stderr;
extern DdManager * dd_manager;
extern bdd_ptr invar_bdd;
extern bdd_ptr init_bdd;
extern node_ptr parse_tree;

//for ecklEval.c
extern FILE * nusmv_stderr;
extern FILE * nusmv_stdout;
extern DdManager * dd_manager;
extern int yylineno;
extern options_ptr options;
extern cmp_struct_ptr cmps;

extern node_ptr one_number;
extern node_ptr zero_number;

extern bdd_ptr invar_bdd;
extern bdd_ptr init_bdd;
extern bdd_ptr reachable_states_bdd;
extern node_ptr reachable_states_layers;
extern node_ptr fairness_constraints_bdd;
extern bdd_ptr fair_states_bdd;

//extern node_ptr real_state_variables;
extern add_ptr process_selector_add;
//extern bdd_ptr input_variables_bdd;
//extern node_ptr all_variables;
//extern node_ptr all_symbols;

extern int current2next[MAX_VAR_INDEX];
extern int next2current[MAX_VAR_INDEX];

extern struct structAuxiVar AuxiVars[MAX_AUXIVARS_NUMBER];
extern int AuxiVars_num;  //the number of AuxiVars

//===========================================

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/
extern node_ptr eval_formula_list	ARGS((Fsm_BddPtr fsm, node_ptr nodes, node_ptr context));
extern void free_formula_list		ARGS((DdManager * dd, node_ptr formula_list));





#endif /* _CTLeckl_INT */
