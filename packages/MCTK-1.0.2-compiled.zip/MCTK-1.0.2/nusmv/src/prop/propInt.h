/**CHeaderFile*****************************************************************

  FileName    [propInt.h]

  PackageName [prop]

  Synopsis    [required]

  Description [optional]

  SeeAlso     [optional]

  Author      [Marco Roveri]

  Copyright   [
  This file is part of the ``prop'' package of NuSMV version 2. 
  Copyright (C) 2000-2001 by ITC-irst. 

  NuSMV version 2 is free software; you can redistribute it and/or 
  modify it under the terms of the GNU Lesser General Public 
  License as published by the Free Software Foundation; either 
  version 2 of the License, or (at your option) any later version.

  NuSMV version 2 is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public 
  License along with this library; if not, write to the Free Software 
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA.

  For more information of NuSMV see <http://nusmv.irst.itc.it>
  or email to <nusmv-users@irst.itc.it>.
  Please report bugs to <nusmv-users@irst.itc.it>.

  To contact the NuSMV development board, email to <nusmv@irst.itc.it>. ]

  Revision    [$Id: propInt.h,v 1.5 2001/11/05 10:57:04 none Exp $]

******************************************************************************/

#ifndef _prop_int
#define _prop_int

#include "util.h"
#include "utils.h"
#include "ucmd.h"
#include "array.h"
#include "node.h"
#include "dd.h"
#include "grammar.h"
#include "rbc.h"
#include "set.h"
#include "compile.h"
#include "opt.h"
#include "set.h"
#include "rbc.h"
#include "mc.h"
#include "ltl.h"
#include "cmd.h"
#include "prop.h"
#include "parser.h"
#include "img.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Structure declarations                                                    */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/
extern FILE * nusmv_stderr;
extern FILE * nusmv_stdout;
extern options_ptr options;
extern node_ptr all_variables;
extern cmp_struct_ptr cmps;

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/


/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

int Prop_Db_PropParseFromArgAndAdd ARGS((int argc, char ** argv, const Prop_Type type));

/**AutomaticEnd***************************************************************/

#endif /* _prop_int */
