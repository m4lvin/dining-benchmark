#! /bin/sh
rm -rf lib/* include *.bak *~
