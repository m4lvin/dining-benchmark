#! /bin/sh
CREATE="ln -sf"
if [ ! -d include ]; then
    mkdir include
fi

cd include
$CREATE ../cudd/cudd.h .
$CREATE ../cudd/cuddInt.h .
$CREATE ../dddmp/dddmp.h .
$CREATE ../mtr/mtr.h .
$CREATE ../st/st.h .
$CREATE ../util/util.h .
$CREATE ../obj/cuddObj.hh .
$CREATE ../mnemosyne/mnemosyne.h .
$CREATE ../../nusmv/src/node/node.h .
cd ..

if [ ! -d lib ]; then 
    mkdir lib
fi

cd lib
$CREATE ../cudd/libcudd.a .
$CREATE ../mtr/libmtr.a .
$CREATE ../st/libst.a .
$CREATE ../util/libutil.a libcudd_util.a
