#include <ctime>
#include "types.hh"
#include "utilities.hh"

using namespace std;

Object::~Object()
{
}

string
Object::to_string()
{
  return "";
}

